# demoya donuştürme = pyinstaller --onefile --icon=rest.ico --noconsole frmGiris.py
# demoya donuştürme = pyinstaller --onefile --icon=rest.ico frmGiris.py
# dosya dönüştürme  = pyuic5 ui/frmPaketYeniMusteri.ui -o py/frmPaketYeniMusteriUi.py
# resim dönüştürme  = pyrcc5 -o ImageRestorant_rc.py ImageRestorant.qrc



import subprocess
# Dönüştürülecek UI dosyalarını listeye ekleyin
ui_files = [
    "ui/frmGiris.ui",
    "ui/frmMasalar.ui",
    "ui/frmMenu.ui",
    "ui/frmOdeme.ui",
    "ui/frmSiparis.ui",
]

# Her UI dosyasını py dosyasına dönüştürün
for ui_file in ui_files:
    py_file = "py/{}.py".format(ui_file.split("/")[-1].replace(".ui", "Ui"))
    command = ["pyuic5", ui_file, "-o", py_file]
    
    try:
        subprocess.run(command, check=True)
        print("{} başarıyla dönüştürüldü.".format(ui_file))
    except subprocess.CalledProcessError:
        print("{} dönüştürülürken bir hata oluştu.".format(ui_file))

