import mysql.connector
from PyQt5 import QtWidgets
from datetime import datetime
from py.frmSiparisUi import Ui_frmSiparis
from PyQt5.QtWidgets import QMessageBox
from database import connect_to_database



class frmSiparis(QtWidgets.QMainWindow):
    def __init__(self,masa_no):
        super(frmSiparis, self).__init__()
        self.ui = Ui_frmSiparis()
        self.ui.setupUi(self) 
        self.showFullScreen()

        #--Hesap Makınesı--
        self.ui.btn1.clicked.connect(lambda: self.add_digit(1)) 
        self.ui.btn2.clicked.connect(lambda: self.add_digit(2))
        self.ui.btn3.clicked.connect(lambda: self.add_digit(3))
        self.ui.btn4.clicked.connect(lambda: self.add_digit(4))
        self.ui.btn5.clicked.connect(lambda: self.add_digit(5))
        self.ui.btn6.clicked.connect(lambda: self.add_digit(6))
        self.ui.btn7.clicked.connect(lambda: self.add_digit(7))
        self.ui.btn8.clicked.connect(lambda: self.add_digit(8))
        self.ui.btn9.clicked.connect(lambda: self.add_digit(9))
        self.ui.btn0.clicked.connect(lambda: self.add_digit(0))
        self.ui.btnTemizle.clicked.connect(self.clear_line_edit)
        #----

        self.ui.btnGeri.clicked.connect(self.back_application)        #btnGeri buton tıklama
        self.ui.btnAnaYemek.clicked.connect(self.get_main_course)     #btnAnaYemek buton
        self.ui.btnMakarna.clicked.connect(self.get_pasta)            #btnMakarna buton
        self.ui.btnSalata.clicked.connect(self.get_salad)             #btnSalata buton
        self.ui.btnDurum.clicked.connect(self.get_durum)              #btnSalata buton
        self.ui.btnArasicak.clicked.connect(self.get_between)         #btnSalata buton
        self.ui.btnCorba.clicked.connect(self.get_soup)               #btnCorba buton
        self.ui.btnFastfood.clicked.connect(self.get_fastfood)        #btnFastfood buton
        self.ui.btnIcecekler.clicked.connect(self.get_drink)          #btnIcecekler buton
        self.ui.btnTatli.clicked.connect(self.get_sweet)              #btnTatli buton
        self.ui.twIcindekiler.itemClicked.connect(self.contents_table)#twIcindekiler tablosu 
        self.ui.twIcindekiler.itemClicked.connect(self.connecting_calculator)#hesapmakınesının baglanması
        self.ui.btnSiparis.clicked.connect(self.order_application)    #btnSiparis
        self.ui.btnOdeme.clicked.connect(self.payment_application)    #odeme sayfasına
        self.ui.btnUrunSil.clicked.connect(self.order_table_delete)
        self.ui.btnKlavye.clicked.connect(self.openKeyboard)          #twSiparis not ekle silme 

        # Bağlantıyı başlat...
        self.connection = connect_to_database()

        # Kullanıcı kontrolünü yapın
        self.authorized_user(masa_no)


    def set_masa_info(self, masa_no):   #masa numarasını al
        masaNumarasi = masa_no[5:]
        self.ui.lblMasaNo.setText(f"Masa {masaNumarasi}")

        try:
            # Veritabanına bağlanın
            connection = self.connection
            if connection is not None:
                cursor = connection.cursor()
                
                # Belirli masa numarasına sahip ve durumu "Açık" olan en son adisyonun tarihini alın
                cursor.execute(
                    "SELECT tarih FROM adisyonlar WHERE masaİd = %s AND durum = %s AND servisTuru = %s ORDER BY tarih DESC LIMIT 1",
                    (masaNumarasi, "acik","normal")
                )
                
                result = cursor.fetchone()
                
                if result:
                    adisyon_tarihi = result[0]  # Veritabanından gelen tarih

                    # Şu anki tarihi ve saat bilgisini alın
                    simdiki_saat = datetime.now().time()

                    # Zaman farkını hesaplayın
                    fark_saniye = adisyon_tarihi.hour * 3600 + adisyon_tarihi.minute * 60 + adisyon_tarihi.second
                    simdiki_saat_saniye = simdiki_saat.hour * 3600 + simdiki_saat.minute * 60 + simdiki_saat.second

                    fark_saniye = simdiki_saat_saniye - fark_saniye
                    saat = fark_saniye // 3600
                    dakika = (fark_saniye % 3600) // 60

                    # Elapsed time'i lblMasaSure içinde gösterin
                    self.ui.lblMasaSure.setText(f"{saat}s  {dakika}dk")

                cursor.close()

        except mysql.connector.Error as err:
            print("Hata set_masa_info:", err)

    def connecting_calculator(self):    #Coklu sıparıs hesabMakınesı
        # Seçilen ürünün bilgilerini al
        selected_row = self.ui.twIcindekiler.currentRow()
        if selected_row < 0:
            return  # Hiçbir ürün seçilmediyse işlem yapma

        urun_adi = self.ui.twIcindekiler.item(selected_row, 2).text()  # Ürün adını al
        urun_adet = int(self.ui.lnUrunAdet.text() or 1)  # Ürün adedini al (boşsa 1 olarak kabul et)

        # Ürün adedini kontrol edin, negatifse 0 yapın
        if urun_adet < 0:
            urun_adet = 0

        if urun_adet == 0:
            return  # Ürün adeti 0 ise işlem yapma

        # twSiparis QTableWidget'deki mevcut satırları kontrol et
        for row in range(self.ui.twSiparis.rowCount()):
            existing_item = self.ui.twSiparis.item(row, 4)
            if existing_item and existing_item.text() == urun_adi:
                # Ürün zaten listede, adet sütunundaki sayıyı güncelle
                adet_item = self.ui.twSiparis.item(row, 1)
                current_adet = int(adet_item.text()) if adet_item else 1
                new_adet = (current_adet + urun_adet)-1
                adet_item = QtWidgets.QTableWidgetItem(str(new_adet))
                self.ui.twSiparis.setItem(row, 1, adet_item)
                return

        # Ürün bilgilerini twSiparis QTableWidget'e yerleştirin
        row_position = self.ui.twSiparis.rowCount()
        self.ui.twSiparis.insertRow(row_position)
        urun_fiyati = self.ui.twIcindekiler.item(selected_row, 0).text()
        urun_id = self.ui.twIcindekiler.item(selected_row, 1).text()
        urun_notu = ""
        self.ui.twSiparis.setItem(row_position, 0, QtWidgets.QTableWidgetItem(urun_fiyati))
        self.ui.twSiparis.setItem(row_position, 3, QtWidgets.QTableWidgetItem(urun_id))
        self.ui.twSiparis.setItem(row_position, 4, QtWidgets.QTableWidgetItem(urun_adi))
        self.ui.twSiparis.setItem(row_position, 2, QtWidgets.QTableWidgetItem(str(urun_adet)))
        self.ui.twSiparis.setItem(row_position, 1, QtWidgets.QTableWidgetItem(urun_notu))


        # Ürün adetini temizleyin
        self.ui.lnUrunAdet.clear()

    def update_table_status(self, table_number):    #masadurum guncelleme
            connection = self.connection
            if connection is not None:
                try:
                    cursor = connection.cursor()
                    
                    # Masalar tablosundaki belirli bir masa numarasının durumunu ve masaDurum sütununu güncelle
                    update_query = "UPDATE masalar SET durum = 2, masaDurum = 'acik' WHERE id = %s"
                    cursor.execute(update_query, (table_number,))
                    
                    connection.commit()  # Değişiklikleri veritabanına kaydet
                    cursor.close()
                    
                    print(f"Masa {table_number} durumu güncellendi.")
                except mysql.connector.Error as err:
                    print("Hata update_table:", err)

    def add_order_to_adisyonlar(self, table_number):    #adisyonlara masayı kaydet
        connection = self.connection
        if connection is not None:
            try:
                cursor = connection.cursor()

                # Adisyonlar tablosuna ekleme yap
                insert_query = "INSERT INTO adisyonlar (masaId, tarih, durum,servisTuru) VALUES (%s, %s, %s)"
                current_datetime = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                cursor.execute(insert_query, (table_number, current_datetime, 'acik','normal'))

                connection.commit()
                cursor.close()

                print(f"Masa {table_number} için sipariş kaydedildi.")
            except mysql.connector.Error as err:
                print("Hata add_order_to_adisyonlar:", err)
        
    def masa_numarasina_gore_adisyon_id_al(self, masa_numarasi):
        baglanti = self.connection
        if baglanti is not None:
            try:
                cursor = baglanti.cursor()

                # Belirli bir masa numarası için adisyonId'yi almak için sorgu
                secme_sorgusu = "SELECT id FROM adisyonlar WHERE masaİd = %s AND durum = 'acik' AND servisTuru='normal'"
                cursor.execute(secme_sorgusu, (masa_numarasi,))
                adisyon_id = cursor.fetchone()[0]

                cursor.close()
                baglanti.close()

                return adisyon_id
            except mysql.connector.Error as hata:
                print("Hata masa_numarasina_gore_adisyon_id_al:", hata)

    def order_application(self):    #tum sıparıslerın buton basvurusu
        for row in range(self.ui.twSiparis.rowCount()):
            adet_item = self.ui.twSiparis.item(row, 1)
            if adet_item is None or adet_item.text() == "":
                QMessageBox.critical(self, "Hata", "Lütfen her siparişin adetini girin.")
                return

        for col in range(self.ui.twSiparis.columnCount()):
            item = self.ui.twSiparis.item(0, 0)
            if item is None or item.text() == "":
                QMessageBox.critical(self, "Hata", "Lütfen bir sipariş ekleyin.")
                return      
                
        table_number = self.ui.lblMasaNo.text()  # Masanın numarasını al
        table_number = table_number[5:]  # Masa numarasını uygun formatta al

        # Masanın durumunu kontrol et
        adisyon_id = self.check_table_status(table_number)

        print(f"\n<--- Masanın Açma İşlemleri Başladı --->")
        if adisyon_id is not None:
            # Mevcut bir adisyon var, siparişleri bu adisyon üzerine ekleyin
            self.add_order_to_existing_adisyon(adisyon_id)
        else:
            # Mevcut bir adisyon yok, yeni bir adisyon oluşturun ve siparişleri ekleyin
            adisyon_id = self.create_new_adisyon(table_number)
            self.add_order_to_existing_adisyon(adisyon_id)
        
        self.update_table_status(table_number)  # Masa durumunu güncelle
        self.yazdir()
        print(f"<--- Masanın Açma İşlemleri Bitti --->")

        # Eğer frmKlavye açıksa, onu da kapat
        if hasattr(self, 'frm_frmKlavye'):
            self.frm_frmKlavye.close()
            
        self.close()
        from frmMasalar import frmMasalar
        self.frm_masalar = frmMasalar()
        self.frm_masalar.show()

    def check_table_status(self, table_number):
        connection = self.connection
        if connection is not None:
            try:
                cursor = connection.cursor()

                # Masalar tablosundan belirli bir masa numarasının adisyon durumunu kontrol edin
                query = "SELECT id FROM adisyonlar WHERE masaİd = %s AND durum = 'acik' AND servisTuru = 'normal'"
                cursor.execute(query, (table_number,))
                result = cursor.fetchone()

                cursor.close()

                if result:
                    return result[0]  # Mevcut bir adisyon bulunduysa adisyon id'sini döndürün
                else:
                    return None  # Mevcut bir adisyon yoksa None döndürün
            except mysql.connector.Error as err:
                print("Hata check_table_status:", err)

    def create_new_adisyon(self, table_number):
        connection = self.connection
        if connection is not None:
            try:
                cursor = connection.cursor()

                # Yeni bir adisyon oluşturun
                insert_query = "INSERT INTO adisyonlar (masaİd, tarih, durum,servisTuru) VALUES (%s, %s, %s, %s)"
                current_datetime = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                cursor.execute(insert_query, (table_number, current_datetime, 'acik','normal'))
                connection.commit()

                # Oluşturulan adisyonun id'sini alın
                query = "SELECT LAST_INSERT_ID()"
                cursor.execute(query)
                adisyon_id = cursor.fetchone()[0]

                cursor.close()

                print(f"Masa {table_number} için yeni bir adisyon oluşturuldu.")
                return adisyon_id
            except mysql.connector.Error as err:
                print("Hata crate_new:", err)

    def add_order_to_existing_adisyon(self, adisyon_id):    # satsları dataya ekle 

            table_number = self.ui.lblMasaNo.text()  # Masanın numarasını al
            table_number = table_number[5:]  # Masa numarasını uygun biçimde alın

            # Veritabanına bağlanın
            connection = self.connection

            if connection is not None:
                try:
                    cursor = connection.cursor()

                    for satir in range(self.ui.twSiparis.rowCount()):
                        # Sipariş detaylarını tablodan alın
                        urun_id = int(self.ui.twSiparis.item(satir, 4).text())
                        adet = int(self.ui.twSiparis.item(satir, 1).text())
                        urun_not = str(self.ui.twSiparis.item(satir, 2).text())

                        # Şu anki tarih ve saat bilgisini alın
                        tarih_ve_saat = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                        servıs_turu = "normal"
                        durum = "acik"

                        # Siparişi "satislar" tablosuna ekleyin
                        ekleme_sorgusu = "INSERT INTO satislar (adisyonİd, urunİd, masaİd, adet, servisTuru, durum, satisZamani,urunNot) VALUES (%s,%s, %s, %s, %s, %s, %s,%s)"
                        cursor.execute(ekleme_sorgusu, (adisyon_id, urun_id, table_number, adet, servıs_turu, durum, tarih_ve_saat,urun_not))

                        connection.commit()

                    cursor.close()
                    print(f"Masa {table_number} için siparişler eklendi.")

                except mysql.connector.Error as hata:
                    print("Hata add_order:", hata)

    def payment_application(self):   # frmOdeme sayfasına
        self.close()
        from frmOdeme import frmOdeme
        self.frm_odeme = frmOdeme()
        masa_no = self.ui.lblMasaNo.text()
        self.frm_odeme.set_masa_info(masa_no)
        self.frm_odeme.show()

    def yazdir(self):
        try:
            dosya_adi = "adisyon_fisi.txt"
            simdiki_zaman = datetime.now().strftime("%H:%M")  # Şu anki tarih ve saat bilgisini al ve formatla

            with open(dosya_adi, "w", encoding="utf-8") as dosya:
                # Ek bilgileri dosyaya yaz
                dosya.write("-------- REHBER ADİSYON ---------\n\n")
                dosya.write(f"Saat: {simdiki_zaman}\n")
                dosya.write(f"Masa: {self.ui.lblMasaNo.text()}\n\n")

                # Sipariş bilgilerini dosyaya yaz
                dosya.write("Ürün\tAdet\tNot\n")
                for row in range(self.ui.twSiparis.rowCount()):
                    if self.ui.twSiparis.item(row, 0) and self.ui.twSiparis.item(row, 1) and self.ui.twSiparis.item(row, 2):
                        urun = self.ui.twSiparis.item(row, 0).text()
                        adet = self.ui.twSiparis.item(row, 1).text()
                        fiyat = self.ui.twSiparis.item(row, 2).text()
                        dosya.write(f"{urun.ljust(21)}{adet.ljust(5)}{fiyat}\n")

                dosya.write("\n\n------ İyi Günler Dileriz -------")
            print(f"{dosya_adi} dosyasına yazıldı.")

        except Exception as e:
            print(f"Hata: {e}")

    def contents_table(self, item):  #twİçindekiler tablosu
        # Seçilen ürünün bilgilerini al
        selected_row = item.row()
        urun_fiyati = self.ui.twIcindekiler.item(selected_row, 0).text()
        urun_id = self.ui.twIcindekiler.item(selected_row, 1).text()
        urun_notu = ""
        urun_adi = self.ui.twIcindekiler.item(selected_row, 2).text()

        # twSiparis QTableWidget'deki mevcut satırları kontrol et
        for row in range(self.ui.twSiparis.rowCount()):
            existing_item = self.ui.twSiparis.item(row, 4)
            if existing_item and existing_item.text() == urun_adi:
                # Ürün zaten listede, adet sütunundaki sayıyı artır
                adet_item = self.ui.twSiparis.item(row, 1)
                current_adet = int(adet_item.text()) if adet_item else 0
                new_adet = current_adet + 1
                adet_item = QtWidgets.QTableWidgetItem(str(new_adet))
                self.ui.twSiparis.setItem(row, 1, adet_item)
                return

        # twSiparis QTableWidget'e yeni bir satır ekleyin
        row_position = self.ui.twSiparis.rowCount()
        self.ui.twSiparis.insertRow(row_position)

        # Ürün bilgilerini twSiparis QTableWidget'e yerleştirin
        self.ui.twSiparis.setItem(row_position, 0, QtWidgets.QTableWidgetItem(urun_fiyati))
        self.ui.twSiparis.setItem(row_position, 3, QtWidgets.QTableWidgetItem(urun_id))
        self.ui.twSiparis.setItem(row_position, 4, QtWidgets.QTableWidgetItem(urun_adi))
        self.ui.twSiparis.setItem(row_position, 2, QtWidgets.QTableWidgetItem(urun_notu))

    def order_table_delete(self):
        selected_items = self.ui.twSiparis.selectedItems()
        if not selected_items:
            return

        # Seçili öğenin bulunduğu satırı bulun
        selected_row = selected_items[0].row()

        # Tablodan seçili satırı kaldırın
        self.ui.twSiparis.removeRow(selected_row)
   
    def clear_line_edit(self):   #temizle butonu
        self.ui.lnUrunAdet.clear()

    def add_digit(self, digit):   #1-9 rakam gönderme
        current_text = self.ui.lnUrunAdet.text()
        new_text = current_text + str(digit)
        self.ui.lnUrunAdet.setText(new_text)

    def back_application(self):   #pencere kapatma
        self.close()
        from frmMasalar import frmMasalar
        self.frm_masalar = frmMasalar()
        self.frm_masalar.show()

    def get_items_by_category(self, category_id):
        connection = self.connection
        cursor = connection.cursor()
        # urunler tablosundan kategoriId'ye göre ürünleri seçin
        query = "SELECT id, urunAd, fiyat FROM urunler WHERE kategoriId = %s"
        try:
            cursor.execute(query, (category_id,))
            items = cursor.fetchall()

            # TableView'deki modeli temizleyin
            self.ui.twIcindekiler.setRowCount(0)

            # Verileri TableView'e ekleme
            for row_num, (urunAd, fiyat, id) in enumerate(items):
                self.ui.twIcindekiler.insertRow(row_num)
                self.ui.twIcindekiler.setItem(row_num, 0, QtWidgets.QTableWidgetItem(str(fiyat)))
                self.ui.twIcindekiler.setItem(row_num, 1, QtWidgets.QTableWidgetItem(str(id)))
                self.ui.twIcindekiler.setItem(row_num, 2, QtWidgets.QTableWidgetItem(str(urunAd)))
        except mysql.connector.Error as err:
            print("Hata:", err)
        finally:
            cursor.close()

    def get_main_course(self):
        self.get_items_by_category(1)

    def get_pasta(self):
        self.get_items_by_category(2)

    def get_salad(self):
        self.get_items_by_category(3)

    def get_soup(self):
        self.get_items_by_category(4)

    def get_fastfood(self):
        self.get_items_by_category(5)

    def get_drink(self):
        self.get_items_by_category(6)

    def get_between(self):
        self.get_items_by_category(7)

    def get_durum(self):
        self.get_items_by_category(9)

    def get_sweet(self):
        self.get_items_by_category(8)