from PyQt5 import QtWidgets
import mysql.connector
from py.frmMenuUi import Ui_frmMenu
from PyQt5.QtCore import QTimer
from datetime import datetime
from wifi import update_wifi_status 
from database import connect_to_database


class frmMenu(QtWidgets.QMainWindow):
    def __init__(self):                                     # Menu penceresi
        super(frmMenu, self).__init__()
        self.ui = Ui_frmMenu()
        self.ui.setupUi(self) 
        self.showFullScreen()
        self.ui.lblTelefon.setText("0553 327 ** **")

        self.ui.btnMasalar.clicked.connect(self.tables_application)
        self.ui.btnCikis.clicked.connect(self.back_application)


        self.connection = connect_to_database()

        # Başlangıçta saat ve tarihi güncelle
        self.guncelle_saat_tarih()
        timer = QTimer(self)
        timer.timeout.connect(self.guncelle_saat_tarih)
        timer.start(1000) 

        # Wi-Fi durumunu kontrol etmek için bir timer oluşturun
        self.timer = QTimer(self) 
        self.timer.timeout.connect(self.check_wifi_status) 
        self.timer.start(15000)

        # Kullanıcı kontrolünü yapın
        self.authorized_user()  

    def check_wifi_status(self):                            # Wi-Fi durumunu kontrol et
        update_wifi_status(self.ui) 

    def authorized_user(self):                              # Kullanıcı kontrolunu yap
        try:
            # Veritabanına bağlanın
            connection = self.connection
            if connection is not None:
                cursor = connection.cursor()

                # Son eklenen kaydı alın
                query = "SELECT personelAd FROM personelhareketleri ORDER BY tarih DESC LIMIT 1"
                cursor.execute(query)
                last_user = cursor.fetchone()

                if last_user and last_user[0] == "admin":
                    # Son kullanıcı admin ise, tüm butonlar etkinleştirilir
                    self.enable_all_buttons()
                    self.ui.lblKullanici.setText(last_user[0])

                else:
                    # Diğer durumlarda sadece belirli butonlar etkinleştirilir
                    self.enable_specific_buttons_for_non_admin()
                    self.ui.lblKullanici.setText(last_user[0])

                cursor.close()

        except mysql.connector.Error as err:
            print("Veritabanı Hatası authorized_user:", err)

    def enable_specific_buttons_for_non_admin(self):        # Kullanıcı kontrolünü yap buton ac
        # Sadece belirli butonları etkinleştir (admin olmayan kullanıcılar için)
        self.ui.btnMasalar.setEnabled(True)
        self.ui.btnPaketler.setEnabled(True)
        self.ui.btnKilit.setEnabled(True)
        self.ui.btnCikis.setEnabled(True)
        # Diğer butonları devre dışı bırak
        self.ui.btnMusteriler.setEnabled(False)
        self.ui.btnAyarlar.setEnabled(False)
        self.ui.btnMutak.setEnabled(False)
        self.ui.btnRaporlar.setEnabled(False)

    def enable_all_buttons(self):                           # Kullanıcı kontrolünü yap buton ac
        # Tüm butonları etkinleştir
        for button in self.findChildren(QtWidgets.QPushButton):
            button.setEnabled(True)

    def tarih_metnini_olustur(self):                        # Tarih metnini olustur
        su_an = datetime.now()
        gunler = ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar"]
        aylar = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"]
        
        gun = gunler[su_an.weekday()]  # haftanın günü
        ay = aylar[su_an.month - 1]   # ayın adı
        tarih_metni = "{} {} {}".format(su_an.day, ay, gun)
        return tarih_metni

    def guncelle_saat_tarih(self):                          # Saat ve tarihi guncelle
        su_an = datetime.now()
        saat_metni = su_an.strftime("%H:%M")  # Sadece saat ve dakika
        tarih_metni = self.tarih_metnini_olustur()
        self.ui.lblSaat.setText(saat_metni)
        self.ui.lblTarih.setText(tarih_metni)

    def tables_application(self):                            # Masalar penceresini açma
        self.close()
        from frmMasalar import frmMasalar
        self.frm_masalar = frmMasalar()
        self.frm_masalar.show()

    def exit_application(self):                             # Programı kapatma
        QtWidgets.QApplication.quit()

    def back_application(self):                             # Porgramı kapatma
        QtWidgets.QApplication.quit()

