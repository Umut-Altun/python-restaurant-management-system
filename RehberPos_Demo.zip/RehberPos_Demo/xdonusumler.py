import subprocess

ui_files = [
    # "ui/frmUrunGuncelle.ui",
    "ui/frmMain.ui",
    # "ui/frmKlavye.ui",
    # "ui/frmPersonelKayit.ui",
    # "ui/frmPersonelGuncelle.ui",
    # "ui/frmPersonelSil.ui",
    # "ui/frmMusteriSil.ui",
    # "ui/frmUrunSil.ui",
    # "ui/frmArkaPlan.ui",
    # "ui/frmGiris.ui",
    # "ui/frmMasalar.ui",
    # "ui/frmMenu.ui",
    # "ui/frmMusteriler.ui",
    # "ui/frmMutfak.ui",
    # "ui/frmOdeme.ui",
    # "ui/frmPaket.ui",
    # "ui/frmRaporlar.ui",
    # "ui/frmPaketSiparis.ui",
    # "ui/frmPaketOdeme.ui",
    # "ui/frmAyarlar.ui",
    # "ui/frmSiparis.ui",
    # "ui/frmYeniMusteri.ui",
    # "ui/frmMusteriGuncelle.ui",
    # "ui/frmYeniUrun.ui",
]

# Her UI dosyasını py dosyasına dönüştürün
for ui_file in ui_files:
    py_file = "py/{}.py".format(ui_file.split("/")[-1].replace(".ui", "Ui"))
    command = ["pyuic5", ui_file, "-o", py_file]
    
    try:
        subprocess.run(command, check=True)
        print("{} başarıyla dönüştürüldü.".format(ui_file))
    except subprocess.CalledProcessError:
        print("{} dönüştürülürken bir hata oluştu.".format(ui_file))



# dosya dönüştürme  = pyuic5 ui/frmPaketYeniMusteri.ui -o py/frmPaketYeniMusteriUi.py

# resim dönüştürme  = pyrcc5 -o ImageRestorant_rc.py ImageRestorant.qrc

# demoya donuştürme = pyinstaller --onefile --icon=rest.ico frmGiris.py




