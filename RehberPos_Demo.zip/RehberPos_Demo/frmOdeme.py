from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QTableWidgetItem
from PyQt5.QtCore import QDateTime
from PyQt5.QtWidgets import QMessageBox
from py.frmOdemeUi import Ui_frmOdeme
import mysql.connector
from datetime import datetime
from database import connect_to_database


class frmOdeme(QtWidgets.QMainWindow):
    def __init__(self):                                                             # Odeme penceresi
        super(frmOdeme, self).__init__()
        self.ui = Ui_frmOdeme()
        self.ui.setupUi(self) 
        self.showFullScreen()

        # Database bağlantısı başlat...
        self.connection = connect_to_database() 

        self.ui.btnGeri.clicked.connect(self.back_application)                      # btnGeri buton tıklama
        self.ui.btnHesapKapat.clicked.connect(self.close_account)                   # hesap kapatma ıslemlerı
        self.ui.btnHesapOzet.clicked.connect(self.yazdir)     # adisyon yazdırma
        self.ui.btnUrunGetir.clicked.connect(self.populate_table)                   # sıparısı adısyona akatarma
        self.ui.btnIptal.clicked.connect(self.cancel_account)                       # btnIptal urun 
 
    def set_masa_info(self, masa_no):                                               # masa numarasını al
            self.ui.lblOdemeMasaNo.setText(masa_no)

    def populate_table(self):                                                       # sıparısı adısyona akatarma
            self.masa = self.ui.lblOdemeMasaNo.text()
            self.masa_no = int(self.masa[5:])
            self.servis_turu="normal"
            self.durum="acik"
            # Veritabanı bağlantısını alın
            connection = self.connection
            if connection:
                try:
                    cursor = connection.cursor()
                    # Siparişleri veritabanından al
                    cursor.execute(
                        "SELECT s.id, s.urunİd, s.adisyonİd, s.masaİd, s.adet,s.urunNot, u.urunAd, u.fiyat " \
                        "FROM satislar AS s " \
                        "INNER JOIN urunler AS u ON s.urunİd = u.id " \
                        "WHERE s.masaİd = %s AND s.servisTuru = %s AND s.durum = %s" ,
                        (self.masa_no, self.servis_turu, self.durum,)
                    )

                    
                    # Tabloyu temizle
                    self.ui.twSiparisOdeme.setRowCount(0)

                    total_price = 0  # Toplam fiyatı başlat
                    # Verileri tabloya ekleyin ve fiyatları toplayın
                    for row_num, (satis_id, urun_id, adisyon_id,masa_id, adet,urun_not, urun_adi, fiyat) in enumerate(cursor.fetchall()):
                        self.ui.twSiparisOdeme.insertRow(row_num)
                        self.ui.twSiparisOdeme.setItem(row_num, 0, QTableWidgetItem(urun_adi))
                        self.ui.twSiparisOdeme.setItem(row_num, 1, QTableWidgetItem(str(adet)))
                        self.ui.twSiparisOdeme.setItem(row_num, 2, QTableWidgetItem(str(fiyat)))
                        self.ui.twSiparisOdeme.setItem(row_num, 4, QTableWidgetItem(str(satis_id)))
                        self.ui.twSiparisOdeme.setItem(row_num, 5, QTableWidgetItem(str(urun_id)))
                        self.ui.twSiparisOdeme.setItem(row_num, 6, QTableWidgetItem(str(adisyon_id)))
                        self.ui.twSiparisOdeme.setItem(row_num, 7, QTableWidgetItem(str(masa_id)))
                        self.ui.twSiparisOdeme.setItem(row_num, 3, QTableWidgetItem(str(urun_not)))

                        # Her ürünün adetini fiyatıyla çarp ve toplam fiyata ekle
                        item_total = adet * fiyat
                        total_price += item_total

                    # Toplam fiyatı lblToplamTutar içinde göster
                    self.ui.lblToplamTutar.setText(str(total_price))

                except mysql.connector.Error as err:
                    print("Hata:", err)
                finally:
                    self.ui.twSiparisOdeme.repaint()
                    cursor.close()
                    
    def close_account(self):                                                        # hesap kapatma ıslemlerı
        self.masa = self.ui.lblOdemeMasaNo.text()
        self.masa_no = int(self.masa[5:])
        connection = self.connection
        # Ödeme türünü alın (rbNakit veya rbKart)
        payment_type = ""
        if self.ui.rbNakit.isChecked():
            payment_type = self.ui.rbNakit.text()
        elif self.ui.rbKart.isChecked():
            payment_type = self.ui.rbKart.text()
        if not payment_type:
            QMessageBox.critical(self, "Hata", "Lütfen ödeme türü seçin.")
            return

        if self.ui.btnHesapKapat.clicked:
            confirmation = QMessageBox.critical(self, "Onay", "Masa Kapatılsın mı?", QMessageBox.Ok | QMessageBox.Cancel)
            if confirmation == QMessageBox.Ok:
                if connection:
                    try:
                        cursor = connection.cursor()

                        # Adisyon ID'lerini bir küme (set) olarak saklayın
                        adisyon_ids = set()

                        # Sipariş verilerini al ve her adisyon için toplam tutarı hesaplayın
                        adisyon_totals = {}  # Adisyon ID'ye göre toplam tutarları saklayın

                        for row_num in range(self.ui.twSiparisOdeme.rowCount()):
                            adisyon_id = int(self.ui.twSiparisOdeme.item(row_num, 6).text())
                            adisyon_ids.add(adisyon_id)  # Her adisyonu bir kez ekleyin

                            # Siparişlerin toplam tutarını hesaplayın ve saklayın
                            item_price = float(self.ui.twSiparisOdeme.item(row_num, 2).text())
                            item_quantity = int(self.ui.twSiparisOdeme.item(row_num, 1).text())
                            item_total = item_price * item_quantity

                            if adisyon_id in adisyon_totals:
                                adisyon_totals[adisyon_id] += item_total
                            else:
                                adisyon_totals[adisyon_id] = item_total

                        # Her adisyon için bir ödeme işlemi oluşturun ve masa durumunu güncelleyin
                        for adisyon_id in adisyon_ids:
                            toplam_tutar = adisyon_totals[adisyon_id]  # Hesaplanmış toplam tutarı alın
                            tarih = QDateTime.currentDateTime().toString("yyyy-MM-dd HH:mm:ss")
                            servis_turu ="normal"
                            
                            print(f"\n>--- Masanın Kapatma İşlemleri Başladı ---<")
                            try:
                                # Verileri başka bir tabloya ekleyin
                                cursor.execute(
                                    "INSERT INTO hesapodemeleri (adisyonİd, odemeTuru, toplamTutar, tarih,servisTuru) VALUES (%s, %s, %s, %s, %s)",
                                    (adisyon_id, payment_type, toplam_tutar, tarih,servis_turu)
                                )
                                print(f"DB Masa {self.masa_no} Hesap Ödemeleri Alındı...")
                            except Exception as ex:
                                print("HATA",ex)
                            try:
                                # Masa durumunu güncelleyin
                                cursor.execute(
                                    "UPDATE masalar SET durum = %s, masaDurum = %s WHERE id = %s",
                                    (1, 'kapalı', self.masa_no,)
                                )
                                print(f"DB Masa {self.masa_no} Durumu Kapatıldı...")
                            except Exception as ex:
                                print("HATA",ex)
                            try:
                                # Adisyon durumunu güncelle
                                cursor.execute(
                                    "UPDATE adisyonlar SET durum = %s WHERE masaİd = %s AND servisTuru = %s",
                                    ("kapalı", self.masa_no,servis_turu,)
                                )
                                print(f"DB Masa {self.masa_no} Adisyonu Kapatıldı...")
                            except Exception as ex:
                                print("HATA:", ex)
                            
                            try:
                                # Adisyon durumunu güncelle
                                cursor.execute(
                                    "UPDATE satislar SET durum = %s WHERE masaİd = %s AND servisTuru = %s",
                                    ("kapalı", self.masa_no,servis_turu,)
                                )
                                print(f"DB Masa {self.masa_no} Satışları Kapatıldı...")
                            except Exception as ex:
                                print("HATA:", ex)
                            print(f">--- Masanın Kapatma İşlemleri Bitti ---<")

                        # Veritabanı değişikliklerini kaydet
                        connection.commit()

                        # Hesap ödemesini tamamladıktan sonra, tabloyu temizle ve toplam tutarı sıfırla
                        self.ui.twSiparisOdeme.setRowCount(0)
                        self.ui.lblToplamTutar.setText("0.0")
                        self.close()
                        from frmMasalar import frmMasalar
                        self.frm_masalar = frmMasalar()
                        self.frm_masalar.show()

                    except mysql.connector.Error as err:
                        print("Hata:", err)
                    finally:
                        cursor.close()
                else:
                    return
            elif confirmation == QMessageBox.Cancel:
                    return

    def transfer_data_to_adisyon_fis(self):                                         # adisyon yazdırma

        # Ödeme türünü alın (rbNakit veya rbKart)
        payment_type = ""
        if self.ui.rbNakit.isChecked():
            payment_type = self.ui.rbNakit.text()
        elif self.ui.rbKart.isChecked():
            payment_type = self.ui.rbKart.text()

        if not payment_type:
            QMessageBox.critical(self, "Hata", "Lütfen ödeme türü seçin.")
            return
        
        # Aktarılacak verileri topla, örneğin, twSiparisOdeme tablosundaki verileri alabilirsiniz
        table_data = []
        for row in range(self.ui.twSiparisOdeme.rowCount()):
            row_data = []
            for column in range(self.ui.twSiparisOdeme.columnCount()):
                item = self.ui.twSiparisOdeme.item(row, column)
                if item:
                    row_data.append(item.text())
                else:
                    row_data.append('')
            table_data.append(row_data)
        

        # Tarih ve ödeme türü verilerini ekleyin
        tarih = QDateTime.currentDateTime().toString("yyyy-MM-dd HH:mm:ss")
        self.adisyon_fis.set_tarih(tarih)
        self.adisyon_fis.set_odeme_turu(payment_type)
        toplam_tutar = self.ui.lblToplamTutar.text()
        self.adisyon_fis.set_toplam_tutar(toplam_tutar)
        # frmAdisyonFiş içindeki bir yöntemi çağırarak verileri aktarın
        self.adisyon_fis.populate(table_data)
        self.adisyon_fis.show()

    def back_application(self):                                                     # geri gel
        self.close()
        from frmMasalar import frmMasalar
        self.frm_siparis = frmMasalar()
        self.frm_siparis.show()

    def populate(self, table_data):                                                 # frmAdisyonFiş verileri aktarın
        for row_num, row_data in enumerate(table_data):
            self.ui.twIcindekiler.insertRow(row_num)
            for col_num, cell_data in enumerate(row_data):
                self.ui.twIcindekiler.setItem(row_num, col_num, QTableWidgetItem(cell_data))

    def cancel_account(self):                                                       # hesap iptal ıslemlerı
        self.masa = self.ui.lblOdemeMasaNo.text()
        self.masa_no = int(self.masa[5:])
        connection = self.connection
        # Ödeme türünü alın (rbNakit veya rbKart)
        payment_type = ""
        if self.ui.rbNakit.isChecked():
            payment_type = self.ui.rbNakit.text()
        elif self.ui.rbKart.isChecked():
            payment_type = self.ui.rbKart.text()
        if not payment_type:
            payment_type = "iptal"

        if self.ui.btnIptal.clicked:
            confirmation = QMessageBox.critical(self, "Onay", "Masa İptal Edilsin mi ?", QMessageBox.Ok | QMessageBox.Cancel)
            if confirmation == QMessageBox.Ok:
                if connection:
                    try:
                        cursor = connection.cursor()

                        # Adisyon ID'lerini bir küme (set) olarak saklayın
                        adisyon_ids = set()

                        # Sipariş verilerini al ve her adisyon için toplam tutarı hesaplayın
                        adisyon_totals = {}  # Adisyon ID'ye göre toplam tutarları saklayın

                        for row_num in range(self.ui.twSiparisOdeme.rowCount()):
                            adisyon_id = int(self.ui.twSiparisOdeme.item(row_num, 5).text())
                            adisyon_ids.add(adisyon_id)  # Her adisyonu bir kez ekleyin

                            # Siparişlerin toplam tutarını hesaplayın ve saklayın
                            item_price = float(self.ui.twSiparisOdeme.item(row_num, 2).text())
                            item_quantity = int(self.ui.twSiparisOdeme.item(row_num, 1).text())
                            item_total = item_price * item_quantity

                            if adisyon_id in adisyon_totals:
                                adisyon_totals[adisyon_id] += item_total
                            else:
                                adisyon_totals[adisyon_id] = item_total

                        # Her adisyon için bir ödeme işlemi oluşturun ve masa durumunu güncelleyin
                        for adisyon_id in adisyon_ids:
                            toplam_tutar = adisyon_totals[adisyon_id]  # Hesaplanmış toplam tutarı alın
                            tarih = QDateTime.currentDateTime().toString("yyyy-MM-dd HH:mm:ss")
                            servis_turu ="normal"

                            try:
                                # Masa durumunu güncelleyin
                                cursor.execute(
                                    "UPDATE masalar SET durum = %s, masaDurum = %s WHERE id = %s",
                                    (1, 'kapalı', self.masa_no,)
                                )
                                print("DB Masa Durumu *kapalı* Olarak Güncellendi...")
                            except Exception as ex:
                                print("HATA",ex)
                            try:
                                # Masa durumunu güncelleyin
                                cursor.execute(
                                    "UPDATE adisyonlar SET servisTuru = %s,durum = %s WHERE durum = %s AND masaİd = %s AND servisTuru = %s " ,
                                    ('iptal','kapalı','açık', self.masa_no,'normal')
                                )
                                print("DB Adisyon İptali Ve Durum Güncellemesi Yapıldı...")
                            except Exception as ex:
                                print("HATA",ex)
                            try:
                                # Sıparıs sılme
                                cursor.execute(
                                    "DELETE FROM satislar WHERE masaİd = %s AND servisTuru = %s",
                                    (self.masa_no,servis_turu,)
                                )
                                print("DB Siparisler Silindi...")
                            except Exception as ex:
                                print("HATA",ex)

                        # Veritabanı değişikliklerini kaydet
                        connection.commit()

                        # Hesap ödemesini tamamladıktan sonra, tabloyu temizle ve toplam tutarı sıfırla
                        self.ui.twSiparisOdeme.setRowCount(0)
                        self.ui.lblToplamTutar.setText("0.0")
                        self.close()
                        from frmMasalar import frmMasalar
                        self.frm_frmMasalar = frmMasalar()
                        self.frm_frmMasalar.show()

                    except mysql.connector.Error as err:
                        print("Hata cancel_account:", err)
                    finally:
                        cursor.close()
                else:
                    return
            elif confirmation == QMessageBox.Cancel :
                return
            
    def yazdir(self):
        try:
            dosya_adi = "adisyon_fisi.txt"
            simdiki_zaman = datetime.now().strftime("%H:%M")  # Şu anki tarih ve saat bilgisini al ve formatla

            with open(dosya_adi, "w", encoding="utf-8") as dosya:
                # Ek bilgileri dosyaya yaz
                dosya.write("-------- REHBER ADİSYON ---------\n\n")
                dosya.write(f"Saat: {simdiki_zaman}\n")
                dosya.write(f"Masa: {self.ui.lblOdemeMasaNo.text()}\n\n")

                # Sipariş bilgilerini dosyaya yaz
                dosya.write("Ürün\tAdet\tNot\n")
                for row in range(self.ui.twSiparisOdeme.rowCount()):
                    if self.ui.twSiparisOdeme.item(row, 0) and self.ui.twSiparisOdeme.item(row, 1):
                        urun = self.ui.twSiparisOdeme.item(row, 0).text()
                        adet = self.ui.twSiparisOdeme.item(row, 1).text()
                        dosya.write(f"{urun.ljust(21)}{adet.ljust(5)}\n")
                        
                
                dosya.write(f"\nTOPLAM TUTAR: {self.ui.lblToplamTutar.text()}\n")
                dosya.write("\n\n------ İyi Günler Dileriz -------")
            print(f"{dosya_adi} dosyasına siparişler aktarıldı.")

        except Exception as e:
            print(f"Hata yazdir: {e}")