import subprocess

def wifi_control(ui):
    try:
        result = subprocess.run(["netsh", "wlan", "show", "interfaces"], capture_output=True, text=True, encoding='utf-8', errors='ignore')
        if result.stdout is None:
            print("Wi-Fi durumu okunamadı.")
            ui.lblInternet.setText("No WiFi")
            return False

        if "Signal" in result.stdout and "SSID" in result.stdout:
            signal_strength_str = result.stdout.split("Signal")[1].split(":")[1].strip()
            signal_strength = int(''.join(filter(str.isdigit, signal_strength_str)))
            ssid = result.stdout.split("SSID")[1].split(":")[1].strip()
            ui.lblInternet.setText(f"Bağlı {signal_strength}%")
            return True
        else:
            ui.lblInternet.setText("No WiFi")
            return False
    except Exception as e:
        print(f"Hata: {e}")
        ui.lblInternet.setText("Error")
        return False

def update_wifi_status(ui):
    return wifi_control(ui)
