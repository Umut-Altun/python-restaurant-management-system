-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: localhost    Database: restorant
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `adisyonlar`
--

DROP TABLE IF EXISTS `adisyonlar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `adisyonlar` (
  `id` int NOT NULL AUTO_INCREMENT,
  `masaİd` int NOT NULL,
  `tarih` datetime NOT NULL,
  `durum` varchar(15) NOT NULL,
  `servisTuru` varchar(15) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adisyonlar`
--

LOCK TABLES `adisyonlar` WRITE;
/*!40000 ALTER TABLE `adisyonlar` DISABLE KEYS */;
/*!40000 ALTER TABLE `adisyonlar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hesapodemeleri`
--

DROP TABLE IF EXISTS `hesapodemeleri`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hesapodemeleri` (
  `id` int NOT NULL AUTO_INCREMENT,
  `adisyonİd` int NOT NULL,
  `odemeTuru` varchar(15) NOT NULL,
  `toplamTutar` decimal(10,2) NOT NULL,
  `tarih` datetime NOT NULL,
  `servisTuru` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hesapodemeleri`
--

LOCK TABLES `hesapodemeleri` WRITE;
/*!40000 ALTER TABLE `hesapodemeleri` DISABLE KEYS */;
/*!40000 ALTER TABLE `hesapodemeleri` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kategoriler`
--

DROP TABLE IF EXISTS `kategoriler`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kategoriler` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kategoriAdi` varchar(45) NOT NULL,
  `aciklama` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kategoriler`
--

LOCK TABLES `kategoriler` WRITE;
/*!40000 ALTER TABLE `kategoriler` DISABLE KEYS */;
INSERT INTO `kategoriler` VALUES (1,'Ana Yemek','-'),(2,'Makarna','-'),(3,'Salata','-'),(4,'Çorba','-'),(5,'FastFood','-'),(6,'İçecek','-'),(7,'AraSıcak','-'),(8,'Tatlı','-'),(9,'Dürüm','-');
/*!40000 ALTER TABLE `kategoriler` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `masalar`
--

DROP TABLE IF EXISTS `masalar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `masalar` (
  `id` int NOT NULL AUTO_INCREMENT,
  `durum` varchar(15) NOT NULL,
  `masaDurum` varchar(15) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `masalar`
--

LOCK TABLES `masalar` WRITE;
/*!40000 ALTER TABLE `masalar` DISABLE KEYS */;
INSERT INTO `masalar` VALUES (1,'1','kapalı'),(2,'1','kapalı'),(3,'1','kapalı'),(4,'1','kapalı'),(5,'1','kapalı'),(6,'1','kapalı'),(7,'1','kapalı'),(8,'1','kapalı'),(9,'1','kapali'),(10,'1','kapalı'),(11,'1','kapalı'),(12,'1','kapalı'),(13,'1','kapalı'),(14,'1','kapali'),(15,'1','kapalı'),(16,'1','kapalı'),(17,'1','kapali'),(18,'1','kapali'),(19,'1','kapalı'),(20,'1','kapali'),(21,'1','kapali'),(22,'1','kapalı'),(23,'1','kapali'),(24,'1','kapali'),(25,'1','kapali'),(26,'1','kapalı'),(27,'1','kapalı'),(28,'1','kapalı');
/*!40000 ALTER TABLE `masalar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personelhareketleri`
--

DROP TABLE IF EXISTS `personelhareketleri`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personelhareketleri` (
  `id` int NOT NULL AUTO_INCREMENT,
  `personelAd` varchar(45) NOT NULL,
  `durum` varchar(15) NOT NULL,
  `tarih` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personelhareketleri`
--

LOCK TABLES `personelhareketleri` WRITE;
/*!40000 ALTER TABLE `personelhareketleri` DISABLE KEYS */;
/*!40000 ALTER TABLE `personelhareketleri` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personeller`
--

DROP TABLE IF EXISTS `personeller`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personeller` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ad` varchar(20) NOT NULL,
  `soyad` varchar(20) NOT NULL,
  `sifre` varchar(15) NOT NULL,
  `gorev` varchar(15) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personeller`
--

LOCK TABLES `personeller` WRITE;
/*!40000 ALTER TABLE `personeller` DISABLE KEYS */;
/*!40000 ALTER TABLE `personeller` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `satislar`
--

DROP TABLE IF EXISTS `satislar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `satislar` (
  `id` int NOT NULL AUTO_INCREMENT,
  `adisyonİd` int NOT NULL,
  `urunİd` int NOT NULL,
  `masaİd` int NOT NULL,
  `adet` int NOT NULL,
  `servisTuru` varchar(15) NOT NULL,
  `durum` varchar(15) NOT NULL,
  `satisZamani` datetime NOT NULL,
  `urunNot` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `satislar`
--

LOCK TABLES `satislar` WRITE;
/*!40000 ALTER TABLE `satislar` DISABLE KEYS */;
/*!40000 ALTER TABLE `satislar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `urunler`
--

DROP TABLE IF EXISTS `urunler`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `urunler` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kategoriİd` int NOT NULL,
  `urunAd` varchar(45) NOT NULL,
  `aciklama` varchar(45) NOT NULL,
  `fiyat` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `urunler`
--

LOCK TABLES `urunler` WRITE;
/*!40000 ALTER TABLE `urunler` DISABLE KEYS */;
INSERT INTO `urunler` VALUES (1,1,'Soya Tavuk','-',242),(8,1,'Barbekü Tavuk','-',8),(13,3,'Mevsim Salata','-',54),(14,1,'Izgara Tavuk','-',56),(16,1,'Tavuk Sote','-',12),(17,1,'Meksika Tavuk','-',23),(18,3,'Tavuklu Salata','-',54),(19,3,'Ton Balık Salata','-',56),(20,3,'Çoban Salata','-',55),(21,2,'Alfredo Penne','-',56),(22,2,'Kori Penne','-',66),(23,2,'Soya Penne','-',56),(24,2,'Arabiata Penne','-',23),(25,4,'Mercimek','-',67),(26,4,'Yayla','-',32),(27,4,'Ezogelin','-',76),(28,4,'Tavuk','-',97),(29,5,'Patates Kızartma','-',34),(30,5,'Elma Patates','-',23),(31,6,'Su','-',5),(32,6,'Şişe Kola','-',34),(33,6,'Kutu Kola','-',45),(34,7,'Soğan Halkası','-',5),(35,8,'Sütlaç','-',55),(36,8,'Tulumba','-',33),(37,9,'Tavuk Dürüm','-',34),(38,9,'Tantuni Dürüm','-',32);
/*!40000 ALTER TABLE `urunler` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-12 17:50:58
