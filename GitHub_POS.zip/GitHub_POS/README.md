# Restoran Otomasyonu

Bu proje, bir restoranın günlük işlemlerini kolaylaştırmak amacıyla geliştirilmiştir.

## Özellikler

* Giriş ve çıkış işlemleri
* Masa yönetimi
* Sipariş yönetimi
* Ödeme yönetimi
* Raporlama ve analiz

## Kurulum

1. Projeyi klonlayın: `git clone https://github.com/your-username/your-repo-name.git`
2. Gerekli paketleri yükleyin: `pip install -r requirements.txt`
3. Veritabanını oluşturun: `python manage.py migrate`

## Kullanım

1. Uygulamayı çalıştırın: `python main.py`
2. Giriş yapın: `username` ve `password` girerek giriş yapın
3. Masa yönetimi: Masa listesini görüntüleyin, masa ekleyin, masa silin
4. Sipariş yönetimi: Sipariş listesini görüntüleyin, sipariş ekleyin, sipariş silin
5. Ödeme yönetimi: Ödeme listesini görüntüleyin, ödeme ekleyin, ödeme silin
6. Raporlama ve analiz: Raporları görüntüleyin, analiz yapın

## Lisans

Bu proje, MIT lisansı altında yayınlanmıştır.

## Katkıda Bulunanlar

* [Umut Altun](https://github.com/your-username)
* [Other Contributor](https://github.com/other-contributor)

## İletişim

* E-posta: [rehberpos@gmail.com](mailto:rehberpos@gmail.com)
* Adres: Ankara, Türkiye

## Sosyal Medya

- YouTube: [Yapay Rehber](https://www.youtube.com/@yapayrehber)
- Linked: [Umut Altun](https://www.linkedin.com/in/umut-altun-bb4918284)
- GitHub: [Umut Altun](https://github.com/Umut-Altun)

## Veritabanı

Bu proje, aşağıdaki veritabanlarını kullanmaktadır:

* MySQL

## Sürüm Notları

* v1.0.0: İlk sürüm