from forms.frmOdemeUi import Ui_frmOdeme
from PyQt5 import QtWidgets
from database.connect_to_database import connect_to_database
import mysql.connector
from PyQt5.QtWidgets import QTableWidgetItem
from PyQt5.QtWidgets import QMessageBox
from PyQt5.QtCore import QDateTime



class frmOdeme(QtWidgets.QWidget):   # Odeme formunu oluşturma
    def __init__(self, masa_no=None):
        super(frmOdeme, self).__init__()
        self.ui = Ui_frmOdeme()
        self.ui.setupUi(self)
        self.showFullScreen()

        # Masanın numarasını alma
        self.ui.lblOdemeMasaNo.setText(masa_no)

        # Butonlara tıklama olaylarını bağla
        self.ui.btnGeri.clicked.connect(self.back_application)          
        self.ui.btnUrunGetir.clicked.connect(self.populate_table)               
        self.ui.btnHesapKapat.clicked.connect(self.close_account)             

        # Database bağlantısı başlat...
        self.connection = connect_to_database() 


    def back_application(self):     # Geri butonuna tıklama olayı
        self.close()
        from views.frmMasalar import frmMasalar
        self.frm_siparis = frmMasalar()
        self.frm_siparis.show()

    def populate_table(self):       # Siparişleri tabloya ekleme
        self.masa = self.ui.lblOdemeMasaNo.text()
        self.masa_no = int(self.masa[5:])
        self.servis_turu="normal"
        self.durum="açık"

        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                # Siparişleri veritabanından al
                cursor.execute(
                    "SELECT s.id, s.urunİd, s.adisyonİd, s.masaİd, s.adet,s.urunNot, u.urunAd, u.fiyat " \
                    "FROM satislar AS s " \
                    "INNER JOIN urunler AS u ON s.urunİd = u.id " \
                    "WHERE s.masaİd = %s AND s.servisTuru = %s AND s.durum = %s" ,
                    (self.masa_no, self.servis_turu, self.durum,)
                )
                
                # Tabloyu temizle
                self.ui.twSiparisOdeme.setRowCount(0)

                total_price = 0  # Toplam fiyatı başlat

                # Verileri tabloya ekleyin ve fiyatları toplayın
                for row_num, (satis_id, urun_id, adisyon_id,masa_id, adet,urun_not, urun_adi, fiyat) in enumerate(cursor.fetchall()):
                    self.ui.twSiparisOdeme.insertRow(row_num)
                    self.ui.twSiparisOdeme.setItem(row_num, 0, QTableWidgetItem(urun_adi))
                    self.ui.twSiparisOdeme.setItem(row_num, 1, QTableWidgetItem(str(adet)))
                    self.ui.twSiparisOdeme.setItem(row_num, 2, QTableWidgetItem(str(fiyat)))
                    self.ui.twSiparisOdeme.setItem(row_num, 4, QTableWidgetItem(str(satis_id)))
                    self.ui.twSiparisOdeme.setItem(row_num, 5, QTableWidgetItem(str(urun_id)))
                    self.ui.twSiparisOdeme.setItem(row_num, 6, QTableWidgetItem(str(adisyon_id)))
                    self.ui.twSiparisOdeme.setItem(row_num, 7, QTableWidgetItem(str(masa_id)))
                    self.ui.twSiparisOdeme.setItem(row_num, 3, QTableWidgetItem(str(urun_not)))

                    # Her ürünün adetini fiyatıyla çarp ve toplam fiyata ekle
                    item_total = adet * fiyat
                    total_price += item_total

                # Toplam fiyatı lblToplamTutar içinde göster
                self.ui.lblToplamTutar.setText(str(total_price))

                cursor.close()

            except mysql.connector.Error as err:
                print("Hata populate_table:", err)

            finally:
                self.ui.twSiparisOdeme.repaint()    # Tabloyu yenileyeceğinden emin olun
        else:
            print("Veritabanı bağlantısı başarısız")
    
    def close_account(self):         # Hesap kapat butonuna tıklama olayı
        self.masa = self.ui.lblOdemeMasaNo.text()
        self.masa_no = int(self.masa[5:])

        # Ödeme türünü alın (rbNakit veya rbKart)
        payment_type = ""
        if self.ui.rbNakit.isChecked():
            payment_type = self.ui.rbNakit.text()
        elif self.ui.rbKart.isChecked():
            payment_type = self.ui.rbKart.text()
        if not payment_type:
            QMessageBox.critical(self, "Hata", "Lütfen ödeme türü seçin.")
            return

        # Hesap kapatılsın mı?
        if self.ui.btnHesapKapat.clicked:
            confirmation = QMessageBox.critical(self, "Onay", "Masa Kapatılsın mı?", QMessageBox.Ok | QMessageBox.Cancel)
            if confirmation == QMessageBox.Ok:
                if self.connection is not None:
                    try:
                        cursor = self.connection.cursor()

                        # Adisyon ID'lerini bir küme (set) olarak saklayın
                        adisyon_ids = set()

                        # Sipariş verilerini al ve her adisyon için toplam tutarı hesaplayın
                        adisyon_totals = {}  # Adisyon ID'ye göre toplam tutarları saklayın

                        for row_num in range(self.ui.twSiparisOdeme.rowCount()):
                            adisyon_id = int(self.ui.twSiparisOdeme.item(row_num, 6).text())
                            adisyon_ids.add(adisyon_id)  # Her adisyonu bir kez ekleyin

                            # Siparişlerin toplam tutarını hesaplayın ve saklayın
                            item_price = float(self.ui.twSiparisOdeme.item(row_num, 2).text())
                            item_quantity = int(self.ui.twSiparisOdeme.item(row_num, 1).text())
                            item_total = item_price * item_quantity

                            if adisyon_id in adisyon_totals:
                                adisyon_totals[adisyon_id] += item_total
                            else:
                                adisyon_totals[adisyon_id] = item_total

                        # Her adisyon için bir ödeme işlemi oluşturun ve masa durumunu güncelleyin
                        for adisyon_id in adisyon_ids:
                            toplam_tutar = adisyon_totals[adisyon_id]  # Hesaplanmış toplam tutarı alın
                            tarih = QDateTime.currentDateTime().toString("yyyy-MM-dd HH:mm:ss")
                            servis_turu ="normal"
                            
                            print(f"\n>--- Masanın Kapatma İşlemleri Başladı ---<")
                            try:
                                # Verileri başka bir tabloya ekleyin
                                cursor.execute(
                                    "INSERT INTO hesapodemeleri (adisyonİd, odemeTuru, toplamTutar, tarih,servisTuru) VALUES (%s, %s, %s, %s, %s)",
                                    (adisyon_id, payment_type, toplam_tutar, tarih,servis_turu)
                                )
                                print(f"DB Masa {self.masa_no} Hesap Ödemeleri Alındı...")
                            except Exception as ex:
                                print("HATA",ex)
                            try:
                                # Masa durumunu güncelleyin
                                cursor.execute(
                                    "UPDATE masalar SET durum = %s, masaDurum = %s WHERE id = %s",
                                    (1, 'kapalı', self.masa_no,)
                                )
                                print(f"DB Masa {self.masa_no} Durumu Kapatıldı...")
                            except Exception as ex:
                                print("HATA",ex)
                            try:
                                # Adisyon durumunu güncelle
                                cursor.execute(
                                    "UPDATE adisyonlar SET durum = %s WHERE masaİd = %s AND servisTuru = %s",
                                    ("kapalı", self.masa_no,servis_turu,)
                                )
                                print(f"DB Masa {self.masa_no} Adisyonu Kapatıldı...")
                            except Exception as ex:
                                print("HATA:", ex)
                            try:
                                # Adisyon durumunu güncelle
                                cursor.execute(
                                    "UPDATE satislar SET durum = %s WHERE masaİd = %s AND servisTuru = %s",
                                    ("kapalı", self.masa_no,servis_turu,)
                                )
                                print(f"DB Masa {self.masa_no} Satışları Kapatıldı...")
                            except Exception as ex:
                                print("HATA:", ex)
                            print(f">--- Masanın Kapatma İşlemleri Bitti ---<")

                        # Veritabanı değişikliklerini kaydet
                        self.connection.commit()

                        # Hesap ödemesini tamamladıktan sonra, tabloyu temizle ve toplam tutarı sıfırla
                        self.ui.twSiparisOdeme.setRowCount(0)
                        self.ui.lblToplamTutar.setText("0.0")
                        self.close()

                        # Masalar sayfasına geri dondur
                        from views.frmMasalar import frmMasalar
                        self.frm_masalar = frmMasalar()
                        self.frm_masalar.show()

                    except mysql.connector.Error as err:
                        print("Hata:", err)
                    finally:
                        cursor.close()
                else:
                    print("Veritabanı bağlantısı başarısız")
            elif confirmation == QMessageBox.Cancel:
                    return
    

