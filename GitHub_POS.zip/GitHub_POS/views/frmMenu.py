from forms.frmMenuUi import Ui_frmMenu
from PyQt5 import QtWidgets
from database.connect_to_database import connect_to_database
from datetime import datetime

class frmMenu(QtWidgets.QWidget):   # Menü formusunu oluşturma
    def __init__(self, parent=None):
        super(frmMenu, self).__init__(parent)
        self.ui = Ui_frmMenu()
        self.ui.setupUi(self)
        self.showFullScreen()

        # Menüdeki butonların tıklanma olayları
        self.ui.btnMasalar.clicked.connect(self.tables_application)
        self.ui.btnCikis.clicked.connect(self.exit_applicaiton)
        self.ui.btnKilit.clicked.connect(self.back_applicant)

        # Database bağlantısını başlat
        self.connection = connect_to_database()

        # İletişim adresini gönderme
        self.ui.lblTelefon.setText("0654 454 23 34")

        # Arayüzdeki saat ve tarihi gönderme
        self.update_time_date()


    def tables_application(self):   # Masalar formunu açma
        print("Masalar'a tıklandı")
        from views.frmMasalar import frmMasalar
        self.tables = frmMasalar()
        self.tables.show()
        self.close()

    def exit_applicaiton(self):     # Uygulamayı kapatma
        print("Cıkıs'a tıklandı")
        QtWidgets.QApplication.quit()

    def back_applicant(self):      # Menü giriş sayfasına dönme
        print("Giriş'e tıklandı")
        from views.frmGiris import frmGiris
        self.tables = frmGiris()
        self.tables.show()
        self.close()

    def update_time_date(self):     # Arayüzdeki saat ve tarihi gönderme  
        simdiki_zaman = datetime.now()
        saat = simdiki_zaman.strftime("%H:%M")
        tarih = simdiki_zaman.strftime("%d %B %A")
        # tarih = self.create_history_text()   # Tarih metni oluşturan fonksiyon
        self.ui.lblSaat.setText(saat)
        self.ui.lblTarih.setText(tarih)

    def create_history_text(self):  # Tarih metni oluşturan fonksiyon
        simdiki_zaman = datetime.now()
        gunler = ["Pazar", "Pazartesi", "Salı", "Carsamba", "Perşembe", "Cuma", "Cumartesi"]
        aylar = [ "Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"]

        gun = gunler[simdiki_zaman.weekday()]
        ay = aylar[simdiki_zaman.month - 1]
        tarih_metni = f"{simdiki_zaman.day} {ay} {gun}"
        return tarih_metni