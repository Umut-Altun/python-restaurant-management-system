import mysql
from forms.frmMasalarUi import Ui_frmMasalar
from PyQt5 import QtWidgets
from database.connect_to_database import connect_to_database
from PyQt5.QtGui import QIcon, QPixmap


class frmMasalar(QtWidgets.QWidget):   # Masalar formunu oluşturma
    def __init__(self):
        super(frmMasalar, self).__init__()
        self.ui = Ui_frmMasalar()
        self.ui.setupUi(self)
        self.showFullScreen()

        # Butonlara tıklanma olayları
        self.ui.btnCikis.clicked.connect(self.exit_applicaiton)
        self.ui.btnGeri.clicked.connect(self.back_application)

        # Masa butonlarını bir diziye atama
        self.masa_buttons = [
            self.ui.btnMasa1, self.ui.btnMasa2, self.ui.btnMasa3, self.ui.btnMasa4, self.ui.btnMasa5,
            self.ui.btnMasa6, self.ui.btnMasa7, self.ui.btnMasa8, self.ui.btnMasa9, self.ui.btnMasa10,
            self.ui.btnMasa11, self.ui.btnMasa12, self.ui.btnMasa13, self.ui.btnMasa14, self.ui.btnMasa15,
            self.ui.btnMasa16, self.ui.btnMasa17, self.ui.btnMasa18, self.ui.btnMasa19, self.ui.btnMasa20,
            self.ui.btnMasa21, self.ui.btnMasa22, self.ui.btnMasa23, self.ui.btnMasa24, self.ui.btnMasa25,
            self.ui.btnMasa26, self.ui.btnMasa27, self.ui.btnMasa28,
        ]

        # Masa butonlarının tıklanma olayları
        for i, masa_buton in enumerate(self.masa_buttons, start=1):
            masa_buton.clicked.connect(lambda _, masa_num=i: self.open_order_window(f"MASA {masa_num}"))

        # Database bağlantısını başlatma
        self.connection = connect_to_database()

        # Masa elementleri doldurma
        self.tables_control()       # Masa elementlerinin kontrol edilmesi
        self.update_table_status()  # Masa durumlarının kontrol edilmesi


    def exit_applicaiton(self):     # Uygulamayı kapatma
        print("Cıkıs'a tıklandı")
        QtWidgets.QApplication.quit()

    def back_application(self):      # Menü giriş sayfasına dönme
        print("Geri'a tıklandı")
        from views.frmMenu import frmMenu
        self.tables = frmMenu()
        self.tables.show()
        self.close()

    def open_order_window(self, masa_num):  # Sipariş formunu açma
        print(f"{masa_num} butonuna tıklandı")
        from views.frmSiparis import frmSiparis
        self.order = frmSiparis(str(masa_num))
        self.order.show()
        self.close()
        print(f"Siparişler formu açıldı")

    def tables_control(self):   # Masa elementlerinin kontrol edilmesi
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                # Adisyonlar tablosudan durumu "acık" olan masaları secme
                query = "SELECT masaId, durum, tarih FROM adisyonlar WHERE durum = 'açık' AND servisTuru = 'normal'"
                cursor.execute(query)
                adisyonlar = cursor.fetchall()

                for adisyon in adisyonlar:
                    masa_id = adisyon[0]    # masa id değeri
                    masa_durum = adisyon[1]   # masa durum degeri
                    tarih = adisyon[2]  # masa tarih degeri

                    if masa_durum == "açık":
                        # masa durumu
                        label_durum = getattr(self.ui, f"lblBtnDurum_{masa_id}")
                        label_durum.setText("Dolu")
                        #masa saati
                        label_tarih = getattr(self.ui, f"lblBtnSaat_{masa_id}")
                        label_tarih.setText(tarih.strftime('%H:%M'))
                        #masa toplamı
                        toplam_fiyat = self.calculate_total_sales(masa_id)
                        label_fiyat = getattr(self.ui, f"lblBtnFiyat_{masa_id}")
                        label_fiyat.setText(f"${str(toplam_fiyat)}")

                    else:
                        label_durum = getattr(self.ui, f"lblBtnDurum_{masa_id}")
                        label_durum.setText("Boş")

                cursor.close()

            except mysql.connector.Eror as err:
                print("Hata tables_control :", err)
        else:
            print("Veritabanı bağlantısı başarısız")

    def calculate_total_sales(self, masa_id):   # Masa toplam tutarın hesaplanması
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                # Masa ID'sine göre satışların toplam tutarını hesapla
                query = (f"SELECT SUM(u.fiyat * s.adet) FROM satislar s JOIN urunler u ON s.urunId = u.id WHERE s.adisyonId = (SELECT id FROM adisyonlar WHERE masaId = '{masa_id}' AND durum = 'açık' and servisTuru = 'normal') and s.durum = 'açık'")

                cursor.execute(query)
                total_sales = cursor.fetchone()[0]
                cursor.close()

                return total_sales if total_sales else "boş"
            
            except mysql.connector.Error as err:
                print("Hata calculate_total_sales:", err)
                return "hata"
        else:
            print("Veritabanı bağlantısı başarısız")

    def update_table_status(self):  # Masa durumlarının kontrol edilmesi
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()
                query = "SELECT id, durum FROM masalar"
                cursor.execute(query)
                masa_durumlari = cursor.fetchall()
                cursor.close()

                for masa_id, masa_durumu in masa_durumlari:
                    masa_button = self.masa_buttons[masa_id - 1]

                    if masa_durumu == '1':
                        # Masa boş durumunda resmi yükle
                        image_path = f":/nmasalar/resimler/MASA/bos_masa.png"
                        pixmap = QPixmap(image_path)
                        masa_button.setIcon(QIcon(pixmap))

                    elif masa_durumu == '2':
                        # Masa dolu durumunda resmi yükle
                        image_path =  f":/nmasalar/resimler/MASA/dolu_masa.png"
                        pixmap = QPixmap(image_path)
                        masa_button.setIcon(QIcon(pixmap))

            except mysql.connector.Error as err:
                print("Hata update_table_status:", err)
        else:
            print("Veritabanı bağlantısı başarısız")
