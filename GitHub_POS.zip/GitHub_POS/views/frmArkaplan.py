from forms.frmArkaPlanUi import Ui_frmArkaPlan
from PyQt5 import QtWidgets

class frmArkaPlan(QtWidgets.QWidget):   # Arkaplan formunu oluşturma
    def __init__(self):
        super(frmArkaPlan, self).__init__()
        self.ui = Ui_frmArkaPlan()
        self.ui.setupUi(self)
        self.showFullScreen()
