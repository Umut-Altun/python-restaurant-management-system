from forms.frmSiparisUi import Ui_frmSiparis
from PyQt5 import QtWidgets
import mysql.connector
from datetime import datetime
from PyQt5.QtWidgets import QMessageBox
from database.connect_to_database import connect_to_database

class frmSiparis(QtWidgets.QWidget):   # Masalar formunu oluşturma
    def __init__(self, masa_num=None):
        super(frmSiparis, self).__init__()
        self.ui = Ui_frmSiparis()
        self.ui.setupUi(self)
        self.showFullScreen()

        #Tıklanan masanın numarasını alma
        self.ui.lblMasaNo.setText(masa_num)

        # Kategori ID'lerini butonlarla eşleştiren bir sözlük oluşturun
        category_buttons = {
            self.ui.btnAnaYemek: 1,
            self.ui.btnMakarna: 2,
            self.ui.btnSalata: 3,
            self.ui.btnDurum: 9,
            self.ui.btnArasicak: 7,
            self.ui.btnCorba: 4,
            self.ui.btnFastfood: 5,
            self.ui.btnIcecekler: 6,
            self.ui.btnTatli: 8
        }

        # Butonlara tıklama olaylarını bağla
        for button, category_id in category_buttons.items():
            button.clicked.connect(lambda _, cid=category_id: self.get_items_by_category(cid))

        # Butonlara tıklama olaylarını bağla	
        self.ui.twIcindekiler.itemClicked.connect(self.contents_table)  
        self.ui.btnSiparis.clicked.connect(self.order_application)    
        self.ui.btnOdeme.clicked.connect(self.payment_application)     
        self.ui.btnUrunSil.clicked.connect(self.order_table_delete)   
        self.ui.btnGeri.clicked.connect(self.back_application)        

        # Bağlantıyı başlat...
        self.connection = connect_to_database()


    def back_application(self):     # Geri butonuna tıklama olayı
        self.close()
        from views.frmMasalar import frmMasalar
        self.frm_masalar = frmMasalar()
        self.frm_masalar.show()

    def get_items_by_category(self, category_id):   # Kategoriye göre ürünleri getirme
        if self.connection is not None:
            try:
                cursor = self.connection.cursor() 

                # urunler tablosundan kategoriId'ye göre ürünleri seçin
                query = "SELECT id, urunAd, fiyat FROM urunler WHERE kategoriId = %s"
                cursor.execute(query, (category_id,))
                items = cursor.fetchall()

                # TableView'deki modeli temizleyin
                self.ui.twIcindekiler.setRowCount(0)

                # Verileri TableView'e ekleme
                for row_num, (urunAd, fiyat, id) in enumerate(items):
                    self.ui.twIcindekiler.insertRow(row_num)
                    self.ui.twIcindekiler.setItem(row_num, 0, QtWidgets.QTableWidgetItem(str(fiyat)))
                    self.ui.twIcindekiler.setItem(row_num, 1, QtWidgets.QTableWidgetItem(str(id)))
                    self.ui.twIcindekiler.setItem(row_num, 2, QtWidgets.QTableWidgetItem(str(urunAd)))

                cursor.close()

            except mysql.connector.Eror as err:
                print("Hata get_items_by_category :", err)
        else:
            print("Veritabanı bağlantısı başarısız")

    def contents_table(self, item):    # Ürünleri içerik tablosuna aktarma
        # Seçilen ürünün bilgilerini al
        selected_row = item.row()
        urun_fiyati = self.ui.twIcindekiler.item(selected_row, 0).text()
        urun_id = self.ui.twIcindekiler.item(selected_row, 1).text()
        urun_notu = ""
        urun_adi = self.ui.twIcindekiler.item(selected_row, 2).text()

        # twSiparis QTableWidget'deki mevcut satırları kontrol et
        for row in range(self.ui.twSiparis.rowCount()):
            existing_item = self.ui.twSiparis.item(row, 4)
            if existing_item and existing_item.text() == urun_adi:
                # Ürün zaten listede, adet sütunundaki sayıyı artır
                adet_item = self.ui.twSiparis.item(row, 1)
                current_adet = int(adet_item.text()) if adet_item else 0
                new_adet = current_adet + 1
                adet_item = QtWidgets.QTableWidgetItem(str(new_adet))
                self.ui.twSiparis.setItem(row, 1, adet_item)
                return

        # twSiparis QTableWidget'e yeni bir satır ekleyin
        row_position = self.ui.twSiparis.rowCount()
        self.ui.twSiparis.insertRow(row_position)

        # Ürün bilgilerini twSiparis QTableWidget'e yerleştirin
        self.ui.twSiparis.setItem(row_position, 0, QtWidgets.QTableWidgetItem(urun_fiyati))
        self.ui.twSiparis.setItem(row_position, 3, QtWidgets.QTableWidgetItem(urun_id))
        self.ui.twSiparis.setItem(row_position, 4, QtWidgets.QTableWidgetItem(urun_adi))
        self.ui.twSiparis.setItem(row_position, 2, QtWidgets.QTableWidgetItem(urun_notu))
    

    def order_application(self):    # Sipariş verme işlemi
        # twSiparis QTableWidget'deki ürün varlığını kontrol edin
        for col in range(self.ui.twSiparis.columnCount()):
            item = self.ui.twSiparis.item(0, 0)
            if item is None or item.text() == "":
                QMessageBox.critical(self, "Hata", "Lütfen bir sipariş ekleyin.")
                return     

        # twSiparis QTableWidget'deki ürün adetini kontrol edin
        for row in range(self.ui.twSiparis.rowCount()):
            adet_item = self.ui.twSiparis.item(row, 1)
            if adet_item is None or adet_item.text() == "":
                QMessageBox.critical(self, "Hata", "Lütfen her siparişin adetini girin.")
                return 

        # Sipariş verme işlemleri        
        table_number = self.ui.lblMasaNo.text()  # Masanın numarasını al
        table_number = table_number[5:]  # Masa numarasını uygun formatta al
        print(f"Masanın numarası: {table_number}")
        adisyon_id = self.check_table_status(table_number)   # Masanın durumunu kontrol eden fonksiyonu çağır

        print(f"\n<--- Masanın Açma İşlemleri Başladı --->")
        # Siparişlerin varlığını ve yokluğunu kontrol edin
        if adisyon_id is not None:
            # Mevcut bir adisyon var, siparişleri bu adisyon üzerine ekleyin
            self.add_order_to_existing_adisyon(adisyon_id)
        else:
            # Mevcut bir adisyon yok, yeni bir adisyon oluşturun ve siparişleri ekleyin
            adisyon_id = self.create_new_adisyon(table_number)
            self.add_order_to_existing_adisyon(adisyon_id)
        
        self.update_table_status(table_number)  # Masa durumunu güncelleyen fonksiyonu çağır
        print(f"<--- Masanın Açma İşlemleri Bitti --->")

        # Tekrardan masalar formuna dön
        self.close()
        from views.frmMasalar import frmMasalar
        self.frm_masalar = frmMasalar()
        self.frm_masalar.show()

    def check_table_status(self, table_number):  # Masa durumunu kontrol etme
        connection = self.connection
        if connection is not None:
            try:
                cursor = connection.cursor()

                # Masalar tablosundan belirli bir masa numarasının adisyon durumunu kontrol edin
                query = "SELECT id FROM adisyonlar WHERE masaİd = %s AND durum = 'açık' AND servisTuru = 'normal'"
                cursor.execute(query, (table_number,))
                result = cursor.fetchone()

                cursor.close()

                if result:
                    return result[0]  # Mevcut bir adisyon bulunduysa adisyon id'sini döndürün
                else:
                    return None  # Mevcut bir adisyon yoksa None döndürün
            except mysql.connector.Error as err:
                print("Hata check_table_status:", err)

    def update_table_status(self, table_number):   # Masa durumunu güncelleme
            connection = self.connection
            if connection is not None:
                try:
                    cursor = connection.cursor()
                    
                    # Masalar tablosundaki belirli bir masa numarasının durumunu ve masaDurum sütununu güncelle
                    update_query = "UPDATE masalar SET durum = 2, masaDurum = 'açık' WHERE id = %s"
                    cursor.execute(update_query, (table_number,))
                    
                    connection.commit()  # Değişiklikleri veritabanına kaydet
                    cursor.close()
                    
                    print(f"Masa {table_number}'in durumu güncellendi.")
                except mysql.connector.Error as err:
                    print("Hata update_table:", err)

    def create_new_adisyon(self, table_number):  # Yeni adisyon oluşturma
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                # Yeni bir adisyon oluşturun
                insert_query = "INSERT INTO adisyonlar (masaİd, tarih, durum,servisTuru) VALUES (%s, %s, %s, %s)"
                current_datetime = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                cursor.execute(insert_query, (table_number, current_datetime, 'açık','normal'))
                self.connection.commit()

                # Oluşturulan adisyonun id'sini alın
                query = "SELECT LAST_INSERT_ID()"
                cursor.execute(query)
                adisyon_id = cursor.fetchone()[0]

                cursor.close()

                print(f"Masa {table_number} için yeni bir adisyon oluşturuldu.")
                return adisyon_id
            except mysql.connector.Error as err:
                print("Hata crate_new:", err)
        else:
            print("Veritabanı bağlantısı başarısız")
    
    def add_order_to_existing_adisyon(self, adisyon_id):    # Mevcut adisyona sipariş ekleme
        table_number = self.ui.lblMasaNo.text()  # Masanın numarasını al
        table_number = table_number[5:]  # Masa numarasını uygun biçimde alın

        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                for satir in range(self.ui.twSiparis.rowCount()):
                    # Sipariş detaylarını tablodan alın
                    urun_id = int(self.ui.twSiparis.item(satir, 4).text())
                    adet = int(self.ui.twSiparis.item(satir, 1).text())
                    urun_not = str(self.ui.twSiparis.item(satir, 2).text())

                    # Şu anki tarih ve saat bilgisini alın
                    tarih_ve_saat = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    servıs_turu = "normal"
                    durum = "açık"

                    # Siparişi "satislar" tablosuna ekleyin
                    ekleme_sorgusu = "INSERT INTO satislar (adisyonİd, urunİd, masaİd, adet, servisTuru, durum, satisZamani,urunNot) VALUES (%s,%s, %s, %s, %s, %s, %s,%s)"
                    cursor.execute(ekleme_sorgusu, (adisyon_id, urun_id, table_number, adet, servıs_turu, durum, tarih_ve_saat,urun_not))

                    self.connection.commit()

                cursor.close()
                print(f"Masa {table_number} için siparişler eklendi.")

            except mysql.connector.Error as hata:
                print("Hata add_order:", hata)
        else:
            print("Veritabanı bağlantısı başarısız")


    def payment_application(self):  # Ödeme işlemi
        masa_no = self.ui.lblMasaNo.text()
        self.close()
        from views.frmOdeme import frmOdeme
        self.frm_odeme = frmOdeme(masa_no)
        self.frm_odeme.show()

    def order_table_delete(self):   # Sipariş tablosundan ürün silme
        # Seçili öğeyi alın
        selected_items = self.ui.twSiparis.selectedItems()
        if not selected_items:
            return

        # Seçili öğenin bulunduğu satırı bulun
        selected_row = selected_items[0].row()

        # Tablodan seçili satırı kaldırın
        self.ui.twSiparis.removeRow(selected_row)
  















