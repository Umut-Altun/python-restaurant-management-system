import sys
from PyQt5 import QtWidgets
from views.frmGiris import frmGiris
from views.frmArkaplan import frmArkaPlan

def app():
    print("Uygulama başlatılıyor...")
    app = QtWidgets.QApplication(sys.argv)
    win_bg = frmArkaPlan()
    win = frmGiris()
    win_bg.show()
    win.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    app() 