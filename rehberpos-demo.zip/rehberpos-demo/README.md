# Restoran Yönetim Sistemi

Bu proje, bir restoranın çeşitli işlevlerini yönetmek için geliştirilmiş bir restoran yönetim sistemidir. Kullanıcı arayüzü PyQt5 ile oluşturulmuş olup, veritabanı işlemleri MySQL kullanılarak gerçekleştirilmiştir.

## Özellikler

- Kullanıcı girişi ve yetkilendirme
- Masa yönetimi
- Menü yönetimi
- Müşteri yönetimi
- Adisyon ve ödeme işlemleri
- Personel hareketleri kaydı

## Kurulum

### Gereksinimler

- Python 3.6+
- MySQL Server
- PyQt5
- mysql-connector-python

### Adımlar

1. Bu projeyi klonlayın veya indirin:
    ```sh
    git clone https://github.com/kullaniciadi/restoran-yonetim-sistemi.git
    cd restoran-yonetim-sistemi
    ```

2. Gerekli Python paketlerini yükleyin:
    ```sh
    pip install -r requirements.txt
    ```

3. MySQL veritabanını oluşturun ve [restorant.sql](http://_vscodecontentref_/1) dosyasını kullanarak veritabanını içe aktarın:
    ```sh
    mysql -u root -p restorant < dumps/restorant.sql
    ```

4. `config.ini` dosyasını oluşturun ve veritabanı bağlantı bilgilerinizi girin:
    ```ini
    [database]
    host = localhost
    user = root
    password = password
    database = restorant
    ```

## Kullanım

Uygulamayı başlatmak için [main.py](http://_vscodecontentref_/2) dosyasını çalıştırın:
```sh
python main.py
```

### Proje Yapısı

rehberPos/
├── database/
│   ├── __init__.py
│   └── connect_to_database.py
├── forms/
│   ├── __init__.py
│   ├── frmArkaPlanUi.py
│   ├── frmGirisUi.py
│   ├── frmMenuUi.py
│   └── ...
├── views/
│   ├── __init__.py
│   ├── frmArkaPlan.py
│   ├── frmGiris.py
│   ├── frmMenu.py
│   └── ...
├── resimler/
│   └── ...
├── dumps/
│   └── restorant.sql
├── main.py
├── requirements.txt
└── README.md