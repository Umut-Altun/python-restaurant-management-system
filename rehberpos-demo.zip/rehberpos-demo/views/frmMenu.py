from PyQt5 import QtWidgets
from forms.frmMenuUi import Ui_frmMenu
from PyQt5.QtCore import QTimer
from datetime import datetime
from database.connect_to_database import connect_to_database


class frmMenu(QtWidgets.QMainWindow):
    def __init__(self):
        super(frmMenu, self).__init__()
        self.ui = Ui_frmMenu()
        self.ui.setupUi(self) 
        self.showFullScreen()
        self.ui.lblTelefon.setText("0553 543 ** **")

        # Butonlara tıklama olaylarını bağla	
        self.ui.btnMasalar.clicked.connect(self.tables_application)
        self.ui.btnCikis.clicked.connect(self.exit_application)
        self.ui.btnKilit.clicked.connect(self.back_application)

        # Database bağlantısı başlat...
        self.connection = connect_to_database()

        # Başlangıçta saat ve tarihi güncelle
        self.guncelle_saat_tarih()
        timer = QTimer(self)
        timer.timeout.connect(self.guncelle_saat_tarih)
        timer.start(1000) 

    def tarih_metnini_olustur(self):    #tarih ve günü yazdırma
        su_an = datetime.now()
        gunler = ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar"]
        aylar = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"]
        
        gun = gunler[su_an.weekday()]  # haftanın günü
        ay = aylar[su_an.month - 1]   # ayın adı
        tarih_metni = "{} {} {}".format(su_an.day, ay, gun)
        return tarih_metni

    def guncelle_saat_tarih(self):  #saat ve tarihi güncelleme
        su_an = datetime.now()
        saat_metni = su_an.strftime("%H:%M")  # Sadece saat ve dakika
        tarih_metni = self.tarih_metnini_olustur()
        self.ui.lblSaat.setText(saat_metni)
        self.ui.lblTarih.setText(tarih_metni)

    def tables_application(self):   #masaları açma
        self.close()
        from views.frmMasalar import frmMasalar
        self.frm_masalar = frmMasalar()
        self.frm_masalar.show()

    def exit_application(self): #uygulamayı kapatma
        QtWidgets.QApplication.quit()

    def back_application(self): #geri dönme
        self.close()
        from views.frmGiris import frmGiris
        self.frm_giris = frmGiris()
        self.frm_giris.show()

