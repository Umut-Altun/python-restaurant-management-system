from PyQt5 import QtWidgets
import mysql.connector
from database.connect_to_database import connect_to_database
from PyQt5.QtWidgets import QMessageBox
from datetime import datetime
from views.frmMenu import frmMenu
from forms.frmArkaPlanUi import Ui_frmArkaPlan
from forms.frmGirisUi import Ui_frmGiris

class frmArkaPlan(QtWidgets.QMainWindow):   # frmArkaPlan adında bir QMainWindow sınıfı oluşturduk. 
    def __init__(self):
        super(frmArkaPlan, self).__init__() 
        self.ui = Ui_frmArkaPlan()
        self.ui.setupUi(self)
        self.showFullScreen()

class frmGiris(QtWidgets.QMainWindow):  # frmGiris adında bir QMainWindow sınıfı oluşturduk.	
    def __init__(self):
        super(frmGiris, self).__init__() 
        self.ui = Ui_frmGiris()
        self.ui.setupUi(self)
        self.showFullScreen()

        # Butonlara tıklama olaylarını bağla
        self.ui.btnGiris.clicked.connect(self.login_button_clicked)
        self.ui.btnCikis.clicked.connect(self.exit_application)
        
        # Database bağlantısı başlat...
        self.connection = connect_to_database()  

    def check_user_login(self, username, password): # Kullanıcı adı ve şifre kontrolü
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()
                query = "SELECT * FROM personeller WHERE ad = %s AND sifre = %s"
                cursor.execute(query, (username, password))
                user = cursor.fetchone()
                cursor.close()
                if user:
                    return True
            except mysql.connector.Error as err:
                print("Veritabanı Hatası check_user_login:", err)
        return False

    def login_button_clicked(self):     # Giriş butonuna tıklandığında yapılacak işlemler
        username = self.ui.cbKullanici.text()
        password = self.ui.lnSifre.text()

        if self.check_user_login(username, password):
            print(f"| *{username}* İçin Giriş Başarılı. Hoşgeldin!")
            self.user_login_record()
            self.open_menu_window()
            self.close()
        else:
            self.show_error_message("Hata", "Kullanıcı adı veya şifre yanlış!")

    def show_error_message(self, title, message):   # Hata mesajı göster
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Critical)
        msg.setWindowTitle(title)
        msg.setText(message)
        msg.exec_()

    def exit_application(self):    # Uygulamayı kapat
        if self.connection:
            self.connection.close()
        QtWidgets.QApplication.quit()

    def open_menu_window(self):    # Menü penceresini aç
        self.frm_menu = frmMenu()
        self.frm_menu.show()
    
    def user_login_record(self):    # Kullanıcı giriş kaydı
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()
                login_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                selected_username = self.ui.cbKullanici.text()

                insert_query = "INSERT INTO personelhareketleri (personelAd, durum, tarih) VALUES (%s, %s, %s)"
                cursor.execute(insert_query, (selected_username, "Başarılı", login_time))

                self.connection.commit()
                cursor.close()
            except mysql.connector.Error as err:
                print("Veritabanı Hatası user_login_record:", err)