import sys
import os
import logging

# Proje dizinini sys.path'e ekleyin
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from PyQt5 import QtWidgets
from views.frmGiris import frmGiris, frmArkaPlan

# Logging yapılandırması
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def app():
    logging.info("Uygulama başlatılıyor...")
    app = QtWidgets.QApplication(sys.argv)
    winn = frmArkaPlan()
    win = frmGiris()
    winn.show()
    win.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    app()