-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: localhost    Database: restorant
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `adisyonlar`
--

DROP TABLE IF EXISTS `adisyonlar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `adisyonlar` (
  `id` int NOT NULL AUTO_INCREMENT,
  `masaİd` int NOT NULL,
  `tarih` datetime NOT NULL,
  `durum` varchar(15) NOT NULL,
  `servisTuru` varchar(15) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adisyonlar`
--

LOCK TABLES `adisyonlar` WRITE;
/*!40000 ALTER TABLE `adisyonlar` DISABLE KEYS */;
INSERT INTO `adisyonlar` VALUES (1,1,'2024-11-03 15:45:06','kapalı','normal'),(2,2,'2024-11-03 16:44:46','kapalı','normal'),(3,1,'2024-11-15 21:06:54','kapalı','normal'),(4,1,'2024-11-15 21:08:09','kapalı','paket'),(5,12,'2024-11-15 21:10:19','kapalı','paket'),(6,3,'2024-11-16 22:47:19','kapalı','normal'),(7,19,'2024-11-16 22:47:34','kapalı','normal'),(8,20,'2024-11-16 22:47:44','kapalı','normal'),(9,8,'2024-11-16 22:49:15','kapalı','normal'),(10,7,'2024-11-16 22:50:07','kapalı','paket'),(11,3,'2024-12-10 21:06:35','kapalı','normal'),(12,4,'2024-12-10 21:06:38','kapalı','normal'),(13,1,'2024-12-20 18:37:17','kapalı','normal'),(14,1,'2024-12-20 20:04:19','kapalı','normal'),(15,1,'2024-12-20 20:04:43','kapalı','normal'),(16,1,'2024-12-20 21:08:28','kapalı','normal'),(17,4,'2024-12-20 21:39:34','kapalı','normal'),(18,1,'2024-12-20 21:43:31','kapalı','normal'),(19,19,'2024-12-20 21:43:43','kapalı','normal'),(20,4,'2024-12-21 00:09:03','kapalı','normal'),(21,4,'2024-12-21 15:53:45','kapalı','normal'),(22,4,'2024-12-21 16:17:07','kapalı','normal'),(23,13,'2024-12-21 16:19:39','kapalı','normal'),(24,1,'2024-12-21 16:22:31','kapalı','paket'),(25,4,'2024-12-21 16:24:28','kapalı','normal'),(26,5,'2024-12-22 15:24:24','kapalı','normal'),(27,1,'2024-12-22 16:52:34','kapalı','normal'),(28,3,'2024-12-22 16:52:38','kapalı','normal'),(29,12,'2024-12-22 16:52:43','kapalı','normal'),(30,13,'2024-12-22 16:52:47','kapalı','normal'),(31,21,'2024-12-22 16:52:51','kapalı','normal'),(32,16,'2024-12-22 16:52:55','kapalı','normal'),(33,8,'2024-12-22 16:53:01','kapalı','normal'),(34,25,'2024-12-22 16:53:15','kapalı','normal'),(35,1,'2024-12-22 16:55:20','kapalı','paket'),(36,6,'2024-12-22 16:57:30','kapalı','paket'),(37,6,'2024-12-22 17:15:11','kapalı','normal'),(38,4,'2024-12-22 17:34:49','kapalı','normal'),(39,4,'2024-12-23 11:20:07','kapalı','normal'),(40,1,'2025-01-02 13:07:09','kapalı','normal'),(41,1,'2025-01-06 10:36:22','kapalı','normal'),(42,8,'2025-01-06 10:36:38','kapalı','normal'),(43,2,'2025-01-06 10:37:43','kapalı','normal'),(44,10,'2025-01-06 10:37:58','kapalı','normal'),(45,5,'2025-01-06 10:45:04','kapalı','normal'),(46,20,'2025-01-06 10:45:09','kapalı','normal'),(47,15,'2025-01-06 10:45:14','kapalı','normal'),(48,10,'2025-01-06 10:45:19','kapalı','normal'),(49,2,'2025-01-06 12:25:49','kapalı','normal'),(50,4,'2025-01-06 20:06:41','kapalı','normal'),(51,1,'2025-01-25 11:43:20','kapalı','normal'),(52,2,'2025-01-27 10:38:16','kapalı','normal'),(53,1,'2025-02-10 02:31:26','kapalı','normal'),(54,2,'2025-02-10 02:44:45','kapalı','normal'),(55,3,'2025-02-10 02:46:39','kapalı','normal'),(56,3,'2025-02-10 02:50:28','kapalı','normal'),(57,5,'2025-02-10 02:51:32','kapalı','normal'),(58,1,'2025-02-11 20:41:43','kapalı','normal'),(59,2,'2025-02-11 20:43:11','kapalı','paket'),(60,12,'2025-02-11 20:44:24','kapalı','normal');
/*!40000 ALTER TABLE `adisyonlar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hesapodemeleri`
--

DROP TABLE IF EXISTS `hesapodemeleri`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hesapodemeleri` (
  `id` int NOT NULL AUTO_INCREMENT,
  `adisyonİd` int NOT NULL,
  `odemeTuru` varchar(15) NOT NULL,
  `toplamTutar` decimal(10,2) NOT NULL,
  `tarih` datetime NOT NULL,
  `servisTuru` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hesapodemeleri`
--

LOCK TABLES `hesapodemeleri` WRITE;
/*!40000 ALTER TABLE `hesapodemeleri` DISABLE KEYS */;
INSERT INTO `hesapodemeleri` VALUES (1,1,'NAKİT',87.00,'2024-11-03 15:46:35','normal'),(2,2,'NAKİT',44.00,'2024-11-03 16:45:08','normal'),(3,3,'NAKİT',452.00,'2024-11-15 21:07:09','normal'),(4,4,'DIGER',605.00,'2024-11-15 21:08:35','paket'),(5,5,'DIGER',330.00,'2024-11-15 21:10:29','paket'),(6,6,'NAKİT',60.00,'2024-11-16 22:47:55','normal'),(7,7,'NAKİT',852.00,'2024-11-16 22:48:03','normal'),(8,8,'KART',172.00,'2024-11-16 22:48:10','normal'),(9,9,'NAKİT',144.00,'2024-11-16 22:49:28','normal'),(10,10,'DIGER',232.00,'2024-11-16 22:50:16','paket'),(11,12,'NAKİT',132.00,'2024-12-10 21:06:46','normal'),(12,11,'KART',382.00,'2024-12-10 21:06:51','normal'),(13,13,'NAKİT',579.00,'2024-12-20 18:37:24','normal'),(14,14,'KART',662.00,'2024-12-20 20:04:29','normal'),(15,15,'NAKİT',657.00,'2024-12-20 20:04:48','normal'),(16,16,'NAKİT',1171.00,'2024-12-20 21:08:33','normal'),(17,17,'KART',424.00,'2024-12-20 21:39:38','normal'),(18,18,'KART',349.00,'2024-12-20 21:43:36','normal'),(19,19,'NAKİT',557.00,'2024-12-20 21:43:47','normal'),(20,20,'KART',353.00,'2024-12-21 00:09:09','normal'),(21,21,'NAKİT',111.00,'2024-12-21 15:53:50','normal'),(22,24,'DIGER',202.00,'2024-12-21 16:22:40','paket'),(23,22,'NAKİT',340.00,'2024-12-21 16:22:49','normal'),(24,23,'NAKİT',16.00,'2024-12-21 16:22:59','normal'),(25,25,'NAKİT',397.00,'2024-12-21 16:25:26','normal'),(26,26,'NAKİT',480.00,'2024-12-22 15:24:37','normal'),(27,29,'KART',549.00,'2024-12-22 16:53:46','normal'),(28,28,'NAKİT',125.00,'2024-12-22 16:53:51','normal'),(29,31,'NAKİT',605.00,'2024-12-22 16:53:55','normal'),(30,30,'KART',10.00,'2024-12-22 16:54:00','normal'),(31,34,'NAKİT',10.00,'2024-12-22 16:54:08','normal'),(32,32,'NAKİT',98.00,'2024-12-22 16:54:13','normal'),(33,33,'KART',363.00,'2024-12-22 16:54:16','normal'),(34,27,'NAKİT',476.00,'2024-12-22 16:54:20','normal'),(35,35,'DIGER',99.00,'2024-12-22 16:55:26','paket'),(36,36,'DIGER',99.00,'2024-12-22 16:57:36','paket'),(37,37,'KART',5606.00,'2024-12-22 17:15:17','normal'),(38,38,'KART',636.00,'2024-12-22 17:34:12','normal'),(39,39,'NAKİT',12.00,'2024-12-23 11:20:15','normal'),(40,40,'KART',143.00,'2025-01-02 13:27:10','normal'),(41,42,'NAKİT',162.00,'2025-01-06 10:37:39','normal'),(42,44,'NAKİT',128.00,'2025-01-06 10:38:08','normal'),(43,43,'NAKİT',336.00,'2025-01-06 12:25:36','normal'),(44,48,'KART',171.00,'2025-01-06 20:06:46','normal'),(45,49,'KART',113.00,'2025-01-06 20:06:50','normal'),(46,41,'NAKİT',302.00,'2025-01-06 20:06:55','normal'),(47,50,'KART',318.00,'2025-01-06 20:07:00','normal'),(48,45,'KART',290.00,'2025-01-06 20:07:06','normal'),(49,46,'KART',166.00,'2025-01-06 20:07:12','normal'),(50,47,'KART',209.00,'2025-01-06 20:07:19','normal'),(51,51,'KART',76.00,'2025-02-10 02:30:38','normal'),(52,52,'NAKİT',131.00,'2025-02-10 02:30:46','normal'),(53,53,'KART',620.00,'2025-02-10 02:31:56','normal'),(54,54,'KART',88.00,'2025-02-10 02:45:17','normal'),(55,55,'KART',76.00,'2025-02-10 02:46:43','normal'),(56,56,'KART',20.00,'2025-02-10 02:50:39','normal'),(57,57,'KART',32.00,'2025-02-10 02:51:36','normal'),(58,58,'KART',543.00,'2025-02-11 20:42:08','normal'),(59,59,'DIGER',262.00,'2025-02-11 20:43:19','paket'),(60,60,'KART',9756.00,'2025-02-11 20:44:28','normal');
/*!40000 ALTER TABLE `hesapodemeleri` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kategoriler`
--

DROP TABLE IF EXISTS `kategoriler`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kategoriler` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kategoriAdi` varchar(45) NOT NULL,
  `aciklama` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kategoriler`
--

LOCK TABLES `kategoriler` WRITE;
/*!40000 ALTER TABLE `kategoriler` DISABLE KEYS */;
INSERT INTO `kategoriler` VALUES (1,'Ana Yemek','-'),(2,'Makarna','-'),(3,'Salata','-'),(4,'Çorba','-'),(5,'FastFood','-'),(6,'İçecek','-'),(7,'AraSıcak','-'),(8,'Tatlı','-'),(9,'Dürüm','-');
/*!40000 ALTER TABLE `kategoriler` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `masalar`
--

DROP TABLE IF EXISTS `masalar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `masalar` (
  `id` int NOT NULL AUTO_INCREMENT,
  `durum` varchar(15) NOT NULL,
  `masaDurum` varchar(15) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `masalar`
--

LOCK TABLES `masalar` WRITE;
/*!40000 ALTER TABLE `masalar` DISABLE KEYS */;
INSERT INTO `masalar` VALUES (1,'1','kapalı'),(2,'1','kapalı'),(3,'1','kapalı'),(4,'1','kapalı'),(5,'1','kapalı'),(6,'1','kapalı'),(7,'1','kapalı'),(8,'1','kapalı'),(9,'1','kapali'),(10,'1','kapalı'),(11,'1','kapalı'),(12,'1','kapalı'),(13,'1','kapalı'),(14,'1','kapali'),(15,'1','kapalı'),(16,'1','kapalı'),(17,'1','kapali'),(18,'1','kapali'),(19,'1','kapalı'),(20,'1','kapalı'),(21,'1','kapalı'),(22,'1','kapalı'),(23,'1','kapali'),(24,'1','kapali'),(25,'1','kapalı'),(26,'1','kapalı'),(27,'1','kapalı'),(28,'1','kapalı');
/*!40000 ALTER TABLE `masalar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `musteriler`
--

DROP TABLE IF EXISTS `musteriler`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `musteriler` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ad` varchar(15) NOT NULL,
  `soyad` varchar(15) NOT NULL,
  `adres` varchar(45) NOT NULL,
  `telefon` varchar(11) NOT NULL,
  `ilkSiparis` varchar(45) DEFAULT NULL,
  `siparisAdet` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `musteriler`
--

LOCK TABLES `musteriler` WRITE;
/*!40000 ALTER TABLE `musteriler` DISABLE KEYS */;
INSERT INTO `musteriler` VALUES (9,'hakan','uzun','tekırdag','05647481212',NULL,NULL),(23,'umut','altun','ankara','55553455555',NULL,NULL);
/*!40000 ALTER TABLE `musteriler` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paketmasalar`
--

DROP TABLE IF EXISTS `paketmasalar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `paketmasalar` (
  `id` int NOT NULL AUTO_INCREMENT,
  `durum` varchar(15) NOT NULL,
  `masaDurum` varchar(15) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paketmasalar`
--

LOCK TABLES `paketmasalar` WRITE;
/*!40000 ALTER TABLE `paketmasalar` DISABLE KEYS */;
INSERT INTO `paketmasalar` VALUES (1,'1','kapalı'),(2,'1','kapalı'),(3,'1','kapalı'),(4,'1','kapalı'),(5,'1','kapalı'),(6,'1','kapalı'),(7,'1','kapalı'),(8,'1','kapalı'),(9,'1','kapalı'),(10,'1','kapalı'),(11,'1','kapali'),(12,'1','kapalı'),(13,'1','kapali'),(14,'1','kapali'),(15,'1','kapalı'),(16,'1','kapali'),(17,'1','kapali'),(18,'1','kapali'),(19,'1','kapalı'),(20,'1','kapalı'),(21,'1','kapali'),(22,'1','kapalı'),(23,'1','kapali'),(24,'1','kapali'),(25,'1','kapali'),(26,'1','kapali'),(27,'1','kapali'),(28,'1','kapalı');
/*!40000 ALTER TABLE `paketmasalar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paketsiparisler`
--

DROP TABLE IF EXISTS `paketsiparisler`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `paketsiparisler` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ad` varchar(25) NOT NULL,
  `soyad` varchar(25) NOT NULL,
  `adres` varchar(45) NOT NULL,
  `telefon` varchar(15) NOT NULL,
  `odemeTuru` varchar(15) NOT NULL,
  `durum` varchar(15) NOT NULL,
  `masaNo` varchar(15) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paketsiparisler`
--

LOCK TABLES `paketsiparisler` WRITE;
/*!40000 ALTER TABLE `paketsiparisler` DISABLE KEYS */;
INSERT INTO `paketsiparisler` VALUES (1,'hakan','uzun','tekırdag','05647483868','NAKİT','kapalı','Paket 1'),(2,'nacıye','demir','antep','0574486433','NAKİT','kapalı','Paket 12'),(3,'umut','altun','ankaara','05537841221','KART','kapalı','Paket 7'),(4,'umut','altun','ankaara','05537841221','NAKİT','kapalı','Paket 1'),(5,'umut','altun','ankaara','05537841221','KART','kapalı','Paket 1'),(6,'berat','varool','ankar sıncan ansray ','05342321111','NAKİT','kapalı','Paket 6'),(7,'umut','altun','ankara','55553455555','NAKİT','kapalı','Paket 2');
/*!40000 ALTER TABLE `paketsiparisler` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personelhareketleri`
--

DROP TABLE IF EXISTS `personelhareketleri`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personelhareketleri` (
  `id` int NOT NULL AUTO_INCREMENT,
  `personelAd` varchar(45) NOT NULL,
  `durum` varchar(15) NOT NULL,
  `tarih` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personelhareketleri`
--

LOCK TABLES `personelhareketleri` WRITE;
/*!40000 ALTER TABLE `personelhareketleri` DISABLE KEYS */;
INSERT INTO `personelhareketleri` VALUES (1,'admin','Başarılı','2024-06-13 00:47:58'),(2,'admin','Başarılı','2024-06-14 21:41:58'),(3,'admin','Başarılı','2024-06-16 20:52:33'),(4,'admin','Başarılı','2024-06-16 20:55:27'),(5,'admin','Başarılı','2024-06-26 17:57:45'),(6,'admin','Başarılı','2024-06-26 18:09:17'),(7,'admin','Başarılı','2024-07-26 22:58:31'),(8,'admin','Başarılı','2024-07-26 23:00:51'),(9,'admin','Başarılı','2024-07-26 23:05:56'),(10,'admin','Başarılı','2024-11-01 12:54:42'),(11,'admin','Başarılı','2024-11-01 12:57:43'),(12,'admin','Başarılı','2024-11-01 15:41:25'),(13,'admin','Başarılı','2024-11-03 15:34:13'),(14,'umut','Başarılı','2024-11-03 15:44:57'),(15,'admin','Başarılı','2024-11-03 15:46:21'),(16,'admin','Başarılı','2024-11-03 16:44:29'),(17,'umut','Başarılı','2024-11-15 21:06:20'),(18,'admin','Başarılı','2024-11-15 21:06:42'),(19,'admin','Başarılı','2024-11-16 22:45:43'),(20,'admin','Başarılı','2024-12-10 21:06:22'),(21,'admin','Başarılı','2024-12-16 17:47:59'),(22,'admin','Başarılı','2024-12-20 18:36:30'),(23,'admin','Başarılı','2024-12-20 18:37:04'),(24,'admin','Başarılı','2024-12-20 18:37:54'),(25,'admin','Başarılı','2024-12-20 19:47:36'),(26,'admin','Başarılı','2024-12-20 20:03:59'),(27,'umut','Başarılı','2024-12-20 20:05:31'),(28,'admin','Başarılı','2024-12-20 20:59:02'),(29,'admin','Başarılı','2024-12-20 21:03:41'),(30,'admin','Başarılı','2024-12-20 21:04:28'),(31,'admin','Başarılı','2024-12-20 21:08:16'),(32,'admin','Başarılı','2024-12-20 21:29:00'),(33,'admin','Başarılı','2024-12-20 21:29:51'),(34,'admin','Başarılı','2024-12-20 21:33:11'),(35,'admin','Başarılı','2024-12-20 21:39:28'),(36,'admin','Başarılı','2024-12-20 21:43:24'),(37,'admin','Başarılı','2024-12-20 22:26:09'),(38,'admin','Başarılı','2024-12-20 22:27:02'),(39,'admin','Başarılı','2024-12-21 00:08:55'),(40,'admin','Başarılı','2024-12-21 15:53:39'),(41,'admin','Başarılı','2024-12-21 16:07:29'),(42,'admin','Başarılı','2024-12-21 16:16:50'),(43,'admin','Başarılı','2024-12-21 16:17:53'),(44,'admin','Başarılı','2024-12-21 16:18:03'),(45,'admin','Başarılı','2024-12-21 16:20:14'),(46,'admin','Başarılı','2024-12-22 15:07:13'),(47,'admin','Başarılı','2024-12-22 15:23:57'),(48,'admin','Başarılı','2024-12-22 16:52:28'),(49,'admin','Başarılı','2024-12-22 17:13:53'),(50,'admin','Başarılı','2024-12-22 17:32:18'),(51,'admin','Başarılı','2024-12-22 17:33:11'),(52,'admin','Başarılı','2024-12-23 11:19:58'),(53,'admin','Başarılı','2025-01-02 13:07:04'),(54,'admin','Başarılı','2025-01-02 13:27:04'),(55,'admin','Başarılı','2025-01-02 14:04:43'),(56,'admin','Başarılı','2025-01-02 14:06:46'),(57,'admin','Başarılı','2025-01-02 14:07:43'),(58,'admin','Başarılı','2025-01-02 14:10:21'),(59,'admin','Başarılı','2025-01-02 14:12:05'),(60,'admin','Başarılı','2025-01-06 10:18:14'),(61,'admin','Başarılı','2025-01-06 10:21:41'),(62,'admin','Başarılı','2025-01-06 10:36:26'),(63,'admin','Başarılı','2025-01-06 10:36:08'),(64,'admin','Başarılı','2025-01-06 10:44:59'),(65,'admin','Başarılı','2025-01-06 11:18:25'),(66,'admin','Başarılı','2025-01-06 12:24:46'),(67,'admin','Başarılı','2025-01-06 20:06:36'),(68,'admin','Başarılı','2025-01-25 11:42:49'),(69,'admin','Başarılı','2025-01-27 10:38:11'),(70,'admin','Başarılı','2025-01-27 12:09:05'),(71,'admin','Başarılı','2025-02-10 02:30:17'),(72,'admin','Başarılı','2025-02-10 02:31:15'),(73,'admin','Başarılı','2025-02-10 02:44:40'),(74,'admin','Başarılı','2025-02-10 02:45:09'),(75,'admin','Başarılı','2025-02-10 02:46:25'),(76,'admin','Başarılı','2025-02-10 02:46:34'),(77,'admin','Başarılı','2025-02-10 02:50:23'),(78,'admin','Başarılı','2025-02-10 02:51:28'),(79,'admin','Başarılı','2025-02-10 03:03:42'),(80,'admin','Başarılı','2025-02-10 03:04:27'),(81,'admin','Başarılı','2025-02-10 03:07:24'),(82,'admin','Başarılı','2025-02-10 03:08:24'),(83,'admin','Başarılı','2025-02-10 03:09:16'),(84,'admin','Başarılı','2025-02-10 03:37:25'),(85,'admin','Başarılı','2025-02-11 20:39:33'),(86,'umut','Başarılı','2025-02-11 20:45:03'),(87,'umut','Başarılı','2025-02-11 20:45:12'),(88,'umut','Başarılı','2025-02-11 20:45:24'),(89,'admin','Başarılı','2025-02-11 20:45:38');
/*!40000 ALTER TABLE `personelhareketleri` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personeller`
--

DROP TABLE IF EXISTS `personeller`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personeller` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ad` varchar(20) NOT NULL,
  `soyad` varchar(20) NOT NULL,
  `sifre` varchar(15) NOT NULL,
  `gorev` varchar(15) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personeller`
--

LOCK TABLES `personeller` WRITE;
/*!40000 ALTER TABLE `personeller` DISABLE KEYS */;
INSERT INTO `personeller` VALUES (1,'umut','altun','123','patron'),(2,'admin','admin','0000','admin');
/*!40000 ALTER TABLE `personeller` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `satislar`
--

DROP TABLE IF EXISTS `satislar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `satislar` (
  `id` int NOT NULL AUTO_INCREMENT,
  `adisyonİd` int NOT NULL,
  `urunİd` int NOT NULL,
  `masaİd` int NOT NULL,
  `adet` int NOT NULL,
  `servisTuru` varchar(15) NOT NULL,
  `durum` varchar(15) NOT NULL,
  `satisZamani` datetime NOT NULL,
  `urunNot` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=207 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `satislar`
--

LOCK TABLES `satislar` WRITE;
/*!40000 ALTER TABLE `satislar` DISABLE KEYS */;
INSERT INTO `satislar` VALUES (1,1,8,1,1,'normal','kapalı','2024-11-03 15:45:06',''),(2,1,14,1,1,'normal','kapalı','2024-11-03 15:45:06',''),(3,1,17,1,1,'normal','kapalı','2024-11-03 15:45:06',''),(4,2,32,2,1,'normal','kapalı','2024-11-03 16:44:46',''),(5,2,31,2,2,'normal','kapalı','2024-11-03 16:44:46',''),(6,3,1,1,1,'normal','kapalı','2024-11-15 21:06:54',''),(7,3,14,1,2,'normal','kapalı','2024-11-15 21:06:54',''),(8,3,16,1,3,'normal','kapalı','2024-11-15 21:06:54',''),(9,3,17,1,2,'normal','kapalı','2024-11-15 21:06:54',''),(10,3,8,1,2,'normal','kapalı','2024-11-15 21:06:54',''),(11,4,1,1,2,'paket','kapalı','2024-11-15 21:08:09',NULL),(12,4,37,1,1,'paket','kapalı','2024-11-15 21:08:09',NULL),(13,4,38,1,2,'paket','kapalı','2024-11-15 21:08:09',NULL),(14,4,30,1,1,'paket','kapalı','2024-11-15 21:08:09',NULL),(15,5,1,12,1,'paket','kapalı','2024-11-15 21:10:19',NULL),(16,5,14,12,1,'paket','kapalı','2024-11-15 21:10:19',NULL),(17,5,16,12,2,'paket','kapalı','2024-11-15 21:10:19',NULL),(18,5,8,12,1,'paket','kapalı','2024-11-15 21:10:19',NULL),(19,6,16,3,3,'normal','kapalı','2024-11-16 22:47:19',''),(20,6,8,3,3,'normal','kapalı','2024-11-16 22:47:19',''),(21,7,34,19,45,'normal','kapalı','2024-11-16 22:47:34',''),(22,7,30,19,11,'normal','kapalı','2024-11-16 22:47:34',''),(23,7,29,19,11,'normal','kapalı','2024-11-16 22:47:34',''),(24,8,35,20,1,'normal','kapalı','2024-11-16 22:47:44',''),(25,8,36,20,1,'normal','kapalı','2024-11-16 22:47:44',''),(26,8,31,20,1,'normal','kapalı','2024-11-16 22:47:44',''),(27,8,32,20,1,'normal','kapalı','2024-11-16 22:47:44',''),(28,8,33,20,1,'normal','kapalı','2024-11-16 22:47:44',''),(29,9,17,8,1,'normal','kapalı','2024-11-16 22:49:15',''),(30,9,36,8,2,'normal','kapalı','2024-11-16 22:49:15',''),(31,9,35,8,1,'normal','kapalı','2024-11-16 22:49:15',''),(32,10,37,7,4,'paket','kapalı','2024-11-16 22:50:07',NULL),(33,10,38,7,3,'paket','kapalı','2024-11-16 22:50:07',NULL),(34,11,8,3,2,'normal','kapalı','2024-12-10 21:06:35',''),(35,11,14,3,2,'normal','kapalı','2024-12-10 21:06:35',''),(36,11,16,3,1,'normal','kapalı','2024-12-10 21:06:35',''),(37,11,1,3,1,'normal','kapalı','2024-12-10 21:06:35',''),(38,12,38,4,2,'normal','kapalı','2024-12-10 21:06:38',''),(39,12,37,4,2,'normal','kapalı','2024-12-10 21:06:38',''),(40,13,1,1,2,'normal','kapalı','2024-12-20 18:37:17',''),(41,13,8,1,2,'normal','kapalı','2024-12-20 18:37:17',''),(42,13,14,1,1,'normal','kapalı','2024-12-20 18:37:17',''),(43,13,17,1,1,'normal','kapalı','2024-12-20 18:37:17',''),(44,14,1,1,2,'normal','kapalı','2024-12-20 20:04:19',''),(45,14,14,1,2,'normal','kapalı','2024-12-20 20:04:19',''),(46,14,8,1,1,'normal','kapalı','2024-12-20 20:04:19',''),(47,14,16,1,1,'normal','kapalı','2024-12-20 20:04:19',''),(48,14,17,1,2,'normal','kapalı','2024-12-20 20:04:19',''),(49,15,20,1,3,'normal','kapalı','2024-12-20 20:04:43',''),(50,15,19,1,3,'normal','kapalı','2024-12-20 20:04:43',''),(51,15,18,1,4,'normal','kapalı','2024-12-20 20:04:43',''),(52,15,13,1,2,'normal','kapalı','2024-12-20 20:04:43',''),(53,16,1,1,3,'normal','kapalı','2024-12-20 21:08:28',''),(54,16,14,1,6,'normal','kapalı','2024-12-20 21:08:28',''),(55,16,17,1,3,'normal','kapalı','2024-12-20 21:08:28',''),(56,16,8,1,2,'normal','kapalı','2024-12-20 21:08:28',''),(57,16,16,1,2,'normal','kapalı','2024-12-20 21:08:28',''),(58,17,1,4,1,'normal','kapalı','2024-12-20 21:39:34',''),(59,17,14,4,2,'normal','kapalı','2024-12-20 21:39:34',''),(60,17,16,4,2,'normal','kapalı','2024-12-20 21:39:34',''),(61,17,17,4,2,'normal','kapalı','2024-12-20 21:39:34',''),(62,18,1,1,1,'normal','kapalı','2024-12-20 21:43:31',''),(63,18,8,1,2,'normal','kapalı','2024-12-20 21:43:31',''),(64,18,16,1,1,'normal','kapalı','2024-12-20 21:43:31',''),(65,18,17,1,1,'normal','kapalı','2024-12-20 21:43:31',''),(66,18,14,1,1,'normal','kapalı','2024-12-20 21:43:31',''),(67,19,18,19,3,'normal','kapalı','2024-12-20 21:43:43',''),(68,19,19,19,2,'normal','kapalı','2024-12-20 21:43:43',''),(69,19,20,19,3,'normal','kapalı','2024-12-20 21:43:43',''),(70,19,33,19,1,'normal','kapalı','2024-12-20 21:43:43',''),(71,19,32,19,2,'normal','kapalı','2024-12-20 21:43:43',''),(72,19,31,19,1,'normal','kapalı','2024-12-20 21:43:43',''),(73,20,1,4,1,'normal','kapalı','2024-12-21 00:09:03',''),(74,20,8,4,1,'normal','kapalı','2024-12-21 00:09:03',''),(75,20,14,4,1,'normal','kapalı','2024-12-21 00:09:03',''),(76,20,16,4,2,'normal','kapalı','2024-12-21 00:09:03',''),(77,20,17,4,1,'normal','kapalı','2024-12-21 00:09:03',''),(78,21,8,4,1,'normal','kapalı','2024-12-21 15:53:45',''),(79,21,14,4,1,'normal','kapalı','2024-12-21 15:53:45',''),(80,21,16,4,2,'normal','kapalı','2024-12-21 15:53:45',''),(81,21,17,4,1,'normal','kapalı','2024-12-21 15:53:45',''),(82,22,1,4,1,'normal','kapalı','2024-12-21 16:17:07',''),(83,22,8,4,5,'normal','kapalı','2024-12-21 16:17:07',''),(84,22,16,4,1,'normal','kapalı','2024-12-21 16:17:07',''),(85,22,17,4,2,'normal','kapalı','2024-12-21 16:17:07',''),(86,23,8,13,2,'normal','kapalı','2024-12-21 16:19:39',''),(87,24,14,1,2,'paket','kapalı','2024-12-21 16:22:31',NULL),(88,24,33,1,2,'paket','kapalı','2024-12-21 16:22:31',NULL),(89,25,1,4,1,'normal','kapalı','2024-12-21 16:24:28',''),(90,25,14,4,2,'normal','kapalı','2024-12-21 16:24:28',''),(91,25,16,4,1,'normal','kapalı','2024-12-21 16:24:28',''),(92,25,17,4,1,'normal','kapalı','2024-12-21 16:24:28',''),(93,25,8,4,1,'normal','kapalı','2024-12-21 16:24:28',''),(94,26,1,5,1,'normal','kapalı','2024-12-22 15:24:24',''),(95,26,8,5,1,'normal','kapalı','2024-12-22 15:24:24',''),(96,26,14,5,1,'normal','kapalı','2024-12-22 15:24:24',''),(97,26,17,5,1,'normal','kapalı','2024-12-22 15:24:24',''),(98,26,16,5,1,'normal','kapalı','2024-12-22 15:24:24',''),(99,26,35,5,1,'normal','kapalı','2024-12-22 15:24:24',''),(100,26,31,5,1,'normal','kapalı','2024-12-22 15:24:24',''),(101,26,32,5,1,'normal','kapalı','2024-12-22 15:24:24',''),(102,26,33,5,1,'normal','kapalı','2024-12-22 15:24:24',''),(103,27,8,1,1,'normal','kapalı','2024-12-22 16:52:34',''),(104,27,14,1,3,'normal','kapalı','2024-12-22 16:52:34',''),(105,27,16,1,1,'normal','kapalı','2024-12-22 16:52:34',''),(106,27,17,1,2,'normal','kapalı','2024-12-22 16:52:34',''),(107,27,1,1,1,'normal','kapalı','2024-12-22 16:52:34',''),(108,28,29,3,3,'normal','kapalı','2024-12-22 16:52:38',''),(109,28,30,3,1,'normal','kapalı','2024-12-22 16:52:38',''),(110,29,13,12,2,'normal','kapalı','2024-12-22 16:52:43',''),(111,29,19,12,4,'normal','kapalı','2024-12-22 16:52:43',''),(112,29,18,12,3,'normal','kapalı','2024-12-22 16:52:43',''),(113,29,20,12,1,'normal','kapalı','2024-12-22 16:52:43',''),(114,30,34,13,2,'normal','kapalı','2024-12-22 16:52:47',''),(115,31,35,21,11,'normal','kapalı','2024-12-22 16:52:51',''),(116,32,38,16,2,'normal','kapalı','2024-12-22 16:52:55',''),(117,32,37,16,1,'normal','kapalı','2024-12-22 16:52:55',''),(118,33,35,8,6,'normal','kapalı','2024-12-22 16:53:01',''),(119,33,36,8,1,'normal','kapalı','2024-12-22 16:53:01',''),(120,34,34,25,2,'normal','kapalı','2024-12-22 16:53:15',''),(121,35,37,1,1,'paket','kapalı','2024-12-22 16:55:20',NULL),(122,35,38,1,1,'paket','kapalı','2024-12-22 16:55:20',NULL),(123,35,36,1,1,'paket','kapalı','2024-12-22 16:55:20',NULL),(124,36,14,6,1,'paket','kapalı','2024-12-22 16:57:30',NULL),(125,36,16,6,1,'paket','kapalı','2024-12-22 16:57:30',NULL),(126,36,17,6,1,'paket','kapalı','2024-12-22 16:57:30',NULL),(127,36,8,6,1,'paket','kapalı','2024-12-22 16:57:30',NULL),(128,37,17,6,10,'normal','kapalı','2024-12-22 17:15:11',''),(129,37,14,6,96,'normal','kapalı','2024-12-22 17:15:11',''),(130,38,1,4,2,'normal','kapalı','2024-12-22 17:34:49',''),(131,38,8,4,2,'normal','kapalı','2024-12-22 17:34:49',''),(132,38,14,4,2,'normal','kapalı','2024-12-22 17:34:49',''),(133,38,16,4,2,'normal','kapalı','2024-12-22 17:34:49',''),(134,39,16,4,1,'normal','kapalı','2024-12-23 11:20:07',''),(135,40,14,1,2,'normal','kapalı','2025-01-02 13:07:09',''),(136,40,17,1,1,'normal','kapalı','2025-01-02 13:07:09',''),(137,40,8,1,1,'normal','kapalı','2025-01-02 13:07:09',''),(138,41,1,1,1,'normal','kapalı','2025-01-06 10:36:22',''),(139,41,16,1,5,'normal','kapalı','2025-01-06 10:36:22',''),(140,42,37,8,1,'normal','kapalı','2025-01-06 10:36:38',''),(141,42,38,8,4,'normal','kapalı','2025-01-06 10:36:38',''),(142,43,8,2,2,'normal','kapalı','2025-01-06 10:37:43',''),(143,43,14,2,2,'normal','kapalı','2025-01-06 10:37:43',''),(144,43,16,2,2,'normal','kapalı','2025-01-06 10:37:43',''),(145,44,38,10,4,'normal','kapalı','2025-01-06 10:37:58',''),(146,45,1,5,1,'normal','kapalı','2025-01-06 10:45:04',''),(147,45,8,5,3,'normal','kapalı','2025-01-06 10:45:04',''),(148,45,16,5,2,'normal','kapalı','2025-01-06 10:45:04',''),(149,46,38,20,2,'normal','kapalı','2025-01-06 10:45:09',''),(150,46,37,20,3,'normal','kapalı','2025-01-06 10:45:09',''),(151,47,35,15,2,'normal','kapalı','2025-01-06 10:45:14',''),(152,47,36,15,3,'normal','kapalı','2025-01-06 10:45:14',''),(153,48,8,10,3,'normal','kapalı','2025-01-06 10:45:19',''),(154,48,16,10,1,'normal','kapalı','2025-01-06 10:45:19',''),(155,48,17,10,1,'normal','kapalı','2025-01-06 10:45:19',''),(156,48,14,10,2,'normal','kapalı','2025-01-06 10:45:19',''),(157,43,8,2,2,'normal','kapalı','2025-01-06 12:25:04',''),(158,43,14,2,3,'normal','kapalı','2025-01-06 12:25:04',''),(159,49,17,2,1,'normal','kapalı','2025-01-06 12:25:49',''),(160,49,14,2,1,'normal','kapalı','2025-01-06 12:25:49',''),(161,49,32,2,1,'normal','kapalı','2025-01-06 12:25:49',''),(162,50,1,4,1,'normal','kapalı','2025-01-06 20:06:41',''),(163,50,14,4,1,'normal','kapalı','2025-01-06 20:06:41',''),(164,50,16,4,1,'normal','kapalı','2025-01-06 20:06:41',''),(165,50,8,4,1,'normal','kapalı','2025-01-06 20:06:41',''),(166,51,8,1,1,'normal','kapalı','2025-01-25 11:43:20',''),(167,51,14,1,1,'normal','kapalı','2025-01-25 11:43:20',''),(168,51,16,1,1,'normal','kapalı','2025-01-25 11:43:20',''),(169,52,8,2,1,'normal','kapalı','2025-01-27 10:38:16',''),(170,52,16,2,2,'normal','kapalı','2025-01-27 10:38:16',''),(171,52,17,2,1,'normal','kapalı','2025-01-27 10:38:16',''),(172,52,14,2,1,'normal','kapalı','2025-01-27 10:38:16',''),(173,52,8,2,1,'normal','kapalı','2025-02-10 02:30:27',''),(174,52,16,2,1,'normal','kapalı','2025-02-10 02:30:27',''),(175,53,1,1,1,'normal','kapalı','2025-02-10 02:31:26',''),(176,53,8,1,2,'normal','kapalı','2025-02-10 02:31:26',''),(177,53,14,1,4,'normal','kapalı','2025-02-10 02:31:26',''),(178,53,16,1,2,'normal','kapalı','2025-02-10 02:31:26',''),(179,53,30,1,2,'normal','kapalı','2025-02-10 02:31:36',''),(180,53,29,1,2,'normal','kapalı','2025-02-10 02:31:36',''),(181,54,8,2,1,'normal','kapalı','2025-02-10 02:44:45',''),(182,54,14,2,1,'normal','kapalı','2025-02-10 02:44:45',''),(183,54,16,2,2,'normal','kapalı','2025-02-10 02:44:45',''),(184,55,14,3,1,'normal','kapalı','2025-02-10 02:46:39',''),(185,55,8,3,1,'normal','kapalı','2025-02-10 02:46:39',''),(186,55,16,3,1,'normal','kapalı','2025-02-10 02:46:39',''),(187,56,8,3,1,'normal','kapalı','2025-02-10 02:50:28',''),(188,56,16,3,1,'normal','kapalı','2025-02-10 02:50:28',''),(189,57,38,5,1,'normal','kapalı','2025-02-10 02:51:32',''),(190,58,21,1,4,'normal','kapalı','2025-02-11 20:41:43','SOSSZZ'),(191,58,24,1,1,'normal','kapalı','2025-02-11 20:41:43',''),(192,58,23,1,2,'normal','kapalı','2025-02-11 20:41:43',''),(193,58,37,1,1,'normal','kapalı','2025-02-11 20:41:56',''),(194,58,38,1,2,'normal','kapalı','2025-02-11 20:41:56',''),(195,59,1,2,1,'paket','kapalı','2025-02-11 20:43:11',NULL),(196,59,8,2,1,'paket','kapalı','2025-02-11 20:43:11',NULL),(197,59,16,2,1,'paket','kapalı','2025-02-11 20:43:11',NULL),(198,60,30,12,3,'normal','kapalı','2025-02-11 20:44:24',''),(199,60,29,12,3,'normal','kapalı','2025-02-11 20:44:24',''),(200,60,36,12,6,'normal','kapalı','2025-02-11 20:44:24',''),(201,60,31,12,3,'normal','kapalı','2025-02-11 20:44:24',''),(202,60,32,12,6,'normal','kapalı','2025-02-11 20:44:24',''),(203,60,19,12,82,'normal','kapalı','2025-02-11 20:44:24',''),(204,60,20,12,40,'normal','kapalı','2025-02-11 20:44:24',''),(205,60,13,12,40,'normal','kapalı','2025-02-11 20:44:24',''),(206,60,18,12,4,'normal','kapalı','2025-02-11 20:44:24','');
/*!40000 ALTER TABLE `satislar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `urunler`
--

DROP TABLE IF EXISTS `urunler`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `urunler` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kategoriİd` int NOT NULL,
  `urunAd` varchar(45) NOT NULL,
  `aciklama` varchar(45) NOT NULL,
  `fiyat` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `urunler`
--

LOCK TABLES `urunler` WRITE;
/*!40000 ALTER TABLE `urunler` DISABLE KEYS */;
INSERT INTO `urunler` VALUES (1,1,'Soya Tavuk','-',242),(8,1,'Barbekü Tavuk','-',8),(13,3,'Mevsim Salata','-',54),(14,1,'Izgara Tavuk','-',56),(16,1,'Tavuk Sote','-',12),(17,1,'Meksika Tavuk','-',23),(18,3,'Tavuklu Salata','-',54),(19,3,'Ton Balık Salata','-',56),(20,3,'Çoban Salata','-',55),(21,2,'Alfredo Penne','-',56),(22,2,'Kori Penne','-',66),(23,2,'Soya Penne','-',99),(24,2,'Arabiata Penne','-',23),(25,4,'Mercimek','-',67),(26,4,'Yayla','-',32),(27,4,'Ezogelin','-',76),(28,4,'Tavuk','-',97),(29,5,'Patates Kızartma','-',34),(30,5,'Elma Patates','-',23),(31,6,'Su','-',5),(32,6,'Şişe Kola','-',34),(33,6,'Kutu Kola','-',45),(34,7,'Soğan Halkası','-',5),(35,8,'Sütlaç','-',55),(36,8,'Tulumba','-',33),(37,9,'Tavuk Dürüm','-',34),(38,9,'Tantuni Dürüm','-',32);
/*!40000 ALTER TABLE `urunler` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-12  2:08:01
