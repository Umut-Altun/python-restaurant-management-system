from forms.frmPaketUi import Ui_frmPaket
from PyQt5.QtGui import QIcon, QPixmap
from PyQt5 import QtWidgets
import mysql.connector
from PyQt5.QtCore import QTimer
from database.connect_to_database import connect_to_database
from scripts.wifi import update_wifi_status 


class frmPaket(QtWidgets.QMainWindow):
    def __init__(self):
        super(frmPaket, self).__init__()
        self.ui = Ui_frmPaket()
        self.ui.setupUi(self) 
        self.showFullScreen()

        self.ui.btnGeri.clicked.connect(self.back_application)                      # btnGeri buton tıklama

        # Database bağlantısı başlat...
        self.connection = connect_to_database() 

        self.masa_buttons = [
            self.ui.btnPktMasa1, self.ui.btnPktMasa2, self.ui.btnPktMasa3,
            self.ui.btnPktMasa4,self.ui.btnPktMasa5, self.ui.btnPktMasa6,
            self.ui.btnPktMasa7, self.ui.btnPktMasa8, self.ui.btnPktMasa9,
            self.ui.btnPktMasa10, self.ui.btnPktMasa11, self.ui.btnPktMasa12,
            self.ui.btnPktMasa13, self.ui.btnPktMasa14, self.ui.btnPktMasa15,
            self.ui.btnPktMasa16,self.ui.btnPktMasa17, self.ui.btnPktMasa18,
            self.ui.btnPktMasa19, self.ui.btnPktMasa20, self.ui.btnPktMasa21,
            self.ui.btnPktMasa22, self.ui.btnPktMasa23, self.ui.btnPktMasa24,
            self.ui.btnPktMasa25, self.ui.btnPktMasa26, self.ui.btnPktMasa27,
            self.ui.btnPktMasa28,
        ]

        # Masa düğmelerine tıklandığında open_order_window fonksiyonunu bağlayın
        for i, masa_button in enumerate(self.masa_buttons, start=1):
            masa_button.clicked.connect(lambda _, num=i: self.open_order_window(num))

        self.update_table_status()
        self.sale_transfer_time()
        self.total_transfer_time()
        self.table_control()

        # Wi-Fi durumunu kontrol etmek için bir timer oluşturun
        self.timer = QTimer(self) 
        self.timer.timeout.connect(self.check_wifi_status) 
        self.timer.start(1500)

        self.user_control()  # Kullanıcı kontrol fonksiyonunu çağır

        # Wi-Fi durumunu kontrol etmek için bir timer oluşturun
        self.timer = QTimer(self) 
        self.timer.timeout.connect(self.check_wifi_status) 
        self.timer.start(15000)



    def check_wifi_status(self):
        update_wifi_status(self.ui)

    def user_control(self):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                # En son giriş yapan kullanıcının adını al
                query = "SELECT personelAd FROM personelhareketleri WHERE durum = 'Başarılı' ORDER BY tarih DESC LIMIT 1"
                cursor.execute(query)
                last_logged_in_user = cursor.fetchone()

                if last_logged_in_user:
                    self.ui.lblKullanici.setText(last_logged_in_user[0])
                else:
                    self.ui.lblKullanici.setText("Giriş Yapılmadı")

                cursor.close()

            except mysql.connector.Error as err:
                print("Veritabanı Hatası:", err)

    def back_application(self):                                                     # pencere 
        self.close()
        from views.frmMenu import frmMenu
        self.frm_frmMenu = frmMenu()
        self.frm_frmMenu.show()

    def update_table_status(self):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()
                query = "SELECT id, durum FROM paketmasalar"
                cursor.execute(query)
                masa_durumlari = cursor.fetchall()
                cursor.close()

                for masa_id, masa_durumu in masa_durumlari:
                    masa_button = self.masa_buttons[masa_id - 1]

                    if masa_durumu == "1":
                        # Masa boş durumunda resmi yükle
                        image_path = f":/pmasalar/resimler/PMASA/PB1.png"
                        pixmap = QPixmap(image_path)
                        masa_button.setIcon(QIcon(pixmap))
                    elif masa_durumu == "2":
                        # Masa dolu durumunda resmi yükle
                        image_path = f":/pmasalar/resimler/PMASA/PD2.png"
                        pixmap = QPixmap(image_path)
                        masa_button.setIcon(QIcon(pixmap))

                        # Dolu masa olduğunda butona tıklandığında frmPaketOdeme sayfasına git
                        masa_button.clicked.connect(lambda _, num=masa_id: self.open_order_window(num, "frmPaketOdeme"))

                # print("-----masa durum kontrolleri tamamlandı------")
            except mysql.connector.Error as err:
                print("Hata:", err)

    def open_order_window(self, masa_no, page=None):
        if page is None:
            # Sayfa belirtilmemişse varsayılan olarak frmPaketSiparis sayfasına git
            page = "frmPaketSiparis"
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()
                query = "SELECT durum FROM paketmasalar WHERE id = %s"
                cursor.execute(query, (masa_no,))
                masa_durumu = cursor.fetchone()
                cursor.close()

                if masa_durumu:
                    if masa_durumu[0] == "1":
                        # Durum 1 ise frmPaketSiparis sayfasına git
                        self.close()
                        from views.frmPaketSiparis import frmPaketSiparis
                        self.frm_frmPaketSiparis = frmPaketSiparis()
                        masa_no = f"Paket {masa_no}"
                        self.frm_frmPaketSiparis.set_masa_info(masa_no)
                        self.frm_frmPaketSiparis.show()
                    elif masa_durumu[0] == "2":
                        # Durum 2 ise frmPaketOdeme sayfasına git
                        self.close()
                        from views.frmPaketOdeme import frmPaketOdeme
                        self.frm_odeme = frmPaketOdeme()
                        masa_no = f"Paket {masa_no}"
                        self.frm_odeme.set_masa_info(masa_no)
                        self.frm_odeme.show()
                    else:
                        print("Masa durumu belirlenemiyor.")
                        return

                else:
                    print("Masa durumu bulunamadı.")
            except mysql.connector.Error as err:
                print("Hata:", err)
        else:
            print("Veritabanı bağlantısı kurulamadı.")

    def sale_transfer_time(self):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                # Adisyonlar tablosundan durumu "acik" olan satırları seçin
                query = "SELECT masaId, tarih FROM adisyonlar WHERE durum = 'acik' and servisTuru = 'paket'"
                cursor.execute(query)
                adisyonlar = cursor.fetchall()

                for adisyon in adisyonlar:
                    masa_id = adisyon[0]  # Masa ID'sini al
                    tarih = adisyon[1]  # Tarifi al

                    # Masa ID'sine uygun masa düğmesinin altındaki etiketi güncelle
                    label = getattr(self.ui, f"lblBtnSaat_{masa_id}")
                    tarih_str = tarih.strftime('%H:%M')
                    label.setText(tarih_str)
                cursor.close()

            except mysql.connector.Error as err:
                print("Hata:", err)

    def total_transfer_time(self):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                # Adisyonlar tablosundan durumu "acik" olan satırları seçin
                query = "SELECT masaId, tarih FROM adisyonlar WHERE durum = 'acik' and servisTuru = 'paket'"
                cursor.execute(query)
                adisyonlar = cursor.fetchall()

                for adisyon in adisyonlar:
                    masa_id = adisyon[0]  # Masa ID'sini al

                    # Masa ID'sine uygun fiyat etiketini güncelle
                    total_sales = self.calculate_total_sales(masa_id)
                    label_fiyat = getattr(self.ui, f"lblBtnFiyat_{masa_id}")
                    label_fiyat.setText(f"${str(total_sales)}")

                cursor.close()

            except mysql.connector.Error as err:
                print("Hata:", err)

    def calculate_total_sales(self, masa_id):
        try:
            cursor = self.connection.cursor()

            # Masa ID'sine göre satışların toplam tutarını hesapla
            query = f"SELECT SUM(u.fiyat * s.adet) FROM satislar s JOIN urunler u ON s.urunId = u.id WHERE s.adisyonId = (SELECT id FROM adisyonlar WHERE masaId = '{masa_id}' AND durum = 'acik' and servisTuru = 'paket') and s.durum = 'acik'"
            cursor.execute(query)
            total_sales = cursor.fetchone()[0]

            cursor.close()

            return total_sales if total_sales else 0  # Toplam satışı veya 0'ı döndür

        except mysql.connector.Error as err:
            print("Hata:", err)
            return 0  # Hata durumunda 0 döndür

    def table_control(self):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                # Adisyonlar tablosundan durumu "acik" olan satırları seçin
                query = "SELECT masaId ,durum FROM adisyonlar WHERE servisTuru = 'paket'"
                cursor.execute(query)
                adisyonlar = cursor.fetchall()

                for adisyon in adisyonlar:
                    masa_id = adisyon[0]  # Masa ID'sini al
                    masa_durum = adisyon[1]  # Masa ID'sini al

                    if masa_durum == "acik":
                        label_durum = getattr(self.ui, f"lblBtnDurum_{masa_id}")
                        label_durum.setText("Dolu")
                    else:
                        label_durum = getattr(self.ui, f"lblBtnDurum_{masa_id}")
                        label_durum.setText("Boş")

                cursor.close()

            except mysql.connector.Error as err:
                print("Hata:", err)


