from forms.frmAyarlarUi import Ui_frmAyarlar
from PyQt5 import QtWidgets
import mysql.connector
from database.connect_to_database import connect_to_database


class frmAyarlar(QtWidgets.QMainWindow):
    def __init__(self):
        super(frmAyarlar, self).__init__()
        self.ui = Ui_frmAyarlar()
        self.ui.setupUi(self) 
        self.showFullScreen()
        self.ui.btnGeri.clicked.connect(self.back_application) #btnGeri buton tıklama
        self.ui.btnAra.clicked.connect(self.search_users) #arama buton tıklama
        self.ui.btnPrsnlDuzenle.clicked.connect(self.users_update) #prsl guncelle tıklama
        self.ui.btnPrsnlKaydet.clicked.connect(self.users_save) #prsl katıy tıklama
        self.ui.btnPrsnlSil.clicked.connect(self.users_delete) #prsl sil tıklama

        # Bağlantıyı başlat...
        self.connection = connect_to_database()

        self.load_users()


    def back_application(self):    #pencere kapatma
        self.close()
        from views.frmMenu import frmMenu
        self.frm_frmMenu = frmMenu()
        self.frm_frmMenu.show()

    def load_users(self):      #personellero tabloya ekle
        connection = self.connection
        if connection is not None:
            try:
                cursor = connection.cursor()
                # Verileri çek
                cursor.execute("SELECT ad, soyad, sifre, gorev FROM personeller")
                result = cursor.fetchall()

                # TableWidget'e verileri ekle
                self.ui.twPersoneller.setRowCount(len(result))
                self.ui.twPersoneller.setColumnCount(4)

                for row_num, row_data in enumerate(result):
                    for col_num, col_data in enumerate(row_data):
                        self.ui.twPersoneller.setItem(row_num, col_num, QtWidgets.QTableWidgetItem(str(col_data)))

                cursor.close()
            except mysql.connector.Error as err:
                print("Hata load_users:", err)

    def search_users(self):     # kullanıcı arama ıslemlerı
        ad = self.ui.lnAd.text()
        soyad = self.ui.lnSoyad.text()

        connection = self.connection
        if connection is not None:
            try:
                cursor = connection.cursor()
                # SQL sorgusu oluştur ve çalıştır
                query = "SELECT ad, soyad, sifre, gorev FROM personeller WHERE ad LIKE %s AND soyad LIKE %s ORDER BY ad"
                cursor.execute(query, ('%' + ad + '%', '%' + soyad + '%',))
                result = cursor.fetchall()

                # TableWidget'i temizle ve yeni verileri ekle
                self.ui.twPersoneller.setRowCount(len(result))
                for row_num, row_data in enumerate(result):
                    for col_num, col_data in enumerate(row_data):
                        self.ui.twPersoneller.setItem(row_num, col_num, QtWidgets.QTableWidgetItem(str(col_data)))

                cursor.close()
            except mysql.connector.Error as err:
                print("Hata search_users:", err)

        # Arama işlemi bittiğinde kutuları temizle
        self.ui.lnAd.clear()
        self.ui.lnSoyad.clear()

    def users_update(self):    #personel guncelle
        selected_row = self.ui.twPersoneller.currentRow()  # Tablodan seçilen satırı al

        if selected_row >= 0:
            ad = self.ui.twPersoneller.item(selected_row, 0).text()  
            soyad = self.ui.twPersoneller.item(selected_row, 1).text()  
            self.close()
            from views.frmPersonelGuncelle import frmPersonelGuncelle
            self.frm_frmPersonelGuncelle = frmPersonelGuncelle(ad,soyad)
            self.frm_frmPersonelGuncelle.show()
        else:
            QtWidgets.QMessageBox.information(self, "Hata", "Personel seçilmedi.")

    def users_save(self):   #personel kaydet
        self.close()
        from views.frmPersonelKayit import frmPersonelKayit
        self.frm_frmPersonelKayit = frmPersonelKayit()
        self.frm_frmPersonelKayit.show() 

    def users_delete(self):     #personel sil
        selected_row = self.ui.twPersoneller.currentRow()  # Tablodan seçilen satırı al

        if selected_row >= 0:
            ad = self.ui.twPersoneller.item(selected_row, 0).text()  
            soyad = self.ui.twPersoneller.item(selected_row, 1).text()  
            self.close()
            from views.frmPersonelSil import frmPersonelSil
            self.frm_frmPersonelSil = frmPersonelSil(ad,soyad)
            self.frm_frmPersonelSil.show()
        else:
            QtWidgets.QMessageBox.information(self, "Hata", "Personel seçilmedi.")

