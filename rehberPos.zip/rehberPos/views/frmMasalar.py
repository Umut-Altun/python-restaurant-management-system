from forms.frmMasalarUi import Ui_frmMasalar
from PyQt5.QtGui import QIcon, QPixmap
from PyQt5 import QtWidgets
import mysql.connector
from PyQt5.QtCore import QTimer
from scripts.wifi import update_wifi_status 
from database.connect_to_database import connect_to_database


class frmMasalar(QtWidgets.QMainWindow):
    def __init__(self):
        super(frmMasalar, self).__init__()
        self.ui = Ui_frmMasalar()
        self.ui.setupUi(self)
        self.showFullScreen()
        self.ui.btnCikis.clicked.connect(self.exit_application)
        self.ui.btnGeri.clicked.connect(self.back_application)

        self.masa_buttons = [
            self.ui.btnMasa1, self.ui.btnMasa2, self.ui.btnMasa3,
            self.ui.btnMasa4, self.ui.btnMasa5, self.ui.btnMasa6,
            self.ui.btnMasa7, self.ui.btnMasa8, self.ui.btnMasa9,
            self.ui.btnMasa10, self.ui.btnMasa11, self.ui.btnMasa12,
            self.ui.btnMasa13, self.ui.btnMasa14, self.ui.btnMasa15,
            self.ui.btnMasa16, self.ui.btnMasa17, self.ui.btnMasa18,
            self.ui.btnMasa19, self.ui.btnMasa20, self.ui.btnMasa21,
            self.ui.btnMasa22, self.ui.btnMasa23, self.ui.btnMasa24,
            self.ui.btnMasa25,self.ui.btnMasa26,self.ui.btnMasa27,self.ui.btnMasa28,]

        # Database bağlantıyı başlat...
        self.connection = connect_to_database()  

        self.update_table_status()
        self.sale_transfer_time()
        self.total_transfer_time()
        self.table_control()

        for i, masa_button in enumerate(self.masa_buttons, start=1):
            masa_button.clicked.connect(lambda _, num=i: self.open_order_window(f"MASA {num}"))

        self.user_control()  # Kullanıcı kontrol fonksiyonunu çağır

        # Wi-Fi durumunu kontrol etmek için bir timer oluşturun
        self.timer = QTimer(self) 
        self.timer.timeout.connect(self.check_wifi_status) 
        self.timer.start(15000)


    def check_wifi_status(self):
        update_wifi_status(self.ui)
        
    def user_control(self):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                # En son giriş yapan kullanıcının adını al
                query = "SELECT personelAd FROM personelhareketleri WHERE durum = 'Başarılı' ORDER BY tarih DESC LIMIT 1"
                cursor.execute(query)
                last_logged_in_user = cursor.fetchone()

                if last_logged_in_user:
                    self.ui.lblKullanici.setText(last_logged_in_user[0])
                else:
                    self.ui.lblKullanici.setText("Giriş Yapılmadı")

                cursor.close()

            except mysql.connector.Error as err:
                print("Veritabanı Hatası user_control:", err)

    def update_table_status(self):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()
                query = "SELECT id, durum FROM masalar"
                cursor.execute(query)
                masa_durumlari = cursor.fetchall()
                cursor.close()

                for masa_id, masa_durumu in masa_durumlari:
                    masa_button = self.masa_buttons[masa_id - 1]

                    if masa_durumu == '1':  # Masa durumu bir string ise
                        # Masa boş durumunda resmi yükle
                        image_path =f":/nmasalar/resimler/MASA/B1.png"
                        pixmap = QPixmap(image_path)
                        masa_button.setIcon(QIcon(pixmap))
                    elif masa_durumu == '2':  # Masa durumu bir string ise
                        # Masa dolu durumunda resmi yükle
                        image_path =  f":/nmasalar/resimler/MASA/D2.png"
                        pixmap = QPixmap(image_path)
                        masa_button.setIcon(QIcon(pixmap))

                # print("****** Masa Durum Kontrolleri Başarılı ******")
            except mysql.connector.Error as err:
                print("Hata update_table_status:", err)

    def open_order_window(self, masa_no):
        self.close()
        from views.frmSiparis import frmSiparis
        self.frm_siparis = frmSiparis(masa_no)
        self.frm_siparis.set_masa_info(masa_no)
        self.frm_siparis.show()

    def exit_application(self):
        QtWidgets.QApplication.quit()

    def back_application(self):
        self.close()
        from views.frmMenu import frmMenu
        self.frm_menu = frmMenu()
        self.frm_menu.show()

    def sale_transfer_time(self):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                # Adisyonlar tablosundan durumu "acik" olan satırları seçin
                query = "SELECT masaId, tarih FROM adisyonlar WHERE durum = 'acik' and servisTuru = 'normal'"
                cursor.execute(query)
                adisyonlar = cursor.fetchall()

                for adisyon in adisyonlar:
                    masa_id = adisyon[0]  # Masa ID'sini al
                    tarih = adisyon[1]  # Tarifi al

                    # Masa ID'sine uygun masa düğmesinin altındaki etiketi güncelle
                    label = getattr(self.ui, f"lblBtnSaat_{masa_id}")
                    tarih_str = tarih.strftime('%H:%M')
                    label.setText(tarih_str)
                cursor.close()

            except mysql.connector.Error as err:
                print("Hata sale_transfer_time:", err)

    def total_transfer_time(self):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                # Adisyonlar tablosundan durumu "acik" olan satırları seçin
                query = "SELECT masaId, tarih FROM adisyonlar WHERE durum = 'acik' and servisTuru = 'normal'"
                cursor.execute(query)
                adisyonlar = cursor.fetchall()

                for adisyon in adisyonlar:
                    masa_id = adisyon[0]  # Masa ID'sini al

                    # Masa ID'sine uygun fiyat etiketini güncelle
                    total_sales = self.calculate_total_sales(masa_id)
                    label_fiyat = getattr(self.ui, f"lblBtnFiyat_{masa_id}")
                    label_fiyat.setText(f"${str(total_sales)}")

                cursor.close()

            except mysql.connector.Error as err:
                print("Hata total_transfer_time:", err)

    def calculate_total_sales(self, masa_id):
        try:
            cursor = self.connection.cursor()

            # Masa ID'sine göre satışların toplam tutarını hesapla
            query = f"SELECT SUM(u.fiyat * s.adet) FROM satislar s JOIN urunler u ON s.urunId = u.id WHERE s.adisyonId = (SELECT id FROM adisyonlar WHERE masaId = '{masa_id}' AND durum = 'acik' and servisTuru = 'normal') and s.durum = 'acik'"
            cursor.execute(query)
            total_sales = cursor.fetchone()[0]

            cursor.close()

            return total_sales if total_sales else 0  # Toplam satışı veya 0'ı döndür

        except mysql.connector.Error as err:
            print("Hata calculate_total_sales:", err)
            return 0  # Hata durumunda 0 döndür

    def table_control(self):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                # Adisyonlar tablosundan durumu "acik" olan satırları seçin
                query = "SELECT masaId ,durum FROM adisyonlar WHERE servisTuru = 'normal'"
                cursor.execute(query)
                adisyonlar = cursor.fetchall()

                for adisyon in adisyonlar:
                    masa_id = adisyon[0]  # Masa ID'sini al
                    masa_durum = adisyon[1]  # Masa ID'sini al

                    if masa_durum == "acik":
                        label_durum = getattr(self.ui, f"lblBtnDurum_{masa_id}")
                        label_durum.setText("Dolu")
                    else:
                        label_durum = getattr(self.ui, f"lblBtnDurum_{masa_id}")
                        label_durum.setText("Boş")

                cursor.close()

            except mysql.connector.Error as err:
                print("Hata print:", err)