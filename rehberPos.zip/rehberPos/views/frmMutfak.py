from forms.frmMutfakUi import Ui_frmMutfak
from PyQt5 import QtWidgets
import mysql.connector
from database.connect_to_database import connect_to_database



class frmMutfak(QtWidgets.QMainWindow):
    def __init__(self):
        super(frmMutfak, self).__init__()
        self.ui = Ui_frmMutfak()
        self.ui.setupUi(self) 
        self.showFullScreen()
        # Database bağlantısı başlat...
        self.connection = connect_to_database()

        self.ui.btnGeri.clicked.connect(self.back_application)                      # btnGeri buton tıklama
        self.ui.btnUrunKaydet.clicked.connect(self.product_save)                      # urun kaydet buton tıklama
        self.ui.btnUrunGuncelle.clicked.connect(self.product_update)                      # urun guncelle buton tıklama
        self.ui.btnUrunSil.clicked.connect(self.product_delete)                      # urun sıl buton tıklama
        self.ui.btnAra.clicked.connect(self.search_product)                      # urun ara buton tıklama
        self.ui.btnAra_2.clicked.connect(self.search_product_2)                      # urun ara buton tıklama
        self.load_product_list()
        self.load_categori_list()


    def back_application(self):                                                     # pencere kapatma
        self.close()
        from views.frmMenu import frmMenu
        self.frm_frmMenu = frmMenu()
        self.frm_frmMenu.show()

    def load_product_list(self):
        connection = self.connection
        if connection is not None:
            try:
                cursor = connection.cursor()
                # Verileri çek
                cursor.execute("SELECT id,kategoriİd, urunAd,aciklama,fiyat FROM urunler")
                result = cursor.fetchall()

                # TableWidget'e verileri ekle
                self.ui.twUrunler.setRowCount(len(result))
                self.ui.twUrunler.setColumnCount(5)
                for row_num, row_data in enumerate(result):
                    for col_num, col_data in enumerate(row_data):
                        self.ui.twUrunler.setItem(row_num, col_num, QtWidgets.QTableWidgetItem(str(col_data)))

                cursor.close()
            except mysql.connector.Error as err:
                print("Hata load_product_list:", err)

    def load_categori_list(self):
        connection = self.connection
        if connection is not None:
            try:
                cursor = connection.cursor()
                # Verileri çek
                cursor.execute("SELECT id,kategoriAdi,aciklama FROM kategoriler")
                result = cursor.fetchall()

                # TableWidget'e verileri ekle
                self.ui.twKategori.setRowCount(len(result))
                self.ui.twKategori.setColumnCount(3)
                self.ui.twKategori.setHorizontalHeaderLabels(["İD", "KATEGORİ", "ACIKLAMA"])

                for row_num, row_data in enumerate(result):
                    for col_num, col_data in enumerate(row_data):
                        self.ui.twKategori.setItem(row_num, col_num, QtWidgets.QTableWidgetItem(str(col_data)))

                cursor.close()
            except mysql.connector.Error as err:
                print("Hata load_categori_list:", err)

    def product_save(self):
        self.close()
        from views.frmYeniUrun import frmYeniUrun
        self.frm_frmYeniUrun = frmYeniUrun()
        self.frm_frmYeniUrun.show() 

    def product_update(self):                                                  #Urun guncelle
        selected_row = self.ui.twUrunler.currentRow()  # Tablodan seçilen satırı al

        if selected_row >= 0:
            urun_id = self.ui.twUrunler.item(selected_row, 0).text()  # Tablodan urun id numarasını al
            self.close()
            from views.frmUrunGuncelle import frmUrunGuncelle
            self.frm_frmUrunGuncelle= frmUrunGuncelle(urun_id)
            self.frm_frmUrunGuncelle.show()
        else:
            QtWidgets.QMessageBox.information(self, "Hata", "Ürün seçilmedi.")

    def product_delete(self):#Urun sil
        selected_row = self.ui.twUrunler.currentRow()  # Tablodan seçilen satırı al

        if selected_row >= 0:
            urun_id = self.ui.twUrunler.item(selected_row, 0).text()  # Tablodan urun id numarasını al
            self.close()
            from views.frmUrunSil import frmUrunSil
            self.frm_frmUrunSil= frmUrunSil(urun_id)
            self.frm_frmUrunSil.show()
        else:
            QtWidgets.QMessageBox.information(self, "Hata", "Ürün seçilmedi.")

    def search_product(self):                                              # kullanıcı arama ıslemlerı
        ad = self.ui.lnUrunAd.text()

        connection = self.connection
        if connection is not None:
            try:
                cursor = connection.cursor()
                # SQL sorgusu oluştur ve çalıştır
                query = "SELECT id,kategoriİd, urunAd,aciklama,fiyat FROM urunler WHERE urunAd LIKE %s ORDER BY urunAd"
                cursor.execute(query, ('%' + ad + '%',))
                result = cursor.fetchall()

                # TableWidget'i temizle ve yeni verileri ekle
                self.ui.twUrunler.setRowCount(len(result))
                for row_num, row_data in enumerate(result):
                    for col_num, col_data in enumerate(row_data):
                        self.ui.twUrunler.setItem(row_num, col_num, QtWidgets.QTableWidgetItem(str(col_data)))

                cursor.close()             
            except mysql.connector.Error as err:
                print("Hata search_product:", err)

        # Arama işlemi bittiğinde kutuları temizle
        self.ui.lnUrunAd.clear()

    def search_product_2(self):                                              # kullanıcı arama ıslemlerı
        ad = self.ui.lnKategoriAd.text()

        connection = self.connection
        if connection is not None:
            try:
                cursor = connection.cursor()
                # SQL sorgusu oluştur ve çalıştır
                query = "SELECT id,kategoriAdi,aciklama FROM kategoriler WHERE kategoriAdi LIKE %s ORDER BY kategoriAdi"
                cursor.execute(query, ('%' + ad + '%',))
                result = cursor.fetchall()

                # TableWidget'i temizle ve yeni verileri ekle
                self.ui.twKategori.setRowCount(len(result))
                for row_num, row_data in enumerate(result):
                    for col_num, col_data in enumerate(row_data):
                        self.ui.twKategori.setItem(row_num, col_num, QtWidgets.QTableWidgetItem(str(col_data)))

                cursor.close()
            except mysql.connector.Error as err:
                print("Hata search_product_2:", err)

        # Arama işlemi bittiğinde kutuları temizle
        self.ui.lnKategoriAd.clear()


