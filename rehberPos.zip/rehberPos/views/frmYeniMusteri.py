from forms.frmYeniMusteriUi import Ui_frmYeniMusteri
from PyQt5 import QtWidgets
from database.connect_to_database import connect_to_database 


class frmYeniMusteri(QtWidgets.QMainWindow):
    def __init__(self):
        super(frmYeniMusteri, self).__init__()
        self.ui = Ui_frmYeniMusteri()
        self.ui.setupUi(self) 
        self.showFullScreen()

        # Database bağlantısı başlat...
        self.connection = connect_to_database() 

        self.ui.btnMusteriKayit.clicked.connect(self.add_customer)
        self.ui.btnGeri.clicked.connect(self.back_application)


    def back_application(self):
        self.close()
        from views.frmMusteriler import frmMusteriler
        self.frm_frmMusteriler = frmMusteriler()
        self.frm_frmMusteriler.show()

    def add_customer(self):
            # Kullanıcının girdiği verileri al
            if ((self.ui.lnAd.text() !="") and (len(self.ui.lnAd.text()) < 15)):
                ad = self.ui.lnAd.text()
            else:
                QtWidgets.QMessageBox.information(self, "HATA", "Müşteri adı 15 karakter olabilir.")
                return

            if ((self.ui.lnSoyad.text() !="") and (len(self.ui.lnSoyad.text()) < 15)):
                soyad = self.ui.lnSoyad.text()
            else:
                QtWidgets.QMessageBox.information(self, "HATA", "Müşteri soyad 15 karakter olabilir..")
                return

            if ((self.ui.lnTelefon.text() !="") and (len(self.ui.lnTelefon.text()) < 12) and (len(self.ui.lnTelefon.text()) > 10)):
                telefon = self.ui.lnTelefon.text()
            else:
                QtWidgets.QMessageBox.information(self, "HATA", "Müşteri telefon 11 karakter olmalıdır.")
                return

            if ((self.ui.lnAdres.text() !="") and (len(self.ui.lnAdres.text()) < 45)):
                adres = self.ui.lnAdres.text()
            else:
                QtWidgets.QMessageBox.information(self, "HATA", "Müşteri adres 45 karakteri olabilir.")
                return

            self.connection = self.connection
            if self.connection is not None:

                # Veritabanına müşteri ekle
                cursor = self.connection.cursor() 
                insert_query = "INSERT INTO musteriler (ad, soyad, telefon, adres) VALUES (%s, %s, %s, %s)"
                values = (ad, soyad, telefon, adres)
                cursor.execute(insert_query, values)
                self.connection.commit()

                # Bilgilendirme mesajı
                QtWidgets.QMessageBox.information(self, "Başarılı", "Musteri başarıyla eklendi.")

                # Girdi kutularını temizle
                self.ui.lnAd.clear()
                self.ui.lnAdres.clear()
                self.ui.lnSoyad.clear()
                self.ui.lnTelefon.clear()
                self.close()

                from views.frmMusteriler import frmMusteriler
                self.frm_frmMusteriler = frmMusteriler()
                self.frm_frmMusteriler.show()
                
