from PyQt5 import QtWidgets
from forms.frmMusteriGuncelleUi import Ui_frmMusteriGuncelle
from database.connect_to_database import connect_to_database

class frmMusteriGuncelle(QtWidgets.QMainWindow):
    def __init__(self,telefon):
        super(frmMusteriGuncelle, self).__init__()
        self.ui = Ui_frmMusteriGuncelle()
        self.ui.setupUi(self) 
        self.showFullScreen()

        # Bağlantıyı başlat...
        self.connection = connect_to_database()

        self.customer_tel = telefon
        self.load_customer_data()
        self.ui.btnMusteriGuncelle.clicked.connect(self.update_customer)        # btnGeri buton tıklama
        self.ui.btnGeri.clicked.connect(self.back_application)

    def back_application(self):
        self.close()
        from views.frmMusteriler import frmMusteriler
        self.frm_frmMusteriler = frmMusteriler()
        self.frm_frmMusteriler.show()
        

    def load_customer_data(self):                                               #musterı bılgılerını getır
        self.connection = self.connection
        if self.connection is not None:
            cursor = self.connection.cursor()
            select_query = "SELECT ad, soyad, telefon, adres FROM musteriler WHERE telefon = %s"
            cursor.execute(select_query, (self.customer_tel,))
            customer_data = cursor.fetchone()


            if customer_data:
                ad, soyad, telefon, adres = customer_data
                self.ui.lnAd.setText(ad)
                self.ui.lnSoyad.setText(soyad)
                self.ui.lnTelefon.setText(telefon)
                self.ui.lnAdres.setText(adres)

    def update_customer(self):                                                  #musterı bılgılerını guncelle
        self.connection = self.connection
        if self.connection is not None:

            # Kullanıcının girdiği verileri al
            if (self.ui.lnAd.text() !=""):
                ad = self.ui.lnAd.text()
            else:
                QtWidgets.QMessageBox.information(self, "HATA", "Müşteri adı boş.")
                return
                
            if (len(self.ui.lnAd.text()) < 15) :
                ad = self.ui.lnAd.text()
            else:
                QtWidgets.QMessageBox.information(self, "HATA", "Müşteri adı 15 karakteri geçemez.")
                return

            if self.ui.lnSoyad.text() !="":
                soyad = self.ui.lnSoyad.text()
            else:
                QtWidgets.QMessageBox.information(self, "HATA", "Müşteri soyad boş.")
                return

            if (len(self.ui.lnSoyad.text()) < 15) :
                soyad = self.ui.lnSoyad.text()
            else:
                QtWidgets.QMessageBox.information(self, "HATA", "Müşteri soyad 15 karakteri geçemez.")
                return

            if self.ui.lnTelefon.text() !="":
                telefon = self.ui.lnTelefon.text()
            else:
                QtWidgets.QMessageBox.information(self, "HATA", "Müşteri telefon boş.")
                return

            if (len(self.ui.lnTelefon.text()) <= 11) :
                telefon = self.ui.lnTelefon.text()
            else:
                QtWidgets.QMessageBox.information(self, "HATA", "Müşteri telefon 11 karakteri geçemez.")
                return

            if self.ui.lnAdres.text() !="":
                adres = self.ui.lnAdres.text()
            else:
                QtWidgets.QMessageBox.information(self, "HATA", "Müşteri adres boş.")
                return

            if (len(self.ui.lnAdres.text()) < 45) :
                adres = self.ui.lnAdres.text()
            else:
                QtWidgets.QMessageBox.information(self, "HATA", "Müşteri adres 45 karakteri geçemez.")
                return
                

            ad = self.ui.lnAd.text()
            soyad = self.ui.lnSoyad.text()
            telefon = self.ui.lnTelefon.text()
            adres = self.ui.lnAdres.text()

            cursor = self.connection.cursor()
            update_query = "UPDATE musteriler SET ad = %s, soyad = %s, telefon = %s, adres = %s WHERE telefon = %s"
            values = (ad, soyad, telefon, adres,self.customer_tel)
            cursor.execute(update_query, values)
            self.connection.commit()

            QtWidgets.QMessageBox.information(self, "Başarılı", "Müşteri bilgileri güncellendi.")

            # Girdi kutularını temizle
            self.ui.lnAd.clear()
            self.ui.lnAdres.clear()
            self.ui.lnTelefon.clear()
            self.ui.lnSoyad.clear()
            self.close()
            from views.frmMusteriler import frmMusteriler
            self.frm_frmMusteriler = frmMusteriler()
            self.frm_frmMusteriler.show()





