from PyQt5 import QtWidgets
import mysql.connector
from forms.frmUrunSilUi import Ui_frmUrunSil
from PyQt5.QtWidgets import QMessageBox
from database.connect_to_database import connect_to_database 

class frmUrunSil(QtWidgets.QMainWindow):
    def __init__(self,urun_id):
        super(frmUrunSil, self).__init__()
        self.ui = Ui_frmUrunSil()
        self.ui.setupUi(self) 
        self.showFullScreen()

        # Bağlantıyı başlat...
        self.connection = connect_to_database()

        self.urunİd = urun_id
        self.load_product_data()
        self.ui.btnUrunSil.clicked.connect(self.delete_product)                # btnmusterısıl buton tıklama
        self.ui.btnGeri.clicked.connect(self.back_application)

    def back_application(self):
        self.close()
        from views.frmMutfak import frmMutfak
        self.frm_frmMutfak = frmMutfak()
        self.frm_frmMutfak.show()

    def load_product_data(self):                                               # urun bılgılerını getır
        self.connection =self.connection
        if self.connection is not None:
            cursor = self.connection.cursor()
            select_query = "SELECT kategoriİd, urunAd,aciklama,fiyat FROM urunler WHERE id = %s"
            cursor.execute(select_query, (self.urunİd,))
            customer_data = cursor.fetchone()

            if customer_data:
                kategori_id,ad,aciklama,fiyat = customer_data
                self.ui.lblKategoriId.setText(str(kategori_id))
                self.ui.lblUrunAd.setText(str(ad))
                self.ui.lblAciklama.setText(str(aciklama))
                self.ui.lblFiyat.setText(str(fiyat))

    def delete_product(self):  # urun sılme ıslemlerı
        confirmation = QMessageBox.critical(self, "Onay", "Ürün Silinsin mi ?", QMessageBox.Ok | QMessageBox.Cancel)
        if confirmation == QMessageBox.Ok:
            connection =self.connection
            if connection:
                try:
                    cursor = connection.cursor()
                    try:
                        # Sipariş silme
                        cursor.execute(
                            "DELETE FROM urunler WHERE id = %s",
                            (self.urunİd,)
                        )
                        connection.commit()  # Değişiklikleri kaydet
                        QMessageBox.information(self, "Bilgi", "Ürün Silindi.")

                        # Label kutularını temizle
                        self.ui.lblAciklama.clear()
                        self.ui.lblFiyat.clear()
                        self.ui.lblKategoriId.clear()
                        self.ui.lblUrunAd.clear()
                        self.close()
                        from views.frmMutfak import frmMutfak
                        self.frm_frmMutfak= frmMutfak()
                        self.frm_frmMutfak.show()

                        
                    except mysql.connector.Error as err:
                        print("Hata:", err)
                        connection.rollback()  # Hata durumunda geri al
                    finally:
                        cursor.close()
                except Exception as ex:
                    print("HATA", ex)
            else:
                return
        elif confirmation == QMessageBox.Cancel:
            return
