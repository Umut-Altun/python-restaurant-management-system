
from forms.frmYeniUrunUi import Ui_frmYeniUrun
from PyQt5 import QtWidgets
import mysql.connector
from database.connect_to_database import connect_to_database 


class frmYeniUrun(QtWidgets.QMainWindow):
    def __init__(self):
        super(frmYeniUrun, self).__init__()
        self.ui = Ui_frmYeniUrun()
        self.ui.setupUi(self) 
        self.showFullScreen()

        # Bağlantıyı başlat...
        self.connection = connect_to_database()

        self.ui.btnUrunKaydet.clicked.connect(self.save_product)                 # btnUrunKaydet buton tıklama
        self.ui.btnGeri.clicked.connect(self.back_application)

    def back_application(self):
        self.close()
        from views.frmMutfak import frmMutfak
        self.frm_frmMutfak = frmMutfak()
        self.frm_frmMutfak.show()

    
    def is_integer(self,text): #sayı kontrol
        try:
            int(text)
            return True
        except ValueError:
            return False

    def save_product(self):
        self.connection =self.connection
        if self.connection is not None:
            if self.ui.lblKategoriId.text() !="":
                kategorId = self.ui.lblKategoriId.text()
            else:
                QtWidgets.QMessageBox.information(self, "HATA", "Kategori id boş.")
                return
            
            if (len(self.ui.lblKategoriId.text()) <= 1):
                kategorId = self.ui.lblKategoriId.text()
            else:
                QtWidgets.QMessageBox.information(self, "HATA", "Kategori id yalnız bir rakam içermelidir.")
                return

            if self.ui.lblUrunAd.text() !="":
                urunAd = self.ui.lblUrunAd.text()
            else:
                QtWidgets.QMessageBox.information(self, "HATA", "Ürün ad boş.")
                return
            
            if (len(self.ui.lblUrunAd.text()) < 45):
                urunAd = self.ui.lblUrunAd.text()
            else:
                QtWidgets.QMessageBox.information(self, "HATA", "Ürün ad 45 karakteri geçemez.")
                return

            if self.ui.lblAciklama.text() !="":
                aciklama = self.ui.lblAciklama.text()
            else:
                QtWidgets.QMessageBox.information(self, "HATA", "Açıklama boş.")
                return
            
            if (len(self.ui.lblAciklama.text()) < 45) :
                aciklama = self.ui.lblAciklama.text()
            else:
                QtWidgets.QMessageBox.information(self, "HATA", "Açıklama 45 karakteri geçemez.")
                return

            if self.ui.lblFiyat.text() !="":
                fiyat = self.ui.lblFiyat.text()
            else:
                QtWidgets.QMessageBox.information(self, "HATA", "Fiyat boş.")
                return
            
            if self.is_integer(self.ui.lblFiyat.text()):
                fiyat = int(self.ui.lblFiyat.text())
            else:
                QtWidgets.QMessageBox.information(self, "HATA", "Fiyat sayı olmalıdır.")
                return

            # Veritabanına müşteri ekle
            cursor = self.connection.cursor() 
            insert_query = "INSERT INTO urunler (kategoriİd, urunAd, aciklama,fiyat) VALUES (%s, %s, %s, %s)"
            values = (kategorId, urunAd, aciklama, fiyat)
            cursor.execute(insert_query, values)
            self.connection.commit()

            # Bilgilendirme mesajı
            QtWidgets.QMessageBox.information(self, "Başarılı", "Ürün başarıyla eklendi.")

            # Girdi kutularını temizle
            self.ui.lblKategoriId.clear()
            self.ui.lblUrunAd.clear()
            self.ui.lblAciklama.clear()
            self.ui.lblFiyat.clear()
            self.close()
            from views.frmMutfak import frmMutfak
            self.frm_frmMutfak = frmMutfak()
            self.frm_frmMutfak.show()


           