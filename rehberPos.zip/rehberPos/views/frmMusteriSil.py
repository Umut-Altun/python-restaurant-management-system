from PyQt5 import QtWidgets
import mysql.connector
from forms.frmMusteriSilUi import Ui_frmMusteriSil
from PyQt5.QtWidgets import QMessageBox
from database.connect_to_database import connect_to_database


class frmMusteriSil(QtWidgets.QMainWindow):
    def __init__(self,telefon):
        super(frmMusteriSil, self).__init__()
        self.ui = Ui_frmMusteriSil()
        self.ui.setupUi(self) 
        self.showFullScreen()

        # Bağlantıyı başlat...
        self.connection = connect_to_database()
        self.customer_tel = int(telefon)
        self.load_customer_data()
        self.ui.btnMusteriSil.clicked.connect(self.delete_customers)        # btnmusterısıl buton tıklama
        self.ui.btnGeri.clicked.connect(self.back_application)

    def back_application(self):
        self.close()
        from views.frmMusteriler import frmMusteriler
        self.frm_frmMusteriler = frmMusteriler()
        self.frm_frmMusteriler.show()
        

    def load_customer_data(self):                                               #musterı bılgılerını getır
        self.connection = self.connection
        if self.connection is not None:
            cursor = self.connection.cursor()
            select_query = "SELECT ad, soyad, telefon, adres FROM musteriler WHERE telefon = %s"
            cursor.execute(select_query, (self.customer_tel,))
            customer_data = cursor.fetchone()

            if customer_data:
                ad, soyad, telefon, adres = customer_data
                self.ui.lnAd.setText(ad)
                self.ui.lnSoyad.setText(soyad)
                self.ui.lnTelefon.setText(telefon)
                self.ui.lnAdres.setText(adres)

    def delete_customers(self):                                                        # musterı sılme ıslemlerı
            confirmation = QMessageBox.critical(self, "Onay", "Musteri Silinsin mi ?", QMessageBox.Ok | QMessageBox.Cancel)
            if confirmation == QMessageBox.Ok:
                connection = self.connection
                if connection:
                    try:
                        cursor = connection.cursor()
                        try:
                            # Sipariş silme
                            cursor.execute(
                                "DELETE FROM musteriler WHERE telefon = %s",
                                (self.customer_tel,)
                            )
                            connection.commit()  # Değişiklikleri kaydet
                            QMessageBox.information(self, "Bilgi", "Musteri Silindi.")
                            
                            # Label kutularını temizle
                            self.ui.lnAd.clear()
                            self.ui.lnAdres.clear()
                            self.ui.lnSoyad.clear()
                            self.ui.lnTelefon.clear()
                            self.close()
                            from views.frmMusteriler import frmMusteriler
                            self.frm_frmMusteriler = frmMusteriler()
                            self.frm_frmMusteriler.show()

                            
                        except mysql.connector.Error as err:
                            print("Hata delete_customers:", err)
                            connection.rollback()  # Hata durumunda geri al
                        finally:
                            cursor.close()
                    except Exception as ex:
                        print("HATA delete_customers", ex)
                else:
                    return
            elif confirmation == QMessageBox.Cancel:
                return

