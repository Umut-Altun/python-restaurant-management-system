from forms.frmKlavyeUi import Ui_frmKlavye
from PyQt5 import QtWidgets

class frmKlavye(QtWidgets.QMainWindow):
    def __init__(self, selected_row, parent):
        super(frmKlavye, self).__init__() 
        self.ui = Ui_frmKlavye()
        self.ui.setupUi(self)
        self.selected_row = selected_row
        self.parent = parent

        screen_rect = QtWidgets.QDesktopWidget().screenGeometry()
        window_rect = self.geometry()
        x_position = (screen_rect.width() - window_rect.width()) // 2
        y_position = (screen_rect.height() - window_rect.height()) // 2 + 200  # aşağıya kaydır
        self.move(x_position, y_position)

        #--Hesap Makınesı--
        self.ui.btn1.clicked.connect(lambda: self.add_digit(1)) 
        self.ui.btn2.clicked.connect(lambda: self.add_digit(2))
        self.ui.btn3.clicked.connect(lambda: self.add_digit(3))
        self.ui.btn4.clicked.connect(lambda: self.add_digit(4))
        self.ui.btn5.clicked.connect(lambda: self.add_digit(5))
        self.ui.btn6.clicked.connect(lambda: self.add_digit(6))
        self.ui.btn7.clicked.connect(lambda: self.add_digit(7))
        self.ui.btn8.clicked.connect(lambda: self.add_digit(8))
        self.ui.btn9.clicked.connect(lambda: self.add_digit(9))
        self.ui.btn0.clicked.connect(lambda: self.add_digit(0))

        self.ui.btnq.clicked.connect(lambda: self.add_digit("Q")) 
        self.ui.btnw.clicked.connect(lambda: self.add_digit("W"))
        self.ui.btne.clicked.connect(lambda: self.add_digit("E"))
        self.ui.btnr.clicked.connect(lambda: self.add_digit("R"))
        self.ui.btnt.clicked.connect(lambda: self.add_digit("T"))
        self.ui.btny.clicked.connect(lambda: self.add_digit("Y"))
        self.ui.btnu.clicked.connect(lambda: self.add_digit("U"))
        self.ui.btni.clicked.connect(lambda: self.add_digit("I"))
        self.ui.btno.clicked.connect(lambda: self.add_digit("O"))
        self.ui.btnp.clicked.connect(lambda: self.add_digit("P"))
        self.ui.btna.clicked.connect(lambda: self.add_digit("A"))
        self.ui.btns.clicked.connect(lambda: self.add_digit("S"))
        self.ui.btnd.clicked.connect(lambda: self.add_digit("D"))
        self.ui.btnf.clicked.connect(lambda: self.add_digit("F"))
        self.ui.btng.clicked.connect(lambda: self.add_digit("G"))
        self.ui.btnh.clicked.connect(lambda: self.add_digit("H"))
        self.ui.btnj.clicked.connect(lambda: self.add_digit("J"))
        self.ui.btnk.clicked.connect(lambda: self.add_digit("K"))
        self.ui.btnl.clicked.connect(lambda: self.add_digit("L"))
        self.ui.btnz.clicked.connect(lambda: self.add_digit("Z"))
        self.ui.btnx.clicked.connect(lambda: self.add_digit("X"))
        self.ui.btnc.clicked.connect(lambda: self.add_digit("C"))
        self.ui.btnv.clicked.connect(lambda: self.add_digit("V"))
        self.ui.btnb.clicked.connect(lambda: self.add_digit("B"))
        self.ui.btnn.clicked.connect(lambda: self.add_digit("N"))
        self.ui.btnm.clicked.connect(lambda: self.add_digit("M"))

        self.ui.btnEt.clicked.connect(lambda: self.add_digit("@"))
        self.ui.btnNokta.clicked.connect(lambda: self.add_digit("."))
        self.ui.btnSolParentez.clicked.connect(lambda: self.add_digit("("))
        self.ui.btnSagParentez.clicked.connect(lambda: self.add_digit(")"))
        self.ui.btnSlash.clicked.connect(lambda: self.add_digit("/"))
        self.ui.btnBosluk.clicked.connect(lambda: self.add_digit("  "))
        self.ui.btnTire.clicked.connect(lambda: self.add_digit("-"))
        self.ui.btnAlt.clicked.connect(lambda: self.add_digit("_"))
        self.ui.btnYldz.clicked.connect(lambda: self.add_digit("*"))
        self.ui.btnTemizle.clicked.connect(self.clear_line_edit)
        self.ui.btnSil.clicked.connect(self.clear_line_text)
        self.ui.btnKaydet.clicked.connect(self.save_notes)

    def add_digit(self, digit):                                       #1-9 rakam gönderme
        current_text = self.ui.lblMetin.text()
        new_text = current_text + str(digit)
        self.ui.lblMetin.setText(new_text)
    
    def clear_line_edit(self):                                        #temizle butonu
        self.ui.lblMetin.clear()

    def clear_line_text(self):
        current_text = self.ui.lblMetin.text()
        if current_text:
            new_text = current_text[:-1]  # Remove the last character
            self.ui.lblMetin.setText(new_text)

    def save_notes(self):
        updated_notes = self.ui.lblMetin.text()
        self.parent.ui.twSiparis.item(self.selected_row, 2).setText(updated_notes)
        self.close()