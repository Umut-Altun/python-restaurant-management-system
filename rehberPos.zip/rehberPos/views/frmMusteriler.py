from PyQt5 import QtWidgets
import mysql.connector
from forms.frmMusterilerUi import Ui_frmMusteriler
from database.connect_to_database import connect_to_database


class frmMusteriler(QtWidgets.QMainWindow):
    def __init__(self):
        super(frmMusteriler, self).__init__()
        self.ui = Ui_frmMusteriler()
        self.ui.setupUi(self) 
        self.showFullScreen()

        # Bağlantıyı başlat...
        self.connection = connect_to_database()

        self.ui.btnGeri.clicked.connect(self.back_application)                      #btnGeri buton tıklama
        self.ui.btnYeniMusteri.clicked.connect(self.get_add_customer)               #btnMusterıEkle buton tıklama
        self.ui.btnMusteriGuncelle.clicked.connect(self.get_update_customer)        #btnMusterıguncelle buton tıklama
        self.ui.btnMusteriSil.clicked.connect(self.get_delete_customer)                #btnMusterıSIl buton tıklama
        self.ui.btnAra.clicked.connect(self.search_customer_by_name)                #btnArama buton tıklama
        self.load_data()                                                            #Musterılerı tabloya ekle


    def load_data(self):                                                            #Musterılerı tabloya ekle
        connection = self.connection
        if connection is not None:
            try:
                cursor = connection.cursor()
                # Verileri çek
                cursor.execute("SELECT ad, soyad, telefon, adres FROM musteriler")
                result = cursor.fetchall()

                # TableWidget'e verileri ekle
                self.ui.twMusteriler.setRowCount(len(result))
                self.ui.twMusteriler.setColumnCount(4)

                for row_num, row_data in enumerate(result):
                    for col_num, col_data in enumerate(row_data):
                        self.ui.twMusteriler.setItem(row_num, col_num, QtWidgets.QTableWidgetItem(str(col_data)))

                cursor.close()
            except mysql.connector.Error as err:
                print("Hata load_data:", err)

    def back_application(self):                                                     #pencere kapatma
        self.close()
        from views.frmMenu import frmMenu
        self.frm_frmMenu = frmMenu()
        self.frm_frmMenu.show()

        
    def get_add_customer(self):                                                     #musterı ekle 
        self.close()
        from views.frmYeniMusteri import frmYeniMusteri
        self.frm_musterı = frmYeniMusteri()
        self.frm_musterı.show()
    
    def get_update_customer(self):                                                  #musteri guncelle
        selected_row = self.ui.twMusteriler.currentRow()  # Tablodan seçilen satırı al

        if selected_row >= 0:
            self.close()
            telefon = self.ui.twMusteriler.item(selected_row, 2).text()  # Tablodan telefon numarasını al
            from views.frmMusteriGuncelle import frmMusteriGuncelle
            self.frm_musteriGuncelle = frmMusteriGuncelle(telefon)
            self.frm_musteriGuncelle.show()
        else:
            QtWidgets.QMessageBox.information(self, "Hata", "Müşteri seçilmedi.")

    def search_customer_by_name(self):                                              # musterı arama ıslemlerı
        ad = self.ui.lnAd.text()
        soyad = self.ui.lnSoyad.text()  # lnSoyad'dan metni al
        telefon = self.ui.lnTelefon.text()  # lnTelefon'dan metni al

        connection = self.connection
        if connection is not None:
            try:
                cursor = connection.cursor()
                # SQL sorgusu oluştur ve çalıştır
                query = "SELECT ad, soyad, telefon, adres FROM musteriler WHERE ad LIKE %s AND soyad LIKE %s AND telefon LIKE %s ORDER BY ad"
                cursor.execute(query, ('%' + ad + '%', '%' + soyad + '%', '%' + telefon + '%'))
                result = cursor.fetchall()

                # TableWidget'i temizle ve yeni verileri ekle
                self.ui.twMusteriler.setRowCount(len(result))
                for row_num, row_data in enumerate(result):
                    for col_num, col_data in enumerate(row_data):
                        self.ui.twMusteriler.setItem(row_num, col_num, QtWidgets.QTableWidgetItem(str(col_data)))

                cursor.close()
            except mysql.connector.Error as err:
                print("Hata search_customer_by_name:", err)

        # Arama işlemi bittiğinde kutuları temizle
        self.ui.lnAd.clear()
        self.ui.lnSoyad.clear()
        self.ui.lnTelefon.clear()
 
    def get_delete_customer(self): # musterı sil ıslemlerı
        selected_row = self.ui.twMusteriler.currentRow()  # Tablodan seçilen satırı al

        if selected_row >= 0:
            self.close()
            telefon = self.ui.twMusteriler.item(selected_row, 2).text()  # Tablodan telefon numarasını al
            from views.frmMusteriSil import frmMusteriSil
            self.frm_frmMusteriSil = frmMusteriSil(telefon)
            self.frm_frmMusteriSil.show()
        else:
            QtWidgets.QMessageBox.information(self, "Hata", "Müşteri seçilmedi.")








