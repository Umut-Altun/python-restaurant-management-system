from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QTableWidgetItem
from PyQt5.QtCore import QDateTime
from PyQt5.QtWidgets import QMessageBox
from forms.frmPaketOdemeUi import Ui_frmPaketOdeme
import mysql.connector
from datetime import datetime
from database.connect_to_database import connect_to_database



class frmPaketOdeme(QtWidgets.QMainWindow):
    def __init__(self):
        super(frmPaketOdeme, self).__init__()
        self.ui = Ui_frmPaketOdeme()
        self.ui.setupUi(self) 
        self.showFullScreen()

        # Database bağlantıyı başlat...
        self.connection = connect_to_database() 

        self.ui.btnGeri.clicked.connect(self.back_application)                      # btnGeri buton tıklama
        self.ui.btnHesapKapat.clicked.connect(self.close_account)                   # hesap kapatma ıslemlerı
        self.ui.btnHesapOzet.clicked.connect(self.paket_yazdir)                     # adisyon yazdırma
        self.ui.btnUrunGetir.clicked.connect(self.populate_table)                   # sıparısı adısyona akatarma
        self.ui.btnUrunGetir.clicked.connect(self.musteri_aktar)                   # sıparısı adısyona akatarma
        self.ui.btnIptal.clicked.connect(self.cancel_account)                       # masa iptal akatarma

 
    def set_masa_info(self, masa_no):                                               # masa numarasını al
            self.ui.lblOdemeMasaNo.setText(masa_no)

    def populate_table(self):                                                       # sıparısı adısyona akatarma
            self.masa = self.ui.lblOdemeMasaNo.text()
            self.masa_no = int(self.masa[6:])
            self.servis_turu="paket"
            self.durum="acik"
            # Veritabanı bağlantısını alın
            connection = self.connection
            if connection:
                try:
                    cursor = connection.cursor()
                    # Siparişleri veritabanından al
                    cursor.execute(
                        "SELECT s.id, s.urunİd, s.adisyonİd, s.masaİd, s.adet, u.urunAd, u.fiyat " \
                        "FROM satislar AS s " \
                        "INNER JOIN urunler AS u ON s.urunİd = u.id " \
                        "WHERE s.masaİd = %s AND s.servisTuru = %s AND s.durum = %s" ,
                        (self.masa_no, self.servis_turu, self.durum,)
                    )
                    
                    # Tabloyu temizle
                    self.ui.twSiparisOdeme.setRowCount(0)

                    total_price = 0  # Toplam fiyatı başlat
                    # Verileri tabloya ekleyin ve fiyatları toplayın
                    for row_num, (satis_id, urun_id, adisyon_id,masa_id, adet, urun_adi, fiyat) in enumerate(cursor.fetchall()):
                        self.ui.twSiparisOdeme.insertRow(row_num)
                        self.ui.twSiparisOdeme.setItem(row_num, 0, QTableWidgetItem(urun_adi))
                        self.ui.twSiparisOdeme.setItem(row_num, 1, QTableWidgetItem(str(adet)))
                        self.ui.twSiparisOdeme.setItem(row_num, 2, QTableWidgetItem(str(fiyat)))
                        self.ui.twSiparisOdeme.setItem(row_num, 3, QTableWidgetItem(str(satis_id)))
                        self.ui.twSiparisOdeme.setItem(row_num, 4, QTableWidgetItem(str(urun_id)))
                        self.ui.twSiparisOdeme.setItem(row_num, 5, QTableWidgetItem(str(adisyon_id)))
                        self.ui.twSiparisOdeme.setItem(row_num, 6, QTableWidgetItem(str(masa_id)))

                        # Her ürünün adetini fiyatıyla çarp ve toplam fiyata ekle
                        item_total = adet * fiyat
                        total_price += item_total

                    # Toplam fiyatı lblToplamTutar içinde göster
                    self.ui.lblToplamTutar.setText(str(total_price))

                except mysql.connector.Error as err:
                    print("Hata:", err)
                finally:
                    self.ui.twSiparisOdeme.repaint()
                    cursor.close()
                    

    def close_account(self):                                                        # hesap kapatma ıslemlerı
        self.masa = self.ui.lblOdemeMasaNo.text()
        self.masa_no = int(self.masa[5:])
        connection = self.connection

        if self.ui.btnHesapKapat.clicked:
            confirmation = QMessageBox.critical(self, "Onay", "Masa Kapatılsın mı?", QMessageBox.Ok | QMessageBox.Cancel)
            if confirmation == QMessageBox.Ok:
                if connection:
                    try:
                        cursor = connection.cursor()

                        # Adisyon ID'lerini bir küme (set) olarak saklayın
                        adisyon_ids = set()

                        # Sipariş verilerini al ve her adisyon için toplam tutarı hesaplayın
                        adisyon_totals = {}  # Adisyon ID'ye göre toplam tutarları saklayın

                        for row_num in range(self.ui.twSiparisOdeme.rowCount()):
                            adisyon_id = int(self.ui.twSiparisOdeme.item(row_num, 5).text())
                            adisyon_ids.add(adisyon_id)  # Her adisyonu bir kez ekleyin

                            # Siparişlerin toplam tutarını hesaplayın ve saklayın
                            item_price = float(self.ui.twSiparisOdeme.item(row_num, 2).text())
                            item_quantity = int(self.ui.twSiparisOdeme.item(row_num, 1).text())
                            item_total = item_price * item_quantity

                            if adisyon_id in adisyon_totals:
                                adisyon_totals[adisyon_id] += item_total
                            else:
                                adisyon_totals[adisyon_id] = item_total

                        # Her adisyon için bir ödeme işlemi oluşturun ve masa durumunu güncelleyin
                        for adisyon_id in adisyon_ids:
                            toplam_tutar = adisyon_totals[adisyon_id]  # Hesaplanmış toplam tutarı alın
                            tarih = QDateTime.currentDateTime().toString("yyyy-MM-dd HH:mm:ss")
                            servis_turu ="paket"
                            payment_type ="DIGER"

                            print(f"\n>--- Masanın Kapatma İşlemleri Başladı ---<")
                            try:
                                # Verileri başka bir tabloya ekleyin
                                cursor.execute(
                                    "INSERT INTO hesapodemeleri (adisyonİd, odemeTuru, toplamTutar, tarih,servisTuru) VALUES (%s, %s, %s, %s, %s)",
                                    (adisyon_id, payment_type, toplam_tutar, tarih,servis_turu)
                                )
                                print(f"Paket Masa {self.masa_no} Hesap Ödemeleri Alındı...")
                            except Exception as ex:
                                print("HATA",ex)
                            try:
                                # Masa durumunu güncelleyin
                                cursor.execute(
                                    "UPDATE paketmasalar SET durum = %s, masaDurum = %s WHERE id = %s",
                                    (1, 'kapalı', self.masa_no,)
                                )
                                print(f"Paket Masa {self.masa_no} Durumu Kapatıldı...")
                            except Exception as ex:
                                print("HATA",ex)
                            try:
                                cursor.execute(
                                    "UPDATE adisyonlar SET durum = %s WHERE masaİd = %s AND servisTuru = %s",
                                    ("kapalı", self.masa_no,servis_turu,)
                                )
                                print(f"Paket Masa {self.masa_no} Adisyonu Kapatıldı...")
                            except Exception as ex:
                                print("HATA:", ex)

                            try:
                                cursor.execute(
                                    "UPDATE satislar SET durum = %s WHERE masaİd = %s AND servisTuru = %s",
                                    ("kapalı", self.masa_no,servis_turu,)
                                )
                                print(f"Paket Masa {self.masa_no}  Satışları Kapatıldı...")
                            except Exception as ex:
                                print("HATA:", ex) 

                            try:
                                masaIdNo = f"Paket {self.masa_no}"
                                cursor.execute(
                                    "UPDATE paketsiparisler SET durum = %s WHERE masaNo = %s AND durum = %s",
                                    ("kapalı",masaIdNo,"acik",)
                                )
                                print(f"Paket Masa {self.masa_no} Siparişleri Kapatıldı...")

                            except Exception as ex:
                                print("HATA:", ex)

                            print(f">--- Masanın Kapatma İşlemleri Bitti ---<")
                            
                        # Veritabanı değişikliklerini kaydet
                        connection.commit()

                        # Hesap ödemesini tamamladıktan sonra, tabloyu temizle ve toplam tutarı sıfırla
                        self.ui.twSiparisOdeme.setRowCount(0)
                        self.ui.lblToplamTutar.setText("0.0")
                        self.close()
                        from views.frmPaket import frmPaket
                        self.frm_frmPaket = frmPaket()
                        self.frm_frmPaket.show()

                    except mysql.connector.Error as err:
                        print("Hata:", err)
                    finally:
                        cursor.close()
                else:
                    return
            elif confirmation == QMessageBox.Cancel:
                    return
 
    def back_application(self):                                                     # geri gel
        self.close()
        from views.frmPaket import frmPaket
        self.frm_siparis = frmPaket()
        self.frm_siparis.show()

    def populate(self, table_data):                                                 # frmAdisyonFiş verileri aktarın
        for row_num, row_data in enumerate(table_data):
            self.ui.twIcindekiler.insertRow(row_num)
            for col_num, cell_data in enumerate(row_data):
                self.ui.twIcindekiler.setItem(row_num, col_num, QTableWidgetItem(cell_data))

    def cancel_account(self):                                                        # hesap iptal ıslemlerı
        self.masa = self.ui.lblOdemeMasaNo.text()
        self.masa_no = int(self.masa[6:])
        connection = self.connection
        payment_type = "İptal"

        if self.ui.btnIptal.clicked:
            confirmation = QMessageBox.critical(self, "Onay", "Masa İptal Edilsin mi ?", QMessageBox.Ok | QMessageBox.Cancel)
            if confirmation == QMessageBox.Ok:

                if connection:
                    try:
                        cursor = connection.cursor()

                        # Adisyon ID'lerini bir küme (set) olarak saklayın
                        adisyon_ids = set()

                        # Sipariş verilerini al ve her adisyon için toplam tutarı hesaplayın
                        adisyon_totals = {}  # Adisyon ID'ye göre toplam tutarları saklayın

                        for row_num in range(self.ui.twSiparisOdeme.rowCount()):
                            adisyon_id = int(self.ui.twSiparisOdeme.item(row_num, 5).text())
                            adisyon_ids.add(adisyon_id)  # Her adisyonu bir kez ekleyin

                            # Siparişlerin toplam tutarını hesaplayın ve saklayın
                            item_price = float(self.ui.twSiparisOdeme.item(row_num, 2).text())
                            item_quantity = int(self.ui.twSiparisOdeme.item(row_num, 1).text())
                            item_total = item_price * item_quantity

                            if adisyon_id in adisyon_totals:
                                adisyon_totals[adisyon_id] += item_total
                            else:
                                adisyon_totals[adisyon_id] = item_total

                        # Her adisyon için bir ödeme işlemi oluşturun ve masa durumunu güncelleyin
                        for adisyon_id in adisyon_ids:
                            toplam_tutar = adisyon_totals[adisyon_id]  # Hesaplanmış toplam tutarı alın
                            tarih = QDateTime.currentDateTime().toString("yyyy-MM-dd HH:mm:ss")
                            servis_turu ="paket"
                            
                            try:
                                # Masa durumunu güncelleyin
                                cursor.execute(
                                    "UPDATE paketmasalar SET durum = %s, masaDurum = %s WHERE id = %s",
                                    (1, 'kapalı', self.masa_no,)
                                )
                                print("MASA DURUM GÜNCELLENDİ")
                            except Exception as ex:
                                print("HATA",ex)
                            try:
                                # Masa durumunu güncelleyin
                                cursor.execute(
                                    "UPDATE adisyonlar SET servisTuru = %s,durum = %s WHERE durum = %s AND masaİd = %s AND servisTuru = %s " ,
                                    ('iptal','kapalı','acik', self.masa_no,'paket')
                                )
                                print("SERVİS-- TURU GÜNCELLENDİ")
                            except Exception as ex:
                                print("HATA",ex)
                            try:
                                # Sıparıs sılme
                                cursor.execute(
                                    "DELETE FROM satislar WHERE masaİd = %s AND servisTuru = %s",
                                    (self.masa_no,servis_turu,)
                                )
                                print("SIPARIS SILME GÜNCELLENDİ")
                            except Exception as ex:
                                print("HATA",ex)

                        # Veritabanı değişikliklerini kaydet
                        connection.commit()

                        # Hesap ödemesini tamamladıktan sonra, tabloyu temizle ve toplam tutarı sıfırla
                        self.ui.twSiparisOdeme.setRowCount(0)
                        self.ui.lblToplamTutar.setText("0.0")
                        self.close()
                        from views.frmPaket import frmPaket
                        self.frm_frmPaket = frmPaket()
                        self.frm_frmPaket.show()

                    except mysql.connector.Error as err:
                        print("Hata:", err)
                    finally:
                        cursor.close()
                else:
                    return
            elif confirmation == QMessageBox.Cancel:
                    return

    def paket_yazdir(self):
        masaNo = self.ui.lblOdemeMasaNo.text()
        connection = self.connection
        simdiki_zaman = datetime.now().strftime("%H:%M") 
        try:
            cursor = connection.cursor()
            with open( "adisyon_fisi.txt", "w", encoding="utf-8") as dosya:
                    # Sorguyu çalıştırarak verileri al
                    cursor.execute("SELECT ad, soyad, telefon, adres, odemeTuru FROM paketsiparisler WHERE masaNo = %s AND durum = %s",
                        (masaNo, "acik"))

                    for row in cursor.fetchall():
                        ad, soyad, telefon, adres, odeme_turu = row

                        # Ek bilgileri dosyaya yaz
                        simdiki_zaman = datetime.now().strftime("%H:%M")  
                        dosya.write("-------- REHBER ADİSYON ---------\n\n")
                        dosya.write(f"Saat: {simdiki_zaman}\n")
                        dosya.write(f"No: {odeme_turu}\n\n")

                        dosya.write(f"Ad   : {ad}\n")
                        dosya.write(f"Soyad: {soyad}\n")
                        dosya.write(f"TelNo: {telefon}\n")
                        if len(adres) > 26:
                            # 28 karakterden sonra bir alt satıra geç
                            dosya.write(f"Adres: {adres[:26]}\n")
                            dosya.write(f"{adres[26:]}\n\n")
                        else:
                            dosya.write(f"Adres: {adres}\n\n")

                        # Sipariş bilgilerini dosyaya yaz
                        dosya.write("Ürün\tAdet\tFiyat\n")
                        for row in range(self.ui.twSiparisOdeme.rowCount()):
                            if self.ui.twSiparisOdeme.item(row, 0) and self.ui.twSiparisOdeme.item(row, 1) and self.ui.twSiparisOdeme.item(row, 2):
                                urun = self.ui.twSiparisOdeme.item(row, 0).text()
                                adet = self.ui.twSiparisOdeme.item(row, 1).text()
                                fiyat = self.ui.twSiparisOdeme.item(row, 2).text()
                                dosya.write(f"{urun.ljust(21)}{adet.ljust(9)}{fiyat}\n")

                        # Toplam tutarı dosyaya yaz
                        dosya.write(f"\nTOPLAM TUTAR: {self.ui.lblToplamTutar.text()}")
                        dosya.write("\n\n------ İyi Günler Dileriz -------")
                    print("paket fiş dosyasına yazıldı.")

            #-------------- Masa durumunu güncelleyin----------------------
            try:
                cursor.execute("UPDATE paketsiparisler SET durum = %s WHERE masaNo = %s and durum = %s",
                            ("kapalı", masaNo, "acik"))
                print(f"No {masaNo} için sipariş güncel kapatıldı.")
            except Exception as ex:
                print("HATA UPDATE paketsiparisler ", ex)
            #-----------------------------------------------------------------

        except Exception as e:
            print(f"Hata: {e}")
        finally:
            cursor.close()
            
    def musteri_aktar(self):
        masaNo = self.ui.lblOdemeMasaNo.text()
        connection = self.connection
        if connection is not None:
            try:
                cursor = connection.cursor()
                # Verileri çek
                cursor.execute(f"SELECT ad, soyad, adres, telefon FROM paketsiparisler WHERE masaNo = '{masaNo}' AND durum = 'acik'")
                result = cursor.fetchall()

                for row_num, row_data in enumerate(result):
                    self.ui.ldAd.setText(row_data[0])  # İlk sütun ad
                    self.ui.lnSoyad.setText(row_data[1])  # İkinci sütun soyad
                    self.ui.lnAdres.setText(row_data[2])  # Üçüncü sütun adres
                    self.ui.lnTelefon.setText(row_data[3])  # Dördüncü sütun telefon

                cursor.close()
            except mysql.connector.Error as err:
                print("Hata:", err)
