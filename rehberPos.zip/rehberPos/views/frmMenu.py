from PyQt5 import QtWidgets
import mysql.connector
from forms.frmMenuUi import Ui_frmMenu
from PyQt5.QtCore import QTimer
from datetime import datetime
from scripts.wifi import update_wifi_status 
from database.connect_to_database import connect_to_database


class frmMenu(QtWidgets.QMainWindow):
    def __init__(self):
        super(frmMenu, self).__init__()
        self.ui = Ui_frmMenu()
        self.ui.setupUi(self) 
        self.showFullScreen()
        self.ui.lblTelefon.setText("0553 327 ** **")

        self.ui.btnMasalar.clicked.connect(self.tables_application)
        self.ui.btnPaketler.clicked.connect(self.package_application)
        self.ui.btnMusteriler.clicked.connect(self.customer_application)
        self.ui.btnAyarlar.clicked.connect(self.settings_application)
        self.ui.btnMutak.clicked.connect(self.kitchen_application)
        self.ui.btnRaporlar.clicked.connect(self.report_application)
        self.ui.btnCikis.clicked.connect(self.exit_application)
        self.ui.btnKilit.clicked.connect(self.back_application)

        self.connection = connect_to_database()

        # Başlangıçta saat ve tarihi güncelle
        self.guncelle_saat_tarih()
        timer = QTimer(self)
        timer.timeout.connect(self.guncelle_saat_tarih)
        timer.start(1000) 

        # Wi-Fi durumunu kontrol etmek için bir timer oluşturun
        self.timer = QTimer(self) 
        self.timer.timeout.connect(self.check_wifi_status) 
        self.timer.start(15000)

        # Kullanıcı kontrolünü yapın
        self.authorized_user()  


    def check_wifi_status(self):
        update_wifi_status(self.ui)  # UI bileşenini geçirerek durumu kontrol edin

    def authorized_user(self): # Kullanıcı kontrolünü yapın
        try:
            # Veritabanına bağlanın
            connection = self.connection
            if connection is not None:
                cursor = connection.cursor()

                # Son eklenen kaydı alın
                query = "SELECT personelAd FROM personelhareketleri ORDER BY tarih DESC LIMIT 1"
                cursor.execute(query)
                last_user = cursor.fetchone()

                if last_user and last_user[0] == "admin":
                    # Son kullanıcı admin ise, tüm butonlar etkinleştirilir
                    self.enable_all_buttons()
                    self.ui.lblKullanici.setText(last_user[0])

                else:
                    # Diğer durumlarda sadece belirli butonlar etkinleştirilir
                    self.enable_specific_buttons_for_non_admin()
                    self.ui.lblKullanici.setText(last_user[0])

                cursor.close()

        except mysql.connector.Error as err:
            print("Veritabanı Hatası authorized_user:", err)

    def enable_specific_buttons_for_non_admin(self):
        # Sadece belirli butonları etkinleştir (admin olmayan kullanıcılar için)
        self.ui.btnMasalar.setEnabled(True)
        self.ui.btnPaketler.setEnabled(True)
        self.ui.btnKilit.setEnabled(True)
        self.ui.btnCikis.setEnabled(True)
        # Diğer butonları devre dışı bırak
        self.ui.btnMusteriler.setEnabled(False)
        self.ui.btnAyarlar.setEnabled(False)
        self.ui.btnMutak.setEnabled(False)
        self.ui.btnRaporlar.setEnabled(False)

    def enable_all_buttons(self):# Kullanıcı kontrolünü yap buton ac
        # Tüm butonları etkinleştir
        for button in self.findChildren(QtWidgets.QPushButton):
            button.setEnabled(True)

    def tarih_metnini_olustur(self):
        su_an = datetime.now()
        gunler = ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar"]
        aylar = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"]
        
        gun = gunler[su_an.weekday()]  # haftanın günü
        ay = aylar[su_an.month - 1]   # ayın adı
        tarih_metni = "{} {} {}".format(su_an.day, ay, gun)
        return tarih_metni

    def guncelle_saat_tarih(self):
        su_an = datetime.now()
        saat_metni = su_an.strftime("%H:%M")  # Sadece saat ve dakika
        tarih_metni = self.tarih_metnini_olustur()
        self.ui.lblSaat.setText(saat_metni)
        self.ui.lblTarih.setText(tarih_metni)

    def tables_application(self):  #masalara geçme
        self.close()
        from views.frmMasalar import frmMasalar
        self.frm_masalar = frmMasalar()
        self.frm_masalar.show()

    def package_application(self):  #paket işlemlerine geçme
        self.close()
        from views.frmPaket import frmPaket
        self.frm_paket = frmPaket()
        self.frm_paket.show()

    def customer_application(self):  #musteri işlemlerine geçme
        self.close()
        from views.frmMusteriler import frmMusteriler
        self.frm_paket = frmMusteriler()
        self.frm_paket.show()
    
    def settings_application(self):  #ayarlar işlemlerine geçme
        self.close()
        from frmAyarlar import frmAyarlar
        self.frm_paket = frmAyarlar()
        self.frm_paket.show()

    def kitchen_application(self):  #mutfak işlemlerine geçme
        self.close()
        from views.frmMutfak import frmMutfak
        self.frm_paket = frmMutfak()
        self.frm_paket.show()

    def report_application(self):  #rapor işlemlerine geçme
        self.close()
        from views.frmRaporlar import frmRaporlar
        self.frm_paket = frmRaporlar()
        self.frm_paket.show()

    def exit_application(self):  #programı kapatma
        QtWidgets.QApplication.quit()

    def back_application(self):  #pencereyi kapatma
        self.close()
        from views.frmGiris import frmGiris
        self.frm_giris = frmGiris()
        self.frm_giris.show()

