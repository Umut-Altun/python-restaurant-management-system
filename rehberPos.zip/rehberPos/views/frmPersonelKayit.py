from PyQt5 import QtWidgets
from forms.frmPersonelKayitUi import Ui_frmPersonelKaydet
from database.connect_to_database import connect_to_database 


class frmPersonelKayit(QtWidgets.QMainWindow):
    def __init__(self):
        super(frmPersonelKayit, self).__init__()
        self.ui = Ui_frmPersonelKaydet()
        self.ui.setupUi(self) 
        self.showFullScreen()

        # Database bağlantısı başlat...
        self.connection = connect_to_database()

        self.ui.btnPersonelKayit.clicked.connect(self.save_users)                 # personel kayıt buton tıklama
        self.ui.btnGeri.clicked.connect(self.back_application)

    def back_application(self):
        self.close()
        from views.frmAyarlar import frmAyarlar
        self.frm_frmAyarlar = frmAyarlar()
        self.frm_frmAyarlar.show()
        
    
    def save_users(self):
        self.connection = self.connection
        if self.connection is not None:
            if self.ui.lnAd.text() !="":
                lnAd = self.ui.lnAd.text()
            else:
                QtWidgets.QMessageBox.information(self, "HATA", "Ad boş.")
                return

            if (len(self.ui.lnAd.text()) < 15) :
                lnAd = self.ui.lnAd.text()
            else:
                QtWidgets.QMessageBox.information(self, "HATA", "Ad 20 karakteri geçemez.")
                return

            if self.ui.lnSoyad.text() !="":
                lnSoyad = self.ui.lnSoyad.text()
            else:
                QtWidgets.QMessageBox.information(self, "HATA", "Soyad ad boş.")
                return

            if (len(self.ui.lnSoyad.text()) < 20) :
                lnSoyad = self.ui.lnSoyad.text()
            else:
                QtWidgets.QMessageBox.information(self, "HATA", "Soyad 20 karakteri geçemez.")
                return

            if self.ui.lnSifre.text() !="":
                lnSifre = self.ui.lnSifre.text()
            else:
                QtWidgets.QMessageBox.information(self, "HATA", "Şifre boş.")
                return
            
            if (len(self.ui.lnSifre.text()) < 15) :
                lnSifre = self.ui.lnSifre.text()
            else:
                QtWidgets.QMessageBox.information(self, "HATA", "Şifre 15 karakteri geçemez.")
                return

            if self.ui.lnGorevId.text() !="":
                lnGorevId = self.ui.lnGorevId.text()
            else:
                QtWidgets.QMessageBox.information(self, "HATA", "Görev boş.")
                return

            if (len(self.ui.lnGorevId.text()) < 15) :
                lnGorevId = self.ui.lnGorevId.text()
            else:
                QtWidgets.QMessageBox.information(self, "HATA", "Görev 15 karakteri geçemez.")
                return

            # Veritabanına müşteri ekle
            cursor = self.connection.cursor() 
            insert_query = "INSERT INTO personeller (ad, soyad, sifre,gorev) VALUES (%s, %s, %s, %s)"
            values = (lnAd, lnSoyad, lnSifre, lnGorevId)
            cursor.execute(insert_query, values)
            self.connection.commit()

            # Bilgilendirme mesajı
            QtWidgets.QMessageBox.information(self, "Başarılı", "Personel başarıyla eklendi.")

            # Girdi kutularını temizle
            self.ui.lnAd.clear()
            self.ui.lnSoyad.clear()
            self.ui.lnSifre.clear()
            self.ui.lnGorevId.clear()
            self.close()
            from views.frmAyarlar import frmAyarlar
            self.frm_frmAyarlar = frmAyarlar()
            self.frm_frmAyarlar.show()

