from PyQt5 import QtWidgets
from forms.frmRaporlarUi import Ui_frmRaporlar
from datetime import datetime, timedelta
from database.connect_to_database import connect_to_database 
import mysql.connector
from PyQt5.QtWidgets import QProgressDialog, QMessageBox


class frmRaporlar(QtWidgets.QMainWindow):
    def __init__(self):
        super(frmRaporlar, self).__init__()
        self.ui = Ui_frmRaporlar()
        self.ui.setupUi(self) 
        self.showFullScreen()

        # Database bağlantısı başlat...
        self.connection = connect_to_database()

        self.ui.btnGeri.clicked.connect(self.back_application) #btnGeri buton tıklama
        # self.ui.btnUrunSil.clicked.connect(self.deleteDataUrunler)  #HATALI FONKSIYON GELİŞTİRİLİCEK

        self.ui.btnGunlukRapor.clicked.connect(self.getTodayReport) #gunluk rapor buton tıklama
        self.ui.btnHaftalikRapor.clicked.connect(self.getWeeklyReport) #hafta rapor buton tıklama
        self.ui.btnAylikRapor.clicked.connect(self.getMoonReport) #ay rapor buton tıklama


    def back_application(self): #pencere kapatma
        self.close()
        from views.frmMenu import frmMenu
        self.frm_frmMenu = frmMenu()
        self.frm_frmMenu.show()

    def calculateOrderTotals(self): #toplam satıs adet
        # Servis ve adet sütunu indeksleri
        servis_sutunu_indeksi = 2
        adet_sutunu_indeksi = 1

        # QTableWidget nesnesini alın
        table_widget = self.ui.twUrunler

        # Servis türüne göre sipariş sayılarını tutacak değişkenler
        paket_siparis_sayisi = 0
        normal_siparis_sayisi = 0

        # Tüm satırları gezerek siparişleri hesaplayın
        for row in range(table_widget.rowCount()):
            servis_turu_item = table_widget.item(row, servis_sutunu_indeksi)
            adet_item = table_widget.item(row, adet_sutunu_indeksi)
            
            if servis_turu_item is not None and adet_item is not None:
                servis_turu = servis_turu_item.text()
                adet = int(adet_item.text())  # Adet sayısını integer'a çevirin
                
                if servis_turu == "paket":
                    paket_siparis_sayisi += adet  # Paket sipariş adedini artırın
                elif servis_turu == "normal":
                    normal_siparis_sayisi += adet

        # Sonuçları label'lara yerleştirin
        self.ui.lblPaketToplam.setText(str(paket_siparis_sayisi))
        self.ui.lblServisPaket.setText(str(normal_siparis_sayisi))

    def calculateTotalAmount(self):  #toplam tutaar
        # QTableWidget nesnesini alın
        table_widget = self.ui.twUrunler

        # Toplam tutarı hesaplamak için bir değişken tanımlayın
        toplam_tutar = 0.0

        # Tüm satırları gezerek toplam tutarı hesaplayın
        for row in range(table_widget.rowCount()):
            adet_item = table_widget.item(row, 1)  # Adet sütunu indeksi
            fiyat_item = table_widget.item(row, 3)  # Fiyat sütunu indeksi

            if adet_item is not None and fiyat_item is not None:
                adet = int(adet_item.text())
                fiyat = float(fiyat_item.text())
                toplam_tutar += adet * fiyat

        # Sonucu lblToplamTutar label'ına yerleştirin
        self.ui.lblToplamTutar.setText(f"${str(toplam_tutar)}")
        self.ui.lblToplamTutar_1.setText(f"${str(toplam_tutar)}")

    def checkOpenTables(self): #acık masa kontrol
        connection =self.connection
        cursor = connection.cursor()
        try:
            # Masalar tablosundaki durum sütununu kontrol et
            cursor.execute("SELECT COUNT(*) FROM masalar WHERE durum = 2")
            result = cursor.fetchone()[0]  # 2 durumunda açık masa sayısını al
            if result > 0:
                QMessageBox.critical(self, "Hata", "Açık masalar var! Lütfen masaları kapatın.")
                return True
            else:
                return False
        except mysql.connector.Error as err:
            print("Hata:", err)
            return False
        finally:
            cursor.close()
        
    def deleteDataUrunler(self):
        for col in range(self.ui.twUrunler.columnCount()):
            item = self.ui.twUrunler.item(0, 0)
            if item is None or item.text() == "":
                QMessageBox.critical(self, "Hata", "Lütfen ürünleri getirin.")
                return

        # Masalarda açık masa kontrolü
        if self.checkOpenTables():
            return  # Eğer açık masa varsa işlemi durdur

        confirmation = QMessageBox.critical(self, "Onay", "Rapor Temizlensin mi?", QMessageBox.Ok | QMessageBox.Cancel)
        if confirmation == QMessageBox.Ok:
            # Yükleniyor mesajı yerine QProgressDialog kullan
            progress_dialog = QProgressDialog("Veritabanı siliniyor, lütfen bekleyin...", None, 0, 0, self)
            progress_dialog.setWindowTitle("Yükleniyor")
            progress_dialog.setModal(True)
            progress_dialog.show()

            try:
                connection = self.connection
                if connection:
                    cursor = connection.cursor()

                    # SQL_SAFE_UPDATES kapatma
                    cursor.execute("SET SQL_SAFE_UPDATES = 0;")

                    # Tabloları temizleme ve AUTO_INCREMENT sıfırlama
                    tables = ["satislar", "hesapodemeleri", "adisyonlar", "paketsiparisler", "personelhareketleri"]
                    for table in tables:
                        cursor.execute(f"DELETE FROM {table};")
                        cursor.execute(f"ALTER TABLE {table} AUTO_INCREMENT = 1;")

                    # SQL_SAFE_UPDATES açma
                    cursor.execute("SET SQL_SAFE_UPDATES = 1;")
                    
                    connection.commit()  # Değişiklikleri onayla
                    QMessageBox.information(self, "Başarılı", "Veritabanı başarıyla temizlendi.")
                else:
                    QMessageBox.critical(self, "Hata", "Veritabanı bağlantısı bulunamadı.")

            except mysql.connector.Error as err:
                print("Hata:", err)
                connection.rollback()  # Hata durumunda geri al
                QMessageBox.critical(self, "Hata", "Veritabanı temizleme işlemi başarısız oldu.")

            finally:
                cursor.close()

        elif confirmation == QMessageBox.Cancel:
            return
            
    def clearAllTextFields(self):
        self.ui.lblAnayemek.clear()
        self.ui.lblFastfood.clear()
        self.ui.lblTatli.clear()
        self.ui.lblCorba.clear()
        self.ui.lblDurum.clear()
        self.ui.lblIcecek.clear()
        self.ui.lblArasicak.clear()
        self.ui.lblMakarna.clear()
        self.ui.lblSalata.clear()
        self.ui.lblServisPaket.clear()
        self.ui.lblPaketToplam.clear()
        self.ui.lblToplamTutar.clear()
        self.ui.lblToplamTutar_1.clear()
        self.ui.lblDiger.clear()
        self.ui.lblKart.clear()
        self.ui.lblNakit.clear()

    def categoryTotals(self):  # kategori toplamları
        # Sütun indeksleri
        urun_id_sutunu_indeksi = 5  # twUrunler tablosundaki ürün id sütunu indeksi
        adet_sutunu_indeksi = 1    #   tablosundaki adet sütunu indeksi

        # QTableWidget nesnesini alın
        table_widget = self.ui.twUrunler

        # Ürün id'leri ile kategorileri eşleştirmek için bir sözlük oluşturun
        urun_id_kategori_mapping = {}

        # Tüm satırları gezerek ürün id'leri ve kategorileri eşleştirin
        for row in range(table_widget.rowCount()):
            urun_id_item = table_widget.item(row, urun_id_sutunu_indeksi)
            adet_item = table_widget.item(row, adet_sutunu_indeksi)

            if urun_id_item is not None and adet_item is not None:
                urun_id = int(urun_id_item.text())
                adet = int(adet_item.text())

                # Veritabanından ürünün kategoriİd'sini alın
                kategori_id = self.get_category_id(urun_id)

                # Ürün id ile kategori id'yi eşleştirin
                if kategori_id is not None:
                    if urun_id not in urun_id_kategori_mapping:
                        urun_id_kategori_mapping[urun_id] = [kategori_id, adet]
                    else:
                        urun_id_kategori_mapping[urun_id][1] += adet

        # Kategori ID Toplamı sayacı oluşturun
        kategori_id_toplam_sayaci = {}

        # Toplam sayıları hesaplayın
        for urun_id, (kategori_id, toplam_adet) in urun_id_kategori_mapping.items():
            # print(f"Ürün ID: {urun_id}, Kategori ID: {kategori_id}, Toplam Adet: {toplam_adet}")

            # Toplam sayıları sakla
            if kategori_id not in kategori_id_toplam_sayaci:
                kategori_id_toplam_sayaci[kategori_id] = toplam_adet
            else:
                kategori_id_toplam_sayaci[kategori_id] += toplam_adet

        # Etiketlere değerleri ata
        for kategori_id, toplam_adet in kategori_id_toplam_sayaci.items():
            if kategori_id == 1:
                self.ui.lblAnayemek.setText(f"{toplam_adet}")
            elif kategori_id == 2:
                self.ui.lblMakarna.setText(f"{toplam_adet}")
            elif kategori_id == 3:
                self.ui.lblSalata.setText(f"{toplam_adet}")
            elif kategori_id == 4:
                self.ui.lblCorba.setText(f"{toplam_adet}")
            elif kategori_id == 5:
                self.ui.lblFastfood.setText(f"{toplam_adet}")
            elif kategori_id == 6:
                self.ui.lblIcecek.setText(f"{toplam_adet}")
            elif kategori_id == 7:
                self.ui.lblArasicak.setText(f"{toplam_adet}")
            elif kategori_id == 8:
                self.ui.lblTatli.setText(f"{toplam_adet}")
            elif kategori_id == 9:
                self.ui.lblDurum.setText(f"{toplam_adet}")

            else:
                print("adet hatasi")
              
    def get_category_id(self, urun_id):
        connection =self.connection
        cursor = connection.cursor()

        # Veritabanından ürünün kategoriİd'sini alın
        query = "SELECT kategoriİd FROM urunler WHERE id = %s"
        cursor.execute(query, (urun_id,))
        kategori_id = cursor.fetchone()

        cursor.close()

        return kategori_id[0] if kategori_id else None

    def clearLabels(self):
        # Tüm etiketleri temizle
        self.ui.lblAnayemek.clear()
        self.ui.lblMakarna.clear()
        self.ui.lblSalata.clear()
        self.ui.lblCorba.clear()
        self.ui.lblFastfood.clear()
        self.ui.lblIcecek.clear()
        self.ui.lblArasicak.clear()
        self.ui.lblTatli.clear()
        self.ui.lblDurum.clear()

    def clearPayemnts(self):
        # Tüm etiketleri temizle
        self.ui.lblNakit.clear()
        self.ui.lblDiger.clear()
        self.ui.lblKart.clear()

    def payment_type_dataToday(self):
        self.clearPayemnts()
        connection =self.connection
        cursor = connection.cursor()

        try:
            # Bugünün tarihini alın ve bir gün öncesine dönün
            bugun = datetime.now()
            bir_gun_once = datetime.now().strftime("%Y-%m-%d")

            # Ödeme türlerine göre son 24 saat içindeki toplam tutarları alın
            query = "SELECT odemeTuru, SUM(toplamTutar) FROM hesapodemeleri WHERE tarih >= %s GROUP BY odemeTuru"
            cursor.execute(query, (bir_gun_once,))
            payment_data = cursor.fetchall()

            # Nakit, Diğer ve Kart toplam tutarlarını sıfırla
            nakit_total = 0
            diger_total = 0
            kart_total = 0

            # Her ödeme türünün toplam tutarını ilgili değişkene ekle
            for odeme_turu, toplam_tutar in payment_data:
                if odeme_turu == 'NAKİT':
                    nakit_total += toplam_tutar
                elif odeme_turu == 'DIGER':
                    diger_total += toplam_tutar
                elif odeme_turu == 'KART':
                    kart_total += toplam_tutar

            # Sonuçları label kutularına yerleştir
            self.ui.lblNakit.setText(str(nakit_total))
            self.ui.lblDiger.setText(str(diger_total))
            self.ui.lblKart.setText(str(kart_total))

        except Exception as ex:
            print("HATA", ex)

        finally:
            cursor.close()
            
    def getTodayReport(self): #gunluk rapor
        self.clearLabels()
        # Masalarda açık masa kontrolü
        if self.checkOpenTables():
            return  # Eğer açık masa varsa işlemi durdur

        connection =self.connection
        cursor = connection.cursor()

        # Bugünün tarihini alın
        bugunun_tarihi = datetime.now().strftime("%Y-%m-%d")

        query = """
        SELECT s.urunİd, s.masaİd, s.adet, s.servisTuru, u.urunAd, u.fiyat 
        FROM satislar s
        JOIN urunler u ON s.urunİd = u.id
        WHERE DATE(s.satisZamani) = %s
        """
        
        try:
            cursor.execute(query, (bugunun_tarihi,))
            siparisler = cursor.fetchall()

            # TableView'deki modeli temizleyin
            self.ui.twUrunler.setRowCount(0)

            # Verileri TableView'e ekleme
            for row_num, (urunİd, masaİd, adet, servisTuru, urunAd, fiyat) in enumerate(siparisler):
                self.ui.twUrunler.insertRow(row_num)
                self.ui.twUrunler.setItem(row_num, 0, QtWidgets.QTableWidgetItem(str(urunAd)))
                self.ui.twUrunler.setItem(row_num, 1, QtWidgets.QTableWidgetItem(str(adet)))
                self.ui.twUrunler.setItem(row_num, 2, QtWidgets.QTableWidgetItem(str(servisTuru)))
                self.ui.twUrunler.setItem(row_num, 3, QtWidgets.QTableWidgetItem(str(fiyat)))
                self.ui.twUrunler.setItem(row_num, 4, QtWidgets.QTableWidgetItem(str(masaİd)))
                self.ui.twUrunler.setItem(row_num, 5, QtWidgets.QTableWidgetItem(str(urunİd)))

                        
            self.calculateOrderTotals()#adet
            self.calculateTotalAmount()#toplam
            self.payment_type_dataToday()
            self.categoryTotals()
        except mysql.connector.Error as err:
            print("Hata:", err)

        cursor.close()

    def payment_type_dataWeek(self):
        self.clearPayemnts()
        connection =self.connection
        cursor = connection.cursor()

        try:
            # Bugünün tarihini alın
            bugunun_tarihi = datetime.now().strftime("%Y-%m-%d")

            # Haftanın başlangıç tarihini hesaplayın (7 gün geriye git)
            bir_gun_once = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d")

            # Ödeme türlerine göre son 24 saat içindeki toplam tutarları alın
            query = "SELECT odemeTuru, SUM(toplamTutar) FROM hesapodemeleri WHERE tarih >= %s GROUP BY odemeTuru"
            cursor.execute(query, (bir_gun_once,))
            payment_data = cursor.fetchall()

            # Nakit, Diğer ve Kart toplam tutarlarını sıfırla
            nakit_total = 0
            diger_total = 0
            kart_total = 0

            # Her ödeme türünün toplam tutarını ilgili değişkene ekle
            for odeme_turu, toplam_tutar in payment_data:
                if odeme_turu == 'NAKİT':
                    nakit_total += toplam_tutar
                elif odeme_turu == 'DIGER':
                    diger_total += toplam_tutar
                elif odeme_turu == 'KART':
                    kart_total += toplam_tutar

            # Sonuçları label kutularına yerleştir
            self.ui.lblNakit.setText(str(nakit_total))
            self.ui.lblDiger.setText(str(diger_total))
            self.ui.lblKart.setText(str(kart_total))

        except Exception as ex:
            print("HATA", ex)

        finally:
            cursor.close()
            
    def getWeeklyReport(self): #haftalık rapor
        self.clearLabels()
                # Masalarda açık masa kontrolü
        if self.checkOpenTables():
            return  # Eğer açık masa varsa işlemi durdur

        connection =self.connection
        cursor = connection.cursor()

        # Bugünün tarihini alın
        bugunun_tarihi = datetime.now().strftime("%Y-%m-%d")

        # Haftanın başlangıç tarihini hesaplayın (7 gün geriye git)
        haftanin_baslangici = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d")

        query = """
        SELECT s.urunİd, s.masaİd, s.adet, s.servisTuru, u.urunAd, u.fiyat 
        FROM satislar s
        JOIN urunler u ON s.urunİd = u.id
        WHERE DATE(s.satisZamani) BETWEEN %s AND %s
        """
        try:
            cursor.execute(query, (haftanin_baslangici, bugunun_tarihi))
            siparisler = cursor.fetchall()

            # TableView'deki modeli temizleyin
            self.ui.twUrunler.setRowCount(0)

            # Verileri TableView'e ekleme
            for row_num, (urunİd, masaİd, adet, servisTuru, urunAd, fiyat) in enumerate(siparisler):
                self.ui.twUrunler.insertRow(row_num)
                self.ui.twUrunler.setItem(row_num, 0, QtWidgets.QTableWidgetItem(str(urunAd)))
                self.ui.twUrunler.setItem(row_num, 1, QtWidgets.QTableWidgetItem(str(adet)))
                self.ui.twUrunler.setItem(row_num, 2, QtWidgets.QTableWidgetItem(str(servisTuru)))
                self.ui.twUrunler.setItem(row_num, 3, QtWidgets.QTableWidgetItem(str(fiyat)))
                self.ui.twUrunler.setItem(row_num, 4, QtWidgets.QTableWidgetItem(str(masaİd)))
                self.ui.twUrunler.setItem(row_num, 5, QtWidgets.QTableWidgetItem(str(urunİd)))
            
            self.calculateOrderTotals() #adet
            self.calculateTotalAmount() #toplam
            self.categoryTotals()
            self.payment_type_dataWeek()
        except mysql.connector.Error as err:
            print("Hata:", err)
        
        cursor.close()

    def payment_type_dataMoon(self):
        self.clearPayemnts()
        connection =self.connection
        cursor = connection.cursor()

        try:
            # Bugünün tarihini alın
            bugunun_tarihi = datetime.now().strftime("%Y-%m-%d")

            # Haftanın başlangıç tarihini hesaplayın (7 gün geriye git)
            bir_gun_once = (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d")

            # Ödeme türlerine göre son 24 saat içindeki toplam tutarları alın
            query = "SELECT odemeTuru, SUM(toplamTutar) FROM hesapodemeleri WHERE tarih >= %s GROUP BY odemeTuru"
            cursor.execute(query, (bir_gun_once,))
            payment_data = cursor.fetchall()

            # Nakit, Diğer ve Kart toplam tutarlarını sıfırla
            nakit_total = 0
            diger_total = 0
            kart_total = 0

            # Her ödeme türünün toplam tutarını ilgili değişkene ekle
            for odeme_turu, toplam_tutar in payment_data:
                if odeme_turu == 'NAKİT':
                    nakit_total += toplam_tutar
                elif odeme_turu == 'DIGER':
                    diger_total += toplam_tutar
                elif odeme_turu == 'KART':
                    kart_total += toplam_tutar

            # Sonuçları label kutularına yerleştir
            self.ui.lblNakit.setText(str(nakit_total))
            self.ui.lblDiger.setText(str(diger_total))
            self.ui.lblKart.setText(str(kart_total))

        except Exception as ex:
            print("HATA", ex)

        finally:
            cursor.close()
            
    def getMoonReport(self):    #aylık rapor
        self.clearLabels()
                # Masalarda açık masa kontrolü
        if self.checkOpenTables():
            return  # Eğer açık masa varsa işlemi durdur
            
        connection =self.connection
        cursor = connection.cursor()

        # Bugünün tarihini alın
        bugunun_tarihi = datetime.now().strftime("%Y-%m-%d")

        # Haftanın başlangıç tarihini hesaplayın (7 gün geriye git)
        haftanin_baslangici = (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d")

        query = """
        SELECT s.urunİd, s.masaİd, s.adet, s.servisTuru, u.urunAd, u.fiyat 
        FROM satislar s
        JOIN urunler u ON s.urunİd = u.id
        WHERE DATE(s.satisZamani) BETWEEN %s AND %s
        """
        
        try:
            cursor.execute(query, (haftanin_baslangici, bugunun_tarihi))
            siparisler = cursor.fetchall()

            # TableView'deki modeli temizleyin
            self.ui.twUrunler.setRowCount(0)

            # Verileri TableView'e ekleme
            for row_num, (urunİd, masaİd, adet, servisTuru, urunAd, fiyat) in enumerate(siparisler):
                self.ui.twUrunler.insertRow(row_num)
                self.ui.twUrunler.setItem(row_num, 0, QtWidgets.QTableWidgetItem(str(urunAd)))
                self.ui.twUrunler.setItem(row_num, 1, QtWidgets.QTableWidgetItem(str(adet)))
                self.ui.twUrunler.setItem(row_num, 2, QtWidgets.QTableWidgetItem(str(servisTuru)))
                self.ui.twUrunler.setItem(row_num, 3, QtWidgets.QTableWidgetItem(str(fiyat)))
                self.ui.twUrunler.setItem(row_num, 4, QtWidgets.QTableWidgetItem(str(masaİd)))
                self.ui.twUrunler.setItem(row_num, 5, QtWidgets.QTableWidgetItem(str(urunİd)))
            
            self.calculateOrderTotals() #adet
            self.calculateTotalAmount() #toplam
            self.categoryTotals()
            self.payment_type_dataMoon()
        except mysql.connector.Error as err:
            print("Hata:", err)
        
        cursor.close()
