from PyQt5 import QtWidgets
from forms.frmPersonelSilUi import Ui_frmPersonelSil
from PyQt5.QtWidgets import QMessageBox
from database.connect_to_database import connect_to_database 
import mysql.connector


class frmPersonelSil(QtWidgets.QMainWindow):
    def __init__(self,ad,soyad):
        super(frmPersonelSil, self).__init__()
        self.ui = Ui_frmPersonelSil()
        self.ui.setupUi(self) 
        self.showFullScreen()

        # Database bağlantısı başlat...
        self.connection = connect_to_database()

        self.personel_ad = ad
        self.personel_soyad = soyad
        self.ui.btnPersonelSil.clicked.connect(self.delete_product)                 # btnUrunGuncelle buton tıklama
        self.load_product_data()
        self.ui.btnGeri.clicked.connect(self.back_application)

    def back_application(self):
        self.close()
        from views.frmAyarlar import frmAyarlar
        self.frm_frmAyarlar = frmAyarlar()
        self.frm_frmAyarlar.show()


    def load_product_data(self):                                               #personel bılgılerını getır
        self.connection =self.connection
        if self.connection is not None:
            cursor = self.connection.cursor()
            select_query = "SELECT ad, soyad,sifre,gorev FROM personeller WHERE ad = %s AND soyad = %s "
            cursor.execute(select_query, (self.personel_ad,self.personel_soyad,))
            customer_data = cursor.fetchone()

            if customer_data:
                ad,soyad,sifre,gorev = customer_data
                self.ui.lnAd.setText(str(ad))
                self.ui.lnSoyad.setText(str(soyad))
                self.ui.lnSifre.setText(str(sifre))
                self.ui.lnGorevId.setText(str(gorev))

    def delete_product(self):                                                  #urun bılgılerını guncelle
        confirmation = QMessageBox.critical(self, "Onay", "Personel Silinsin mi ?", QMessageBox.Ok | QMessageBox.Cancel)
        if confirmation == QMessageBox.Ok:
            connection =self.connection
            if connection:
                try:
                    cursor = connection.cursor()
                    try:
                        # Sipariş silme
                        cursor.execute(
                            "DELETE FROM personeller WHERE ad = %s AND soyad = %s",
                            (self.personel_ad,self.personel_soyad,)
                        )
                        connection.commit()  # Değişiklikleri kaydet
                        QMessageBox.information(self, "Bilgi", "Personel Silindi.")

                        # Label kutularını temizle
                        self.ui.lnAd.clear()
                        self.ui.lnSoyad.clear()
                        self.ui.lnGorevId.clear()
                        self.ui.lnSifre.clear()
                        self.close()
                        from views.frmAyarlar import frmAyarlar
                        self.frm_frmAyarlar = frmAyarlar()
                        self.frm_frmAyarlar.show()

                        
                    except mysql.connector.Error as err:
                        print("Hata:", err)
                        connection.rollback()  # Hata durumunda geri al
                    finally:
                        cursor.close()
                except Exception as ex:
                    print("HATA", ex)
            else:
                return
        elif confirmation == QMessageBox.Cancel:
            return