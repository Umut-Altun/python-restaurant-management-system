from PyQt5 import QtWidgets
from forms.frmPersonelGuncelleUi import Ui_frmPersonelGuncelle
from database.connect_to_database import connect_to_database 


class frmPersonelGuncelle(QtWidgets.QMainWindow):
    def __init__(self,ad,soyad):
        super(frmPersonelGuncelle, self).__init__()
        self.ui = Ui_frmPersonelGuncelle()
        self.ui.setupUi(self) 
        self.showFullScreen()

        # Database bağlantısı başlat...
        self.connection = connect_to_database()

        self.personel_ad = ad
        self.personel_soyad = soyad
        self.ui.btnPersonelGuncelle.clicked.connect(self.update_product)  
        self.load_product_data()
        self.ui.btnGeri.clicked.connect(self.back_application)

    def back_application(self):
        self.close()
        from views.frmAyarlar import frmAyarlar
        self.frm_frmAyarlar = frmAyarlar()
        self.frm_frmAyarlar.show()

    def load_product_data(self):                                               #personel bılgılerını getır
        self.connection = self.connection
        if self.connection is not None:
            cursor = self.connection.cursor()
            select_query = "SELECT ad, soyad,sifre,gorev FROM personeller WHERE ad = %s AND soyad = %s "
            cursor.execute(select_query, (self.personel_ad,self.personel_soyad,))
            customer_data = cursor.fetchone()

            if customer_data:
                ad,soyad,sifre,gorev = customer_data
                self.ui.lnAd.setText(str(ad))
                self.ui.lnSoyad.setText(str(soyad))
                self.ui.lnSifre.setText(str(sifre))
                self.ui.lnGorevId.setText(str(gorev))

    def update_product(self):                                                  #urun bılgılerını guncelle
            # Kullanıcının girdiği verileri al
            if ((self.ui.lnAd.text() !="") and (len(self.ui.lnAd.text()) < 15)):
                ad = self.ui.lnAd.text()
            else:
                QtWidgets.QMessageBox.information(self, "HATA", "Müşteri adı 15 karakter olabilir.")
                return

            if ((self.ui.lnSoyad.text() !="") and (len(self.ui.lnSoyad.text()) < 15)):
                soyad = self.ui.lnSoyad.text()
            else:
                QtWidgets.QMessageBox.information(self, "HATA", "Müşteri soyad 15 karakter olabilir..")
                return

            if ((self.ui.lnTelefon.text() !="") and (len(self.ui.lnTelefon.text()) < 12) and (len(self.ui.lnTelefon.text()) > 10)):
                telefon = self.ui.lnTelefon.text()
            else:
                QtWidgets.QMessageBox.information(self, "HATA", "Müşteri telefon 11 karakter olmalıdır.")
                return

            if ((self.ui.lnAdres.text() !="") and (len(self.ui.lnAdres.text()) < 45)):
                adres = self.ui.lnAdres.text()
            else:
                QtWidgets.QMessageBox.information(self, "HATA", "Müşteri adres 45 karakteri olabilir.")
                return


            self.connection = self.connection
            if self.connection is not None:
                lnAd = self.ui.lnAd.text()
                lnSoyad = self.ui.lnSoyad.text()
                lnSifre = self.ui.lnSifre.text()
                lnGorev = self.ui.lnGorevId.text()

                cursor = self.connection.cursor()
                update_query = "UPDATE personeller SET ad = %s, soyad = %s, sifre = %s, gorev = %s WHERE ad = %s AND  soyad = %s"
                values = (lnAd,lnSoyad,lnSifre,lnGorev,self.personel_ad,self.personel_soyad)
                cursor.execute(update_query, values)
                self.connection.commit()

                QtWidgets.QMessageBox.information(self, "Başarılı", "Kullanıcı  bilgileri güncellendi.")
                # Girdi kutularını temizle
                self.ui.lnAd.clear()
                self.ui.lnSoyad.clear()
                self.ui.lnSifre.clear()
                self.ui.lnGorevId.clear()
                self.close()
                from views.frmAyarlar import frmAyarlar
                self.frm_frmAyarlar = frmAyarlar()
                self.frm_frmAyarlar.show()

