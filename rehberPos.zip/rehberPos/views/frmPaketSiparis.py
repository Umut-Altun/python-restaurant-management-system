from forms.frmPaketSiparisUi import Ui_frmPaketSiparis
from PyQt5.QtCore import QDateTime
from PyQt5.QtWidgets import QMessageBox
from datetime import datetime
from PyQt5 import QtWidgets
import mysql.connector
from database.connect_to_database import connect_to_database



class frmPaketSiparis(QtWidgets.QMainWindow):
    def __init__(self):
        super(frmPaketSiparis, self).__init__()
        self.ui = Ui_frmPaketSiparis()
        self.ui.setupUi(self) 
        self.showFullScreen()

        # Database bağlantıyı başlat...
        self.connection = connect_to_database() 

        #--Hesap Makınesı--
        self.ui.btn1.clicked.connect(lambda: self.add_digit(1)) 
        self.ui.btn2.clicked.connect(lambda: self.add_digit(2))
        self.ui.btn3.clicked.connect(lambda: self.add_digit(3))
        self.ui.btn4.clicked.connect(lambda: self.add_digit(4))
        self.ui.btn5.clicked.connect(lambda: self.add_digit(5))
        self.ui.btn6.clicked.connect(lambda: self.add_digit(6))
        self.ui.btn7.clicked.connect(lambda: self.add_digit(7))
        self.ui.btn8.clicked.connect(lambda: self.add_digit(8))
        self.ui.btn9.clicked.connect(lambda: self.add_digit(9))
        self.ui.btn0.clicked.connect(lambda: self.add_digit(0))
        self.ui.btnTemizle.clicked.connect(self.clear_line_edit)
        #----

        self.ui.btnGeri.clicked.connect(self.back_application)        #btnGeri buton tıklama
        self.ui.btnAnaYemek.clicked.connect(self.get_main_course)     #btnAnaYemek buton
        self.ui.btnMakarna.clicked.connect(self.get_pasta)            #btnMakarna buton
        self.ui.btnSalata.clicked.connect(self.get_salad)             #btnSalata buton
        self.ui.btnCorba.clicked.connect(self.get_soup)               #btnCorba buton
        self.ui.btnFastfood.clicked.connect(self.get_fastfood)        #btnFastfood buton
        self.ui.btnDurum.clicked.connect(self.get_durum)        #btnFastfood buton
        self.ui.btnIcecekler.clicked.connect(self.get_drink)          #btnIcecekler buton
        self.ui.btnTatli.clicked.connect(self.get_sweet)              #btnTatli buton
        self.ui.twIcindekiler.itemClicked.connect(self.contents_table)#twIcindekiler tablosu 
        self.ui.twIcindekiler.itemClicked.connect(self.connecting_calculator)#hesapmakınesının baglanması
        self.ui.btnSiparis.clicked.connect(self.order_application)    #btnSiparis
        self.ui.btnAra.clicked.connect(self.search_customer_by_name)  #btnArama buton tıklama
        self.ui.rbKart.clicked.connect(self.populate_table)    
        self.ui.rbNakit.clicked.connect(self.populate_table)    
        self.ui.btnKlavye.clicked.connect(self.openKeyboard)          #twSiparis not ekle silme 
        self.ui.btnUrunSil.clicked.connect(self.order_table_delete)
        self.ui.btnYeniMusteri.clicked.connect(self.new_customer)
        self.load_data()                                              #Musterılerı tabloya ekle
        
        # self.ui.btnSiparis.clicked.connect(self.transfer_data_to_adisyon_fis)     # adisyon yazdırma

        

    def new_customer(self):                                           #musterı ekle 
        from views.frmPaketYeniMusteri import frmPaketYeniMusteri
        self.frm_frmPaketYeniMusteri = frmPaketYeniMusteri()
        self.frm_frmPaketYeniMusteri.show()
        
    def connecting_calculator(self):                                  #Coklu sıparıs hesabMakınesı
        # Seçilen ürünün bilgilerini al
        selected_row = self.ui.twIcindekiler.currentRow()
        if selected_row < 0:
            return  # Hiçbir ürün seçilmediyse işlem yapma

        urun_adi = self.ui.twIcindekiler.item(selected_row, 2).text()  # Ürün adını al
        urun_adet = int(self.ui.lnUrunAdet.text() or 1)  # Ürün adedini al (boşsa 1 olarak kabul et)

        # Ürün adedini kontrol edin, negatifse 0 yapın
        if urun_adet < 0:
            urun_adet = 0

        if urun_adet == 0:
            return  # Ürün adeti 0 ise işlem yapma

        # twSiparis QTableWidget'deki mevcut satırları kontrol et
        for row in range(self.ui.twSiparis.rowCount()):
            existing_item = self.ui.twSiparis.item(row, 4)
            if existing_item and existing_item.text() == urun_adi:
                # Ürün zaten listede, adet sütunundaki sayıyı güncelle
                adet_item = self.ui.twSiparis.item(row, 1)
                current_adet = int(adet_item.text()) if adet_item else 1 
                new_adet = (current_adet + urun_adet)-1
                adet_item = QtWidgets.QTableWidgetItem(str(new_adet))
                self.ui.twSiparis.setItem(row, 1, adet_item)
                return 

        # Ürün bilgilerini twSiparis QTableWidget'e yerleştirin
        row_position = self.ui.twSiparis.rowCount()
        self.ui.twSiparis.insertRow(row_position)
        urun_fiyati = self.ui.twIcindekiler.item(selected_row, 0).text()
        urun_id = self.ui.twIcindekiler.item(selected_row, 1).text()
        urun_notu = ""
        self.ui.twSiparis.setItem(row_position, 0, QtWidgets.QTableWidgetItem(urun_fiyati))
        self.ui.twSiparis.setItem(row_position, 3, QtWidgets.QTableWidgetItem(urun_id))
        self.ui.twSiparis.setItem(row_position, 4, QtWidgets.QTableWidgetItem(urun_adi))
        self.ui.twSiparis.setItem(row_position, 2, QtWidgets.QTableWidgetItem(str(urun_adet)))
        self.ui.twSiparis.setItem(row_position, 1, QtWidgets.QTableWidgetItem(urun_notu))
        # Ürün adetini temizleyin
        self.ui.lnUrunAdet.clear()

    def contents_table(self, item):                                   #twİçindekiler tablosu
        # Seçilen ürünün bilgilerini al
        selected_row = item.row()
        urun_fiyati = self.ui.twIcindekiler.item(selected_row, 0).text()
        urun_id = self.ui.twIcindekiler.item(selected_row, 1).text()
        urun_adi = self.ui.twIcindekiler.item(selected_row, 2).text()
        urun_notu = ""


        # twSiparis QTableWidget'deki mevcut satırları kontrol et
        for row in range(self.ui.twSiparis.rowCount()):
            existing_item = self.ui.twSiparis.item(row, 4)
            if existing_item and existing_item.text() == urun_adi:
                # Ürün zaten listede, adet sütunundaki sayıyı artır
                adet_item = self.ui.twSiparis.item(row, 1)
                current_adet = int(adet_item.text()) if adet_item else 0
                new_adet = current_adet + 1
                adet_item = QtWidgets.QTableWidgetItem(str(new_adet))
                self.ui.twSiparis.setItem(row, 1, adet_item)
                return

        # twSiparis QTableWidget'e yeni bir satır ekleyin
        row_position = self.ui.twSiparis.rowCount()
        self.ui.twSiparis.insertRow(row_position)

        # Ürün bilgilerini twSiparis QTableWidget'e yerleştirin
        self.ui.twSiparis.setItem(row_position, 0, QtWidgets.QTableWidgetItem(urun_fiyati))
        self.ui.twSiparis.setItem(row_position, 3, QtWidgets.QTableWidgetItem(urun_id))
        self.ui.twSiparis.setItem(row_position, 4, QtWidgets.QTableWidgetItem(urun_adi))
        self.ui.twSiparis.setItem(row_position, 2, QtWidgets.QTableWidgetItem(urun_notu))

    def order_table_delete(self, item):                               #twSiparis tablosu silme 
        selected_items = self.ui.twSiparis.selectedItems()
        if not selected_items:
            return

        # Seçili öğenin bulunduğu satırı bulun
        selected_row = selected_items[0].row()

        # Tablodan seçili satırı kaldırın
        self.ui.twSiparis.removeRow(selected_row)

    def clear_line_edit(self):                                        #temizle butonu
        self.ui.lnUrunAdet.clear()

    def add_digit(self, digit):                                       #1-9 rakam gönderme
        current_text = self.ui.lnUrunAdet.text()
        new_text = current_text + str(digit)
        self.ui.lnUrunAdet.setText(new_text)

    def back_application(self):                                       #pencere kapatma
        self.close()
        from views.frmPaket import frmPaket
        self.frm_frmPaket = frmPaket()
        self.frm_frmPaket.show()
   
    def update_table_status(self, table_number):                                    # masadurum guncelleme
        connection = self.connection
        if connection is not None:
            try:
                cursor = connection.cursor()
                
                # Masalar tablosundaki belirli bir masa numarasının durumunu ve masaDurum sütununu güncelle
                update_query = "UPDATE paketmasalar SET durum = 2, masaDurum = 'acik' WHERE id = %s"
                cursor.execute(update_query, (table_number,))
                
                connection.commit()  # Değişiklikleri veritabanına kaydet
                cursor.close()
                
                
                print(f"Paket Masa {table_number} durumu güncellendi.")
            except mysql.connector.Error as err:
                print("Hata update_table:", err)

    def set_masa_info(self, masa_no):                                               # masa numarasını al
        self.ui.lblMasaNo.setText(str(masa_no))
        masa_no = str(masa_no)
        masaNumarasi = masa_no[6:]
        # Veritabanı bağlantısını alın
        connection = self.connection
        
        if connection:
            try:
                cursor = connection.cursor()
                
                # Belirli masa numarasına sahip ve durumu "Açık" olan en son adisyonun tarihini alın
                cursor.execute(
                    "SELECT tarih FROM adisyonlar WHERE masaİd = %s AND durum = %s AND servisTuru = %s ORDER BY tarih DESC LIMIT 1",
                    (masaNumarasi, "acik","paket")
                )
                
                result = cursor.fetchone()
                
                if result:
                    adisyon_tarihi = result[0]  # Veritabanından gelen tarih

                    # Şu anki tarihi ve saat bilgisini alın
                    simdiki_saat = datetime.now().time()

                    # Zaman farkını hesaplayın
                    fark_saniye = adisyon_tarihi.hour * 3600 + adisyon_tarihi.minute * 60 + adisyon_tarihi.second
                    simdiki_saat_saniye = simdiki_saat.hour * 3600 + simdiki_saat.minute * 60 + simdiki_saat.second

                    fark_saniye = simdiki_saat_saniye - fark_saniye
                    saat = fark_saniye // 3600
                    dakika = (fark_saniye % 3600) // 60

                    # Elapsed time'i lblMasaSure içinde gösterin
                    self.ui.lblMasaSure.setText(f"{saat}s {dakika}dk")

            except mysql.connector.Error as err:
                print("Hata:", err)
            finally:
                cursor.close()
                
    def add_order_to_adisyonlar(self, table_number):                                # adisyonlara masayı kaydet
        connection = self.connection
        adisyon_id = None  # Başlangıçta adisyon_id'yi boş olarak ayarlayın
        if connection is not None:
            try:
                cursor = connection.cursor()

                # Adisyonlar tablosuna ekleme yap
                insert_query = "INSERT INTO adisyonlar (masaİd, tarih, durum,servisTuru) VALUES (%s, %s, %s)"
                current_datetime = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                cursor.execute(insert_query, (table_number, current_datetime, 'acik','paket'))

                connection.commit()
                cursor.close()
                

                print(f"Masa {table_number} için sipariş kaydedildi.")
            except mysql.connector.Error as err:
                print("Hata add_order:", err)
        
    def masa_numarasina_gore_adisyon_id_al(self, masa_numarasi):
        baglanti = self.connection
        if baglanti is not None:
            try:
                cursor = baglanti.cursor()

                # Belirli bir masa numarası için adisyonId'yi almak için sorgu
                secme_sorgusu = "SELECT id FROM adisyonlar WHERE masaİd = %s AND durum = 'acik' AND servisTuru='paket'"
                cursor.execute(secme_sorgusu, (masa_numarasi,))
                adisyon_id = cursor.fetchone()[0]

                cursor.close()
                baglanti.close()

                return adisyon_id
            except mysql.connector.Error as hata:
                print("Hata masa_num:", hata)

    def order_application(self):                                                    # tum sıparıslerın buton basvurusu
        for row in range(self.ui.twSiparis.rowCount()):
            adet_item = self.ui.twSiparis.item(row, 4)
            if adet_item is None or adet_item.text() == "":
                QMessageBox.critical(self, "Hata", "Lütfen her siparişin adetini girin.")
                return
        for col in range(self.ui.twSiparis.columnCount()):
            item = self.ui.twSiparis.item(0, 0)
            if item is None or item.text() == "":
                QMessageBox.critical(self, "Hata", "Lütfen bir sipariş ekleyin.")
                return  
        
        payment_type = ""
        if self.ui.rbNakit.isChecked():
            payment_type = self.ui.rbNakit.text()
        elif self.ui.rbKart.isChecked():
            payment_type = self.ui.rbKart.text()
        if not payment_type:
            QMessageBox.critical(self, "Hata", "Lütfen ödeme türü seçin.")
            return
        
        selected_items = self.ui.twMusteriler.selectedItems()
        if not selected_items:
            QMessageBox.critical(self, "Hata", "Lütfen paket müşterisi girin.")
            return

        table_number = self.ui.lblMasaNo.text()  # Masanın numarasını al
        table_number = table_number[6:]  # Masa numarasını uygun formatta al

        print("\n<--- Masanın Açma İşlemleri Başladı --->")
        # Masanın durumunu kontrol et
        adisyon_id = self.check_table_status(table_number)
        if adisyon_id is not None:
            # Mevcut bir adisyon var, siparişleri bu adisyon üzerine ekleyin
            self.add_order_to_existing_adisyon(adisyon_id)
        else:
            # Mevcut bir adisyon yok, yeni bir adisyon oluşturun ve siparişleri ekleyin
            adisyon_id = self.create_new_adisyon(table_number)
            self.add_order_to_existing_adisyon(adisyon_id)
        
        self.update_table_status(table_number)  # Masa durumunu güncelle
        self.yazdir()

        print("<--- Masanın Açma İşlemleri Bitti --->")
        # Eğer frmKlavye açıksa, onu da kapat
        if hasattr(self, 'frm_frmKlavye'):
            self.frm_frmKlavye.close()
        
        self.close()
        from views.frmPaket import frmPaket
        self.frm_frmPaket = frmPaket()
        self.frm_frmPaket.show()

    def check_table_status(self, table_number):
        connection = self.connection
        if connection is not None:
            try:
                cursor = connection.cursor()

                # Masalar tablosundan belirli bir masa numarasının adisyon durumunu kontrol edin
                query = "SELECT id FROM adisyonlar WHERE masaİd = %s AND durum = 'acik' AND servisTuru = 'paket'"
                cursor.execute(query, (table_number,))
                result = cursor.fetchone()

                cursor.close()
                

                if result:
                    return result[0]  # Mevcut bir adisyon bulunduysa adisyon id'sini döndürün
                else:
                    return None  # Mevcut bir adisyon yoksa None döndürün
            except mysql.connector.Error as err:
                print("Hata check_table:", err)

    def create_new_adisyon(self, table_number):
        connection = self.connection
        if connection is not None:
            try:
                cursor = connection.cursor()

                # Yeni bir adisyon oluşturun
                insert_query = "INSERT INTO adisyonlar (masaİd, tarih, durum,servisTuru) VALUES (%s, %s, %s, %s)"
                current_datetime = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                cursor.execute(insert_query, (table_number, current_datetime, 'acik','paket'))
                connection.commit()

                # Oluşturulan adisyonun id'sini alın
                query = "SELECT LAST_INSERT_ID()"
                cursor.execute(query)
                adisyon_id = cursor.fetchone()[0]

                cursor.close()
                

                print(f"Paket Masa {table_number} için yeni bir adisyon oluşturuldu.")
                return adisyon_id
            except mysql.connector.Error as err:
                print("Hata crate_new:", err)

    def add_order_to_existing_adisyon(self, adisyon_id):                            # satisları dataya ekle 
        table_number = self.ui.lblMasaNo.text()  # Masanın numarasını al
        table_number = table_number[6:]  # Masa numarasını uygun biçimde alın

        # Veritabanına bağlanın
        connection = self.connection

        if connection is not None:
            try:
                cursor = connection.cursor()

                for satir in range(self.ui.twSiparis.rowCount()):
                    # Sipariş detaylarını tablodan alın
                    urun_id = int(self.ui.twSiparis.item(satir, 4).text())
                    adet = int(self.ui.twSiparis.item(satir, 1).text())

                    # Şu anki tarih ve saat bilgisini alın
                    tarih_ve_saat = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                    # Siparişi "satislar" tablosuna ekleyin
                    ekleme_sorgusu = "INSERT INTO satislar (adisyonİd, urunİd, masaİd, adet, servisTuru, durum, satisZamani) VALUES (%s,%s, %s, %s, %s, %s, %s)"
                    servıs_turu = "paket"
                    durum = "acik"

                    cursor.execute(ekleme_sorgusu, (adisyon_id, urun_id, table_number, adet,servıs_turu,durum, tarih_ve_saat))

                connection.commit()
                cursor.close()
                

                print(f"Paket Masa {table_number} için siparişler eklendi.")
            except mysql.connector.Error as hata:
                print("Hata add_order:", hata)

    def load_data(self):                                                            # musterılerı tabloya ekle
        connection = self.connection
        if connection is not None:
            try:
                cursor = connection.cursor()
                # Verileri çek
                cursor.execute("SELECT ad, soyad, telefon, adres FROM musteriler")
                result = cursor.fetchall()

                # TableWidget'e verileri ekle
                self.ui.twMusteriler.setRowCount(len(result))
                self.ui.twMusteriler.setColumnCount(4)

                for row_num, row_data in enumerate(result):
                    for col_num, col_data in enumerate(row_data):
                        self.ui.twMusteriler.setItem(row_num, col_num, QtWidgets.QTableWidgetItem(str(col_data)))

                cursor.close()
                
            except mysql.connector.Error as err:
                print("Hata:", err)

    def search_customer_by_name(self):                                              # musterı arama ıslemlerı
        ad = self.ui.lnAd.text()
        soyad = self.ui.lnSoyad.text()  # lnSoyad'dan metni al
        telefon = self.ui.lnTelefon.text()  # lnTelefon'dan metni al

        connection = self.connection
        if connection is not None:
            try:
                cursor = connection.cursor()
                # SQL sorgusu oluştur ve çalıştır
                query = "SELECT ad, soyad, telefon, adres FROM musteriler WHERE ad LIKE %s AND soyad LIKE %s AND telefon LIKE %s ORDER BY ad"
                cursor.execute(query, ('%' + ad + '%', '%' + soyad + '%', '%' + telefon + '%'))
                result = cursor.fetchall()

                # TableWidget'i temizle ve yeni verileri ekle
                self.ui.twMusteriler.setRowCount(len(result))
                for row_num, row_data in enumerate(result):
                    for col_num, col_data in enumerate(row_data):
                        self.ui.twMusteriler.setItem(row_num, col_num, QtWidgets.QTableWidgetItem(str(col_data)))

                cursor.close()
                
            except mysql.connector.Error as err:
                print("Hata:", err)

        # Arama işlemi bittiğinde kutuları temizle
        self.ui.lnAd.clear()
        self.ui.lnSoyad.clear()
        self.ui.lnTelefon.clear()

    def populate_table(self):
        total_price = 0.0  # Toplam fiyatı sıfıra ayarlayın

        for row in range(self.ui.twSiparis.rowCount()):  # Tablonun tüm satırlarını döngü ile dolaş
            adet_item = self.ui.twSiparis.item(row, 1)
            fiyat_item = self.ui.twSiparis.item(row, 3)

            if adet_item is not None and fiyat_item is not None:
                adet = int(adet_item.text())  # Satılan adet integer'a çevriliyor
                fiyat = float(fiyat_item.text())  # Ürün fiyatı float'a çevriliyor

                item_total = adet * fiyat
                total_price += item_total  # Her ürünün fiyatını toplam fiyata ekleyin

        # Toplam fiyatı lblToplamTutar içinde göster
        self.ui.lblToplamTutar.setText(str(total_price))

    def openKeyboard(self):
        selected_row = self.ui.twSiparis.currentRow()
        if selected_row >= 0:
            urun_not = self.ui.twSiparis.item(selected_row, 2)
            
            if urun_not is not None:
                from views.frmKlavye import frmKlavye
                self.frm_frmKlavye = frmKlavye(selected_row, self)
                self.frm_frmKlavye.show()
            else:
                QtWidgets.QMessageBox.information(self, "Hata", "Ürün notu bulunamadı.")
        else:
            QtWidgets.QMessageBox.information(self, "Hata", "Ürün seçilmedi.")

    def transfer_data_to_adisyon_fis(self):                                         # adisyon yazdırma
        # Ödeme türünü alın (rbNakit veya rbKart)
        if self.ui.rbNakit.isChecked():
            payment_type = self.ui.rbNakit.text()
        elif self.ui.rbKart.isChecked():
            payment_type = self.ui.rbKart.text()
        else:
            return

        if not payment_type:
            QMessageBox.critical(self, "Hata", "Lütfen ödeme türü seçin.")
            return
        
        for row in range(self.ui.twMusteriler.rowCount()):  # Tablonun tüm satırlarını döngü ile dolaş
            adres = self.ui.twMusteriler.item(row, 3)
            tel = self.ui.twMusteriler.item(row, 2)
            adress = str(adres.text())
            tel = str(tel.text())
        
        # Aktarılacak verileri topla, örneğin, twSiparisOdeme tablosundaki verileri alabilirsiniz
        table_data = []
        for row in range(self.ui.twSiparis.rowCount()):
            row_data = []
            for column in range(self.ui.twSiparis.columnCount()):
                item = self.ui.twSiparis.item(row, column)
                if item:
                    row_data.append(item.text())
                else:
                    row_data.append('')
            row_data = [row_data[0],row_data[1],row_data[3],row_data[2]]
            table_data.append(row_data)

        # Tarih ve ödeme türü verilerini ekleyin
        tarih = QDateTime.currentDateTime().toString("yyyy-MM-dd HH:mm:ss")
        self.adisyon_fis.set_tarih(tarih)
        self.adisyon_fis.set_odeme_turu(payment_type)
        toplam_tutar = self.ui.lblToplamTutar.text()
        self.adisyon_fis.set_toplam_tutar(toplam_tutar)
        self.adisyon_fis.ui.lblAdres.setText(adress)
        self.adisyon_fis.ui.lnTelefon.setText(tel)
        self.adisyon_fis.populate(table_data)
        self.adisyon_fis.show()

    def yazdir(self):
        try:
            dosya_adi = "adisyon_fisi.txt"
            with open(dosya_adi, "w", encoding="utf-8") as dosya:
                # Ek bilgileri dosyaya yaz
                simdiki_zaman = datetime.now().strftime("%H:%M")  # Şu anki tarih ve saat bilgisini al ve formatla
                dosya.write("-------- REHBER ADİSYON ---------\n\n")
                dosya.write(f"Saat: {simdiki_zaman}\n")
                dosya.write(f"No: {self.ui.lblMasaNo.text()}\n\n")
                
                
                # musterı bilgilerini dosyaya yaz
                for row in range(self.ui.twMusteriler.rowCount()):
                    if self.ui.twMusteriler.item(row, 0) and self.ui.twMusteriler.item(row, 1) and self.ui.twMusteriler.item(row, 2)and self.ui.twMusteriler.item(row, 3):
                        ad = self.ui.twMusteriler.item(row, 0).text()
                        soyad = self.ui.twMusteriler.item(row, 1).text()
                        telefon = self.ui.twMusteriler.item(row, 2).text()
                        adres = self.ui.twMusteriler.item(row, 3).text()


                dosya.write(f"Ad   : {ad}\n")
                dosya.write(f"Soyad: {soyad}\n")
                dosya.write(f"TelNo: {telefon}\n")
                if len(adres) > 26:
                    # 28 karakterden sonra bir alt satıra geç
                    dosya.write(f"Adres: {adres[:26]}\n")
                    dosya.write(f"{adres[26:]}\n\n")
                else:
                    dosya.write(f"Adres: {adres}\n\n")

                # Sipariş bilgilerini dosyaya yaz
                dosya.write("Ürün\tAdet\tFiyat\n")
                for row in range(self.ui.twSiparis.rowCount()):
                    if self.ui.twSiparis.item(row, 0) and self.ui.twSiparis.item(row, 1) and self.ui.twSiparis.item(row, 3):
                        urun = self.ui.twSiparis.item(row, 0).text()
                        adet = self.ui.twSiparis.item(row, 1).text()
                        fiyat = self.ui.twSiparis.item(row, 3).text()
                        dosya.write(f"{urun.ljust(21)}{adet.ljust(9)}{fiyat}\n")
        
                # Toplam tutarı dosyaya yaz
                dosya.write(f"\nTOPLAM TUTAR: {self.ui.lblToplamTutar.text()}")
                dosya.write("\n\n------ İyi Günler Dileriz -------")

                # ------------------------------------------------------------------ 
                payment_type = ""
                if self.ui.rbNakit.isChecked():
                    payment_type = self.ui.rbNakit.text()
                elif self.ui.rbKart.isChecked():
                    payment_type = self.ui.rbKart.text()
                if not payment_type:
                    QMessageBox.critical(self, "Hata", "Lütfen ödeme türü seçin.")
                    return
                connection = self.connection
                masaNo = self.ui.lblMasaNo.text()
                odemeTuru = payment_type
                if connection is not None:
                    try:
                        cursor = connection.cursor()

                        # Adisyonlar tablosuna ekleme yap
                        insert_query = "INSERT INTO paketsiparisler (ad, soyad, adres,telefon,odemeTuru,durum,masaNo) VALUES (%s,%s, %s, %s, %s, %s, %s)"
                        cursor.execute(insert_query, (ad, soyad, adres,telefon,odemeTuru,"acik",masaNo))

                        connection.commit()
                        cursor.close()
                        

                        print(f"Paket Müşterisi: {telefon} için sipariş kaydedildi.")
                    except mysql.connector.Error as err:
                        print("Hata add_order:", err)
                # ------------------------------------------------------------------ 

            print(f"{dosya_adi} dosyasına yazıldı.")

        except Exception as e:
            print(f"Hata: {e}")

    def get_items_by_category(self, category_id):
        connection = self.connection
        cursor = connection.cursor()
        # urunler tablosundan kategoriId'ye göre ürünleri seçin
        query = "SELECT id, urunAd, fiyat FROM urunler WHERE kategoriId = %s"
        try:
            cursor.execute(query, (category_id,))
            items = cursor.fetchall()

            # TableView'deki modeli temizleyin
            self.ui.twIcindekiler.setRowCount(0)

            # Verileri TableView'e ekleme
            for row_num, (urunAd, fiyat, id) in enumerate(items):
                self.ui.twIcindekiler.insertRow(row_num)
                self.ui.twIcindekiler.setItem(row_num, 0, QtWidgets.QTableWidgetItem(str(fiyat)))
                self.ui.twIcindekiler.setItem(row_num, 1, QtWidgets.QTableWidgetItem(str(id)))
                self.ui.twIcindekiler.setItem(row_num, 2, QtWidgets.QTableWidgetItem(str(urunAd)))
        except mysql.connector.Error as err:
            print("Hata:", err)
        finally:
            cursor.close()

    def get_main_course(self):
        self.get_items_by_category(1)

    def get_pasta(self):
        self.get_items_by_category(2)

    def get_salad(self):
        self.get_items_by_category(3)

    def get_soup(self):
        self.get_items_by_category(4)

    def get_fastfood(self):
        self.get_items_by_category(5)

    def get_drink(self):
        self.get_items_by_category(6)

    def get_between(self):
        self.get_items_by_category(7)

    def get_durum(self):
        self.get_items_by_category(9)

    def get_sweet(self):
        self.get_items_by_category(8)